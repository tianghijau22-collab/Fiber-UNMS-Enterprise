-- ==========================================================
-- FIBER-UNMS ENTERPRISE DATABASE BACKUP
-- Database: fiber_unms_enterprise
-- Tanggal Pembuatan: 2026-08-17 16:31:31
-- Catatan: Backup Inisialisasi Sistem Fiber-UNMS
-- Engine: PostgreSQL Native Dump Exporter
-- ==========================================================

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

-- Nonaktifkan Foreign Key Check
SET CONSTRAINTS ALL DEFERRED;

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "audit_logs"
-- ----------------------------------------------------------

TRUNCATE TABLE "audit_logs" CASCADE;

INSERT INTO "audit_logs" ("id", "user_id", "user_name", "user_role", "action", "module", "description", "ip_address", "user_agent", "old_values", "new_values", "created_at", "updated_at") VALUES
(6, NULL, 'jasen', 'Super Administrator', 'OTDR_TRACE', 'OTDR Tracing', 'Menjalankan simulasi penembakan laser OTDR dari POP Central ke ODC Koto Baru. Jarak terdeteksi 1.200 meter.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', NULL, '{"distance_meters":1200,"break_lat":-0.9452,"break_lng":100.3621}', '2026-08-09 15:42:19', '2026-08-09 15:42:19'),
(7, NULL, 'Rian Hidayat', 'Teknisi Jointer', 'UPDATE', 'Ticketing & Work Order', 'Memperbarui status tiket TICK-2026-0001 menjadi Dalam Penanganan. Menambahkan catatan OTDR tiang #14.', '192.168.1.105', 'Fiber-UNMS Mobile App (Android 14)', '{"status":"Open"}', '{"status":"In Progress","technician":"Rian Hidayat"}', '2026-08-09 15:42:19', '2026-08-09 15:42:19'),
(8, NULL, 'Dewi Lestari', 'Customer Service', 'CREATE', 'Customer Management', 'Mendaftarkan pelanggan baru PT Maju Bersama (Paket FTTH Dedicated 50Mbps). ID: CUST-2026-0882.', '192.168.1.112', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', NULL, '{"name":"PT Maju Bersama","package":"50Mbps Dedicated"}', '2026-08-09 15:42:19', '2026-08-09 15:42:19'),
(9, NULL, 'System Telemetry Engine', 'System', 'PROVISIONING', 'OLT & Telemetry Engine', 'Polling otomatis OLT ZTE C320 Solok. Mengkonfigurasi VLAN 100 & Service Profile ONT ZTE-F663.', '10.10.0.1', 'SNMP Poller Daemon v2.4', '{"status":"Unconfigured"}', '{"status":"ONLINE","rx_power":"-19.4 dBm"}', '2026-08-09 15:42:19', '2026-08-09 15:42:19'),
(10, NULL, 'Admin NOC Enterprise', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna berhasil melakukan otentikasi login ke Dashboard NOC Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', NULL, '{"auth_status":"Success"}', '2026-08-09 15:42:19', '2026-08-09 15:42:19'),
(11, NULL, 'admin@fiber-unms.id', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk email admin@fiber-unms.id (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_email":"admin@fiber-unms.id","status":"FAILED"}', '2026-08-09 15:45:01', '2026-08-09 15:45:01'),
(12, NULL, 'a@fiber-unms.id', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk email a@fiber-unms.id (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_email":"a@fiber-unms.id","status":"FAILED"}', '2026-08-09 15:45:13', '2026-08-09 15:45:13'),
(13, NULL, 'admin@fiber-unms.id', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk email admin@fiber-unms.id (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_email":"admin@fiber-unms.id","status":"FAILED"}', '2026-08-09 15:45:17', '2026-08-09 15:45:17'),
(14, NULL, 'admin@fiber-unms.id', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk email admin@fiber-unms.id (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_email":"admin@fiber-unms.id","status":"FAILED"}', '2026-08-09 15:47:18', '2026-08-09 15:47:18'),
(15, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem NOC Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"Network Operation Center"}', '2026-08-09 15:56:31', '2026-08-09 15:56:31'),
(16, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem NOC.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 15:58:18', '2026-08-09 15:58:18'),
(17, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem NOC Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:09:21', '2026-08-09 16:09:21'),
(18, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem NOC.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:09:37', '2026-08-09 16:09:37'),
(19, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:17:44', '2026-08-09 16:17:44'),
(20, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:18:19', '2026-08-09 16:18:19'),
(21, NULL, 'asdasd', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdasd'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdasd","status":"FAILED"}', '2026-08-09 16:18:59', '2026-08-09 16:18:59'),
(22, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 26_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:22:09', '2026-08-09 16:22:09'),
(23, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 26_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:22:13', '2026-08-09 16:22:13'),
(24, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:24:09', '2026-08-09 16:24:09'),
(25, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:24:13', '2026-08-09 16:24:13'),
(26, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:25:05', '2026-08-09 16:25:05'),
(27, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:25:21', '2026-08-09 16:25:21'),
(28, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:25:33', '2026-08-09 16:25:33'),
(29, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:25:36', '2026-08-09 16:25:36'),
(30, NULL, 'asdasd', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdasd'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdasd","status":"FAILED"}', '2026-08-09 16:27:37', '2026-08-09 16:27:37'),
(31, NULL, 'asdas', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdas'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdas","status":"FAILED"}', '2026-08-09 16:29:10', '2026-08-09 16:29:10'),
(32, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:29:54', '2026-08-09 16:29:54'),
(33, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:29:58', '2026-08-09 16:29:58'),
(34, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:30:07', '2026-08-09 16:30:07'),
(35, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:30:11', '2026-08-09 16:30:11'),
(36, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:32:08', '2026-08-09 16:32:08'),
(37, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:32:13', '2026-08-09 16:32:13'),
(38, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 26_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:32:27', '2026-08-09 16:32:27'),
(39, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 26_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:32:40', '2026-08-09 16:32:40'),
(40, NULL, 'asdasd', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdasd'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdasd","status":"FAILED"}', '2026-08-09 16:33:17', '2026-08-09 16:33:17'),
(41, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:37:32', '2026-08-09 16:37:32'),
(42, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:37:40', '2026-08-09 16:37:40'),
(43, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:37:49', '2026-08-09 16:37:49'),
(44, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 26_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:37:59', '2026-08-09 16:37:59'),
(45, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 26_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:38:06', '2026-08-09 16:38:06'),
(46, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 26_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:38:15', '2026-08-09 16:38:15'),
(47, NULL, 'asdasd', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdasd'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdasd","status":"FAILED"}', '2026-08-09 16:38:36', '2026-08-09 16:38:36'),
(48, NULL, 'asdasd', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdasd'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdasd","status":"FAILED"}', '2026-08-09 16:40:32', '2026-08-09 16:40:32'),
(49, NULL, 'adas', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''adas'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 26_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1', NULL, '{"attempt_username":"adas","status":"FAILED"}', '2026-08-09 16:40:51', '2026-08-09 16:40:51'),
(50, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 26_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:41:06', '2026-08-09 16:41:06'),
(51, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 26_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:41:15', '2026-08-09 16:41:15'),
(52, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:41:24', '2026-08-09 16:41:24'),
(53, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:41:33', '2026-08-09 16:41:33'),
(54, NULL, 'asdasd', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdasd'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdasd","status":"FAILED"}', '2026-08-09 16:41:36', '2026-08-09 16:41:36'),
(55, NULL, 'asdasd', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdasd'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdasd","status":"FAILED"}', '2026-08-09 16:41:42', '2026-08-09 16:41:42'),
(56, NULL, 'asdasd', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdasd'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdasd","status":"FAILED"}', '2026-08-09 16:41:45', '2026-08-09 16:41:45'),
(57, NULL, 'asdas', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdas'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdas","status":"FAILED"}', '2026-08-09 16:42:16', '2026-08-09 16:42:16'),
(58, NULL, 'asdas', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdas'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdas","status":"FAILED"}', '2026-08-09 16:42:38', '2026-08-09 16:42:38'),
(59, NULL, 'asdas', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdas'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdas","status":"FAILED"}', '2026-08-09 16:42:58', '2026-08-09 16:42:58'),
(60, NULL, 'asdda', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdda'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdda","status":"FAILED"}', '2026-08-09 16:43:20', '2026-08-09 16:43:20'),
(61, NULL, 'asdda', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdda'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdda","status":"FAILED"}', '2026-08-09 16:43:22', '2026-08-09 16:43:22'),
(62, NULL, 'asdda', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdda'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdda","status":"FAILED"}', '2026-08-09 16:43:24', '2026-08-09 16:43:24'),
(63, 10, 'Jasen', 'Super Administrator', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''jasen'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"jasen","status":"FAILED"}', '2026-08-09 16:43:30', '2026-08-09 16:43:30'),
(64, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:43:35', '2026-08-09 16:43:35'),
(65, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:44:03', '2026-08-09 16:44:03'),
(66, NULL, 'asdasd', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdasd'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdasd","status":"FAILED"}', '2026-08-09 16:44:09', '2026-08-09 16:44:09'),
(67, NULL, 'adas', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''adas'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"adas","status":"FAILED"}', '2026-08-09 16:44:19', '2026-08-09 16:44:19'),
(68, 10, 'Jasen', 'Super Administrator', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''jasen'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"jasen","status":"FAILED"}', '2026-08-09 16:47:53', '2026-08-09 16:47:53'),
(69, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:47:59', '2026-08-09 16:47:59'),
(70, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:48:04', '2026-08-09 16:48:04'),
(71, NULL, 'asdas', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdas'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdas","status":"FAILED"}', '2026-08-09 16:48:39', '2026-08-09 16:48:39'),
(72, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:48:47', '2026-08-09 16:48:47'),
(73, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:48:55', '2026-08-09 16:48:55'),
(74, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:49:08', '2026-08-09 16:49:08'),
(75, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:49:14', '2026-08-09 16:49:14'),
(76, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:49:23', '2026-08-09 16:49:23'),
(77, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:49:29', '2026-08-09 16:49:29'),
(78, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:50:36', '2026-08-09 16:50:36'),
(79, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:50:44', '2026-08-09 16:50:44'),
(80, NULL, 'zxzxcz', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''zxzxcz'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"zxzxcz","status":"FAILED"}', '2026-08-09 16:52:56', '2026-08-09 16:52:56'),
(81, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:53:06', '2026-08-09 16:53:06'),
(82, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:53:12', '2026-08-09 16:53:12'),
(83, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:54:42', '2026-08-09 16:54:42'),
(84, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:54:51', '2026-08-09 16:54:51'),
(85, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:54:58', '2026-08-09 16:54:58'),
(86, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:55:48', '2026-08-09 16:55:48'),
(87, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:55:54', '2026-08-09 16:55:54'),
(88, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:56:05', '2026-08-09 16:56:05'),
(89, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:56:11', '2026-08-09 16:56:11'),
(90, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:56:27', '2026-08-09 16:56:27'),
(91, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:56:36', '2026-08-09 16:56:36'),
(92, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 16:56:43', '2026-08-09 16:56:43'),
(93, NULL, 'asdas', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdas'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdas","status":"FAILED"}', '2026-08-09 16:56:48', '2026-08-09 16:56:48'),
(94, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 16:57:32', '2026-08-09 16:57:32'),
(95, NULL, 'bsbdb', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''bsbdb'' (Password salah atau user tidak ditemukan).', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36', NULL, '{"attempt_username":"bsbdb","status":"FAILED"}', '2026-08-09 17:17:13', '2026-08-09 17:17:13'),
(96, NULL, 'bsbdb', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''bsbdb'' (Password salah atau user tidak ditemukan).', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36', NULL, '{"attempt_username":"bsbdb","status":"FAILED"}', '2026-08-09 17:17:16', '2026-08-09 17:17:16'),
(97, 10, 'Jasen', 'Super Administrator', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''jasen'' (Password salah atau user tidak ditemukan).', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36', NULL, '{"attempt_username":"jasen","status":"FAILED"}', '2026-08-09 17:17:32', '2026-08-09 17:17:32'),
(98, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 17:17:40', '2026-08-09 17:17:40'),
(99, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 17:17:49', '2026-08-09 17:17:49'),
(100, NULL, 'xcbbn', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''xcbbn'' (Password salah atau user tidak ditemukan).', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36', NULL, '{"attempt_username":"xcbbn","status":"FAILED"}', '2026-08-09 17:18:03', '2026-08-09 17:18:03'),
(101, 10, 'Jasen', 'Super Administrator', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''jasen'' (Password salah atau user tidak ditemukan).', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36', NULL, '{"attempt_username":"jasen","status":"FAILED"}', '2026-08-09 17:18:19', '2026-08-09 17:18:19'),
(102, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-09 17:18:28', '2026-08-09 17:18:28'),
(103, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-09 17:18:36', '2026-08-09 17:18:36'),
(104, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-12 14:27:50', '2026-08-12 14:27:50'),
(105, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-12 14:29:02', '2026-08-12 14:29:02'),
(106, NULL, 'Super Administrator', 'Super Administrator', 'CREATE', 'Management Pengguna', 'Membuat akun pengguna baru tes (Teknisi Jointer - -)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"id":11,"name":"tes","email":"tes@gmail.com","role":"Teknisi Jointer","division":"-","status":"Active"}', '2026-08-12 14:34:12', '2026-08-12 14:34:12'),
(107, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-12 14:34:16', '2026-08-12 14:34:16'),
(108, NULL, 'tes', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''tes'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"tes","status":"FAILED"}', '2026-08-12 14:34:24', '2026-08-12 14:34:24'),
(109, NULL, 'tes', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''tes'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"tes","status":"FAILED"}', '2026-08-12 14:34:31', '2026-08-12 14:34:31'),
(110, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-12 14:34:42', '2026-08-12 14:34:42'),
(111, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-12 14:35:19', '2026-08-12 14:35:19'),
(112, NULL, 'tes', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''tes'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"tes","status":"FAILED"}', '2026-08-12 14:35:37', '2026-08-12 14:35:37'),
(113, NULL, 'tes', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''tes'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"tes","status":"FAILED"}', '2026-08-12 14:35:41', '2026-08-12 14:35:41'),
(114, NULL, 'tes', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''tes'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"tes","status":"FAILED"}', '2026-08-12 14:35:44', '2026-08-12 14:35:44'),
(115, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-12 14:35:53', '2026-08-12 14:35:53'),
(116, NULL, 'Super Administrator', 'Super Administrator', 'DELETE', 'Management Pengguna', 'Menghapus akun pengguna tes (tes@gmail.com)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"id":11,"name":"tes","email":"tes@gmail.com","role":"Teknisi Jointer","division":"-"}', NULL, '2026-08-12 14:38:18', '2026-08-12 14:38:18'),
(117, NULL, 'Super Administrator', 'Super Administrator', 'CREATE', 'Management Pengguna', 'Membuat akun pengguna baru tim (Teknisi Jointer - Operasional Fiber)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"id":12,"name":"tim","email":"tianghijau22@gmail.com","role":"Teknisi Jointer","division":"Operasional Fiber","status":"Active"}', '2026-08-12 14:38:59', '2026-08-12 14:38:59'),
(118, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-12 14:39:11', '2026-08-12 14:39:11'),
(119, NULL, 'tim', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''tim'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"tim","status":"FAILED"}', '2026-08-12 14:39:17', '2026-08-12 14:39:17'),
(120, NULL, 'tim', 'Guest', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''tim'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"tim","status":"FAILED"}', '2026-08-12 14:44:05', '2026-08-12 14:44:05'),
(121, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-12 14:44:14', '2026-08-12 14:44:14'),
(122, NULL, 'Super Administrator', 'Super Administrator', 'DELETE', 'Management Pengguna', 'Menghapus akun pengguna tim (tianghijau22@gmail.com)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"id":12,"name":"tim","email":"tianghijau22@gmail.com","role":"Teknisi Jointer","division":"Operasional Fiber"}', NULL, '2026-08-12 14:44:25', '2026-08-12 14:44:25'),
(123, NULL, 'Super Administrator', 'Super Administrator', 'CREATE', 'Management Pengguna', 'Membuat akun pengguna baru tim1 (Username: tim1, Role: Teknisi Jointer)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"id":13,"name":"tim1","username":"tim1","email":"tim1@gmail.com","role":"Teknisi Jointer","division":"Operasional Fiber","status":"Active"}', '2026-08-12 14:45:15', '2026-08-12 14:45:15'),
(124, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-12 14:45:42', '2026-08-12 14:45:42'),
(125, 13, 'tim1', 'Teknisi Jointer', 'LOGIN', 'Authentication', 'Pengguna tim1 (Teknisi Jointer) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":13,"username":"tim1","role":"Teknisi Jointer","division":"Operasional Fiber"}', '2026-08-12 14:45:49', '2026-08-12 14:45:49'),
(126, NULL, 'Super Administrator', 'Super Administrator', 'UPDATE', 'Management Pengguna', 'Memperbarui data akun pengguna tim1 (#ID: 13)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"name":"tim1","username":"tim1","email":"tim1@gmail.com","role":"Teknisi Jointer","division":"Operasional Fiber","phone":"08888888888","status":"Active"}', '{"name":"tim1","username":"tim1","email":"tim1@gmail.com","role":"Customer Service","division":"Operasional Fiber","phone":"08888888888","status":"Active"}', '2026-08-12 14:46:36', '2026-08-12 14:46:36'),
(127, NULL, 'Super Administrator', 'Super Administrator', 'UPDATE', 'Management Pengguna', 'Memperbarui data akun pengguna tim1 (#ID: 13)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"name":"tim1","username":"tim1","email":"tim1@gmail.com","role":"Customer Service","division":"Operasional Fiber","phone":"08888888888","status":"Active"}', '{"name":"tim1","username":"tim1","email":"tim1@gmail.com","role":"Teknisi Jointer","division":"Operasional Fiber","phone":"08888888888","status":"Active"}', '2026-08-12 14:46:42', '2026-08-12 14:46:42'),
(128, 13, 'tim1', 'Teknisi Jointer', 'LOGOUT', 'Authentication', 'Pengguna tim1 telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-12 14:52:45', '2026-08-12 14:52:45'),
(129, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-12 14:52:51', '2026-08-12 14:52:51'),
(130, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-12 14:54:35', '2026-08-12 14:54:35'),
(131, 13, 'tim1', 'Teknisi Jointer', 'LOGIN', 'Authentication', 'Pengguna tim1 (Teknisi Jointer) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":13,"username":"tim1","role":"Teknisi Jointer","division":"Operasional Fiber"}', '2026-08-12 14:54:42', '2026-08-12 14:54:42'),
(132, 13, 'tim1', 'Teknisi Jointer', 'LOGOUT', 'Authentication', 'Pengguna tim1 telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-12 15:22:39', '2026-08-12 15:22:39'),
(133, 13, 'tim1', 'Teknisi Jointer', 'LOGIN', 'Authentication', 'Pengguna tim1 (Teknisi Jointer) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":13,"username":"tim1","role":"Teknisi Jointer","division":"Operasional Fiber"}', '2026-08-12 15:22:48', '2026-08-12 15:22:48'),
(134, 13, 'tim1', 'Teknisi Jointer', 'LOGOUT', 'Authentication', 'Pengguna tim1 telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-14 10:35:56', '2026-08-14 10:35:56'),
(135, 13, 'tim1', 'Teknisi Jointer', 'LOGIN', 'Authentication', 'Pengguna tim1 (Teknisi Jointer) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":13,"username":"tim1","role":"Teknisi Jointer","division":"Operasional Fiber"}', '2026-08-14 10:36:05', '2026-08-14 10:36:05'),
(136, 13, 'tim1', 'Teknisi Jointer', 'LOGOUT', 'Authentication', 'Pengguna tim1 telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-14 10:42:03', '2026-08-14 10:42:03'),
(137, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-14 10:42:09', '2026-08-14 10:42:09'),
(138, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-14 10:42:27', '2026-08-14 10:42:27'),
(139, 13, 'tim1', 'Teknisi Jointer', 'LOGIN', 'Authentication', 'Pengguna tim1 (Teknisi Jointer) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":13,"username":"tim1","role":"Teknisi Jointer","division":"Operasional Fiber"}', '2026-08-14 10:42:33', '2026-08-14 10:42:33'),
(140, NULL, 'Super Administrator', 'Super Administrator', 'OTDR_TRACE', 'OTDR Tracing', 'Eksekusi penembakan laser OTDR - Jarak terdeteksi: 650 meter', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"distance_meters":650,"cable_id":"12","break_coords":null,"nearest_node":null}', '2026-08-14 10:43:52', '2026-08-14 10:43:52'),
(141, NULL, 'Super Administrator', 'Super Administrator', 'OTDR_TRACE', 'OTDR Tracing', 'Eksekusi penembakan laser OTDR - Jarak terdeteksi: 4489 meter', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"distance_meters":4489,"cable_id":"12","break_coords":null,"nearest_node":null}', '2026-08-14 10:44:30', '2026-08-14 10:44:30'),
(142, 13, 'tim1', 'Teknisi Jointer', 'LOGOUT', 'Authentication', 'Pengguna tim1 telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-14 10:44:59', '2026-08-14 10:44:59'),
(143, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-14 10:45:05', '2026-08-14 10:45:05'),
(144, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-14 10:46:42', '2026-08-14 10:46:42'),
(145, 13, 'tim1', 'Teknisi Jointer', 'LOGIN', 'Authentication', 'Pengguna tim1 (Teknisi Jointer) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":13,"username":"tim1","role":"Teknisi Jointer","division":"Operasional Fiber"}', '2026-08-14 10:46:49', '2026-08-14 10:46:49'),
(146, 13, 'tim1', 'Teknisi Jointer', 'LOGIN', 'Authentication', 'Pengguna tim1 (Teknisi Jointer) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":13,"username":"tim1","role":"Teknisi Jointer","division":"Operasional Fiber"}', '2026-08-14 10:48:13', '2026-08-14 10:48:13'),
(147, 13, 'tim1', 'Teknisi Jointer', 'LOGIN', 'Authentication', 'Pengguna tim1 (Teknisi Jointer) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":13,"username":"tim1","role":"Teknisi Jointer","division":"Operasional Fiber"}', '2026-08-14 10:48:33', '2026-08-14 10:48:33'),
(148, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-14 10:50:26', '2026-08-14 10:50:26'),
(149, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-14 10:50:45', '2026-08-14 10:50:45'),
(150, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-14 10:51:55', '2026-08-14 10:51:55'),
(151, 13, 'tim1', 'Teknisi Jointer', 'LOGIN', 'Authentication', 'Pengguna tim1 (Teknisi Jointer) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":13,"username":"tim1","role":"Teknisi Jointer","division":"Operasional Fiber"}', '2026-08-14 10:54:16', '2026-08-14 10:54:16'),
(152, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-14 10:56:17', '2026-08-14 10:56:17'),
(153, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-14 10:56:50', '2026-08-14 10:56:50'),
(154, 13, 'tim1', 'Teknisi Jointer', 'LOGIN', 'Authentication', 'Pengguna tim1 (Teknisi Jointer) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":13,"username":"tim1","role":"Teknisi Jointer","division":"Operasional Fiber"}', '2026-08-14 10:56:56', '2026-08-14 10:56:56'),
(155, 13, 'tim1', 'Teknisi Jointer', 'LOGOUT', 'Authentication', 'Pengguna tim1 telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-14 11:00:17', '2026-08-14 11:00:17'),
(156, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-14 11:00:23', '2026-08-14 11:00:23'),
(157, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-14 11:03:14', '2026-08-14 11:03:14'),
(158, 13, 'tim1', 'Teknisi Jointer', 'LOGIN', 'Authentication', 'Pengguna tim1 (Teknisi Jointer) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":13,"username":"tim1","role":"Teknisi Jointer","division":"Operasional Fiber"}', '2026-08-14 11:03:20', '2026-08-14 11:03:20'),
(159, 13, 'tim1', 'Teknisi Jointer', 'LOGIN', 'Authentication', 'Pengguna tim1 (Teknisi Jointer) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":13,"username":"tim1","role":"Teknisi Jointer","division":"Operasional Fiber"}', '2026-08-14 11:04:58', '2026-08-14 11:04:58'),
(160, 13, 'tim1', 'Teknisi Jointer', 'LOGOUT', 'Authentication', 'Pengguna tim1 telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-14 11:05:12', '2026-08-14 11:05:12'),
(161, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-14 11:05:18', '2026-08-14 11:05:18'),
(162, 13, 'tim1', 'Teknisi Jointer', 'UPDATE', 'Pengaturan Profil', 'Pengguna tim1 memperbarui data profil pribadinya.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"name":"tim1","email":"tim1@gmail.com","phone":"08888888888","username":"tim1"}', '{"name":"tim1","email":"tim1@gmail.com","phone":"08888888888","username":"tim1"}', '2026-08-14 11:06:38', '2026-08-14 11:06:38'),
(163, 13, 'tim1', 'Teknisi Jointer', 'LOGOUT', 'Authentication', 'Pengguna tim1 telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-14 11:06:46', '2026-08-14 11:06:46'),
(164, 13, 'tim1', 'Teknisi Jointer', 'LOGOUT', 'Authentication', 'Pengguna tim1 telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-14 11:06:46', '2026-08-14 11:06:46'),
(165, 13, 'tim1', 'Teknisi Jointer', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''tim1'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"tim1","status":"FAILED"}', '2026-08-14 11:06:54', '2026-08-14 11:06:54'),
(166, 13, 'tim1', 'Teknisi Jointer', 'LOGIN', 'Authentication', 'Pengguna tim1 (Teknisi Jointer) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":13,"username":"tim1","role":"Teknisi Jointer","division":"Operasional Fiber"}', '2026-08-14 11:06:59', '2026-08-14 11:06:59'),
(167, 13, 'tim1', 'Teknisi Jointer', 'UPDATE', 'Pengaturan Profil', 'Pengguna tim1 memperbarui data profil pribadinya.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"name":"tim1","email":"tim1@gmail.com","phone":"08888888888","username":"tim1"}', '{"name":"tim1","email":"tim1@gmail.com","phone":"08888888888","username":"tim1"}', '2026-08-14 11:16:53', '2026-08-14 11:16:53'),
(168, 13, 'tim1', 'Teknisi Jointer', 'LOGOUT', 'Authentication', 'Pengguna tim1 telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-14 11:17:04', '2026-08-14 11:17:04'),
(169, 13, 'tim1', 'Teknisi Jointer', 'LOGIN', 'Authentication', 'Pengguna tim1 (Teknisi Jointer) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":13,"username":"tim1","role":"Teknisi Jointer","division":"Operasional Fiber"}', '2026-08-14 11:17:22', '2026-08-14 11:17:22'),
(170, 13, 'tim1', 'Teknisi Jointer', 'UPDATE', 'Pengaturan Profil', 'Pengguna tim1 memperbarui data profil pribadinya.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"name":"tim1","email":"tim1@gmail.com","phone":"08888888888","username":"tim1"}', '{"name":"tim1","email":"tim1@gmail.com","phone":"08888888888","username":"tim1"}', '2026-08-14 11:19:04', '2026-08-14 11:19:04'),
(171, 13, 'tim1', 'Teknisi Jointer', 'LOGOUT', 'Authentication', 'Pengguna tim1 telah keluar (logout) dari sistem Fiber-UNMS.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"status":"LOGGED_OUT"}', '2026-08-14 11:19:06', '2026-08-14 11:19:06'),
(172, 13, 'tim1', 'Teknisi Jointer', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''tim1'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"tim1","status":"FAILED"}', '2026-08-14 11:19:44', '2026-08-14 11:19:44'),
(173, 13, 'tim1', 'Teknisi Jointer', 'LOGIN', 'Authentication', 'Pengguna tim1 (Teknisi Jointer) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":13,"username":"tim1","role":"Teknisi Jointer","division":"Operasional Fiber"}', '2026-08-14 11:19:48', '2026-08-14 11:19:48'),
(174, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-14 13:04:49', '2026-08-14 13:04:49'),
(175, NULL, 'Super Administrator', 'Super Administrator', 'TEST', 'Pusat Notifikasi', 'Pengguna User menguji notifikasi perangkat.', '127.0.0.1', 'Symfony', NULL, '{"notification_id":1}', '2026-08-14 14:22:05', '2026-08-14 14:22:05'),
(176, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-14 14:22:45', '2026-08-14 14:22:45'),
(177, 10, 'Jasen', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-14 14:25:09', '2026-08-14 14:25:09'),
(178, NULL, 'Super Administrator', 'Super Administrator', 'TEST', 'Pusat Notifikasi', 'Pengguna User menguji notifikasi perangkat.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"notification_id":2}', '2026-08-14 14:26:17', '2026-08-14 14:26:17'),
(179, 13, 'tim1', 'Teknisi Jointer', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''tim1'' (Password salah atau user tidak ditemukan).', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', NULL, '{"attempt_username":"tim1","status":"FAILED"}', '2026-08-14 14:27:53', '2026-08-14 14:27:53'),
(180, 13, 'tim1', 'Teknisi Jointer', 'LOGIN', 'Authentication', 'Pengguna tim1 (Teknisi Jointer) berhasil login ke sistem Fiber-UNMS Enterprise.', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', NULL, '{"user_id":13,"username":"tim1","role":"Teknisi Jointer","division":"Operasional Fiber"}', '2026-08-14 14:27:58', '2026-08-14 14:27:58'),
(181, NULL, 'Super Administrator', 'Super Administrator', 'TEST', 'Pusat Notifikasi', 'Pengguna User menguji notifikasi perangkat.', '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 26_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1', NULL, '{"notification_id":3}', '2026-08-14 14:30:50', '2026-08-14 14:30:50'),
(182, NULL, 'Super Administrator', 'Super Administrator', 'TEST', 'Pusat Notifikasi', 'Pengguna User menguji notifikasi perangkat.', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', NULL, '{"notification_id":4}', '2026-08-14 14:40:08', '2026-08-14 14:40:08'),
(183, NULL, 'Super Administrator', 'Super Administrator', 'TEST', 'Pusat Notifikasi', 'Pengguna User menguji notifikasi perangkat.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"notification_id":5}', '2026-08-14 14:40:47', '2026-08-14 14:40:47'),
(184, NULL, 'Super Administrator', 'Super Administrator', 'TEST', 'Pusat Notifikasi', 'Pengguna User menguji notifikasi perangkat.', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', NULL, '{"notification_id":6}', '2026-08-14 14:41:09', '2026-08-14 14:41:09'),
(185, NULL, 'Super Administrator', 'Super Administrator', 'TEST', 'Pusat Notifikasi', 'Pengguna User menguji notifikasi perangkat.', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', NULL, '{"notification_id":7}', '2026-08-14 14:41:30', '2026-08-14 14:41:30'),
(186, NULL, 'Super Administrator', 'Super Administrator', 'TEST', 'Pusat Notifikasi', 'Pengguna User menguji notifikasi perangkat.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"notification_id":8}', '2026-08-14 14:42:16', '2026-08-14 14:42:16'),
(187, NULL, 'Super Administrator', 'Super Administrator', 'TEST', 'Pusat Notifikasi', 'Pengguna User menguji notifikasi perangkat.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"notification_id":9}', '2026-08-14 14:42:34', '2026-08-14 14:42:34'),
(188, NULL, 'Super Administrator', 'Super Administrator', 'TEST', 'Pusat Notifikasi', 'Pengguna User menguji notifikasi perangkat.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"notification_id":11}', '2026-08-14 14:45:51', '2026-08-14 14:45:51'),
(189, NULL, 'Super Administrator', 'Super Administrator', 'TEST', 'Pusat Notifikasi', 'Pengguna User menguji notifikasi perangkat.', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', NULL, '{"notification_id":12}', '2026-08-14 14:46:32', '2026-08-14 14:46:32'),
(190, NULL, 'Super Administrator', 'Super Administrator', 'BROADCAST', 'Pusat Notifikasi', 'Pengiriman Notifikasi Massal oleh Administrator: 🚨 Perhatian: Pemeliharaan Sistem NOC Solok (Target: ALL)', '127.0.0.1', 'Symfony', NULL, '{"title":"\ud83d\udea8 Perhatian: Pemeliharaan Sistem NOC Solok","type":"NOC","target_role":"ALL","recipients":2}', '2026-08-14 14:47:14', '2026-08-14 14:47:14'),
(191, NULL, 'Super Administrator', 'Super Administrator', 'BROADCAST', 'Pusat Notifikasi', 'Pengiriman Notifikasi Massal oleh Administrator: Gangguan Putus Kabel Optik Segmen Solok (Target: ALL)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"title":"Gangguan Putus Kabel Optik Segmen Solok","type":"NOC","target_role":"ALL","recipients":2}', '2026-08-14 14:48:07', '2026-08-14 14:48:07'),
(192, NULL, 'Super Administrator', 'Super Administrator', 'BROADCAST', 'Pusat Notifikasi', 'Pengiriman Notifikasi Massal oleh Administrator: Gangguan Putus Kabel Optik Segmen Solok (Target: ALL)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"title":"Gangguan Putus Kabel Optik Segmen Solok","type":"NOC","target_role":"ALL","recipients":2}', '2026-08-14 14:50:30', '2026-08-14 14:50:30'),
(193, NULL, 'Super Administrator', 'Super Administrator', 'BROADCAST', 'Pusat Notifikasi', 'Pengiriman Notifikasi Massal oleh Administrator: Gangguan Putus Kabel Optik Segmen Solok (Target: ALL)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"title":"Gangguan Putus Kabel Optik Segmen Solok","type":"NOC","target_role":"ALL","recipients":2}', '2026-08-14 14:52:45', '2026-08-14 14:52:45'),
(194, NULL, 'Super Administrator', 'Super Administrator', 'TEST', 'Pusat Notifikasi', 'Pengguna User menguji notifikasi perangkat.', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', NULL, '{"notification_id":17}', '2026-08-14 14:53:07', '2026-08-14 14:53:07'),
(195, NULL, 'Super Administrator', 'Super Administrator', 'TEST', 'Pusat Notifikasi', 'Pengguna User menguji notifikasi perangkat.', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', NULL, '{"notification_id":18}', '2026-08-14 14:56:21', '2026-08-14 14:56:21'),
(196, NULL, 'Super Administrator', 'Super Administrator', 'TEST', 'Pusat Notifikasi', 'Pengguna User menguji notifikasi perangkat.', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', NULL, '{"notification_id":19}', '2026-08-14 14:56:57', '2026-08-14 14:56:57'),
(197, NULL, 'Super Administrator', 'Super Administrator', 'BROADCAST', 'Pusat Notifikasi', 'Pengiriman Notifikasi Massal oleh Administrator: Gangguan Putus Kabel Optik Segmen Solok (Target: ALL)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"title":"Gangguan Putus Kabel Optik Segmen Solok","type":"NOC","target_role":"ALL","recipients":2}', '2026-08-14 14:57:12', '2026-08-14 14:57:12'),
(198, NULL, 'Super Administrator', 'Super Administrator', 'TEST', 'Pusat Notifikasi', 'Pengguna User menguji notifikasi perangkat.', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', NULL, '{"notification_id":21}', '2026-08-14 14:57:30', '2026-08-14 14:57:30'),
(199, NULL, 'Super Administrator', 'Super Administrator', 'CREATE', 'Ticketing & Work Order', 'Membuat tiket gangguan baru TICK-2026-0001: asasd (Prioritas: Critical)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"ticket_number":"TICK-2026-0001","title":"asasd","priority":"Critical","status":"Open","technician":"asdasd"}', '2026-08-14 15:01:17', '2026-08-14 15:01:17'),
(200, NULL, 'Super Administrator', 'Super Administrator', 'UPDATE', 'Ticketing & Work Order', 'Memperbarui tiket gangguan TICK-2026-0001 - Status: In Progress', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', '{"title":"asasd","priority":"Critical","status":"Open","technician_name":"asdasd","resolution_notes":null}', '{"title":"asasd","priority":"Critical","status":"In Progress","technician_name":"asdasd","resolution_notes":null}', '2026-08-14 15:01:53', '2026-08-14 15:01:53'),
(201, NULL, 'Super Administrator', 'Super Administrator', 'UPDATE', 'Ticketing & Work Order', 'Memperbarui tiket gangguan TICK-2026-0001 - Status: In Progress', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"title":"asasd","priority":"Critical","status":"In Progress","technician_name":"asdasd","resolution_notes":null}', '{"title":"asasd","priority":"Critical","status":"In Progress","technician_name":"asdasd","resolution_notes":null}', '2026-08-14 15:03:39', '2026-08-14 15:03:39'),
(202, NULL, 'Super Administrator', 'Super Administrator', 'UPDATE', 'Ticketing & Work Order', 'Memperbarui tiket gangguan TICK-2026-0001 - Status: In Progress', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"title":"asasd","priority":"Critical","status":"In Progress","technician_name":"asdasd","resolution_notes":null}', '{"title":"asasd","priority":"Critical","status":"In Progress","technician_name":"asdasd","resolution_notes":"asdasdasdasd"}', '2026-08-14 15:04:03', '2026-08-14 15:04:03'),
(203, NULL, 'Super Administrator', 'Super Administrator', 'UPDATE', 'Ticketing & Work Order', 'Memperbarui tiket gangguan TICK-2026-0001 - Status: Resolved', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"title":"asasd","priority":"Critical","status":"In Progress","technician_name":"asdasd","resolution_notes":"asdasdasdasd"}', '{"title":"asasd","priority":"Critical","status":"Resolved","technician_name":"asdasd","resolution_notes":"asdasdasdasd"}', '2026-08-14 15:04:05', '2026-08-14 15:04:05'),
(204, NULL, 'Super Administrator', 'Super Administrator', 'DELETE', 'Ticketing & Work Order', 'Menghapus tiket gangguan TICK-2026-0001 - asasd', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"ticket_number":"TICK-2026-0001","title":"asasd","status":"Resolved","priority":"Critical"}', NULL, '2026-08-14 15:04:24', '2026-08-14 15:04:24'),
(205, NULL, 'Super Administrator', 'Super Administrator', 'BROADCAST', 'Pusat Notifikasi', 'Pengiriman Notifikasi Massal oleh Administrator: Gangguan Putus Kabel Optik Segmen Solok (Target: ALL)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"title":"Gangguan Putus Kabel Optik Segmen Solok","type":"NOC","target_role":"ALL","recipients":2}', '2026-08-14 15:49:25', '2026-08-14 15:49:25');

INSERT INTO "audit_logs" ("id", "user_id", "user_name", "user_role", "action", "module", "description", "ip_address", "user_agent", "old_values", "new_values", "created_at", "updated_at") VALUES
(206, NULL, 'Super Administrator', 'Super Administrator', 'TEST', 'Pusat Notifikasi', 'Pengguna User menguji notifikasi perangkat.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"notification_id":24}', '2026-08-14 15:50:12', '2026-08-14 15:50:12'),
(207, NULL, 'Super Administrator', 'Super Administrator', 'BROADCAST', 'Pusat Notifikasi', 'Pengiriman Notifikasi Massal oleh Administrator: Gangguan Putus Kabel Optik Segmen Solok (Target: ALL)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"title":"Gangguan Putus Kabel Optik Segmen Solok","type":"NOC","target_role":"ALL","recipients":2}', '2026-08-14 15:50:25', '2026-08-14 15:50:25'),
(208, NULL, 'Super Administrator', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan', 'Perbarui node ODP: ODP 0001 (ODP-SLK-0001)', '127.0.0.1', 'Symfony', NULL, '{"name":"ODP 0001","code":"ODP-SLK-0001","node_type":"ODP","status":"active"}', '2026-08-15 13:47:37', '2026-08-15 13:47:37'),
(209, NULL, 'Super Administrator', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan', 'Perbarui node ODP: ODP 0001 (ODP-SLK-0001)', '127.0.0.1', 'Symfony', NULL, '{"name":"ODP 0001","code":"ODP-SLK-0001","node_type":"ODP","status":"active"}', '2026-08-15 13:47:50', '2026-08-15 13:47:50'),
(210, NULL, 'Super Administrator', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan', 'Perbarui node ODC: ODC 01 (ODC-SLK-01)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"name":"ODC 01","code":"ODC-SLK-01","node_type":"ODC","model":null,"status":"active","latitude":-0.7839611111111111,"longitude":100.65491111111112,"address":"KP JAWA","parent_node_id":1,"olt_device_id":13,"olt_port_ref":"gpon-olt_1\/1\/1","total_ports":68,"used_ports":2,"core_power":"Biru, Orange, Hijau, Coklat, Abu","core_color":null,"splitter_config":["POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4"],"tube_info":"Tube 1 (Biru)","splitter_count":17,"odc_topology_type":"induk"}', '2026-08-15 13:49:36', '2026-08-15 13:49:36'),
(211, NULL, 'Super Administrator', 'Super Administrator', 'CREATE', 'OLT Management', 'Menambahkan perangkat OLT baru asdasd (ASDASD) - IP: 192.168.1.1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"name":"asdasd","code":"ASDASD","vendor":"ZTE","model":"ZXAN C300","vendor_key":"zte","location":"asdasd","ip_address":"192.168.1.1","total_ports":16,"deployment_mode":"direct","snmp_version":"v2c","snmp_community_type":"public","snmp_v3_username":null,"snmp_v3_auth_protocol":"SHA","snmp_v3_priv_protocol":"AES","snmp_port":161,"cli_protocol":"telnet","cli_username":null,"cli_port":23,"probe_agent_url":null,"status":"active","connection_mode":"simulation","updated_at":"2026-08-15T13:56:56.000000Z","created_at":"2026-08-15T13:56:56.000000Z","id":17}', '2026-08-15 13:56:56', '2026-08-15 13:56:56'),
(212, NULL, 'Super Administrator', 'Super Administrator', 'CREATE', 'Infrastruktur Jaringan', 'Membuat node POP baru: asasd (POP-ASA-01)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"name":"asasd","code":"POP-ASA-01","node_type":"POP","model":null,"status":"active","latitude":"-0.7878869","longitude":"100.6570184","address":"asdasd","parent_node_id":null,"olt_device_id":17,"olt_port_ref":null,"total_ports":144,"used_ports":0,"core_power":null,"core_color":null,"splitter_config":null,"tube_info":null,"splitter_count":0,"odc_topology_type":"tunggal","updated_at":"2026-08-15T13:59:50.000000Z","created_at":"2026-08-15T13:59:50.000000Z","id":26,"splitter_type":null}', '2026-08-15 13:59:50', '2026-08-15 13:59:50'),
(213, NULL, 'Budi Operator', 'Operator Jaringan', 'UPDATE', 'Customer Management', 'Pengujian Nama Operator Telegram', '127.0.0.1', 'Symfony', '{"phone":"0811223344"}', '{"phone":"0899887766"}', '2026-08-15 14:01:48', '2026-08-15 14:01:48'),
(214, NULL, 'Super Administrator', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan', 'Perbarui node POP: asasderteter (POP-ASA-01)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"name":"asasderteter","code":"POP-ASA-01","node_type":"POP","model":null,"status":"active","latitude":-0.7878861111111111,"longitude":100.65701944444444,"address":"asdasd","parent_node_id":null,"olt_device_id":17,"olt_port_ref":null,"total_ports":144,"used_ports":0,"core_power":null,"core_color":null,"splitter_config":null,"tube_info":null,"splitter_count":0,"odc_topology_type":"tunggal"}', '2026-08-15 14:02:23', '2026-08-15 14:02:23'),
(215, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan', 'Perbarui node POP: asasderteterasdasd (POP-ASA-01)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"name":"asasderteterasdasd","code":"POP-ASA-01","node_type":"POP","model":null,"status":"active","latitude":-0.7878861111111111,"longitude":100.65701944444444,"address":"asdasd","parent_node_id":null,"olt_device_id":17,"olt_port_ref":null,"total_ports":144,"used_ports":0,"core_power":null,"core_color":null,"splitter_config":null,"tube_info":null,"splitter_count":0,"odc_topology_type":"tunggal"}', '2026-08-15 14:02:48', '2026-08-15 14:02:48'),
(216, 10, 'Jasen', 'Super Administrator', 'DELETE', 'Infrastruktur Jaringan', 'Menghapus node POP: asasderteterasdasd (POP-ASA-01)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"name":"asasderteterasdasd","code":"POP-ASA-01","type":"POP"}', NULL, '2026-08-15 15:48:57', '2026-08-15 15:48:57'),
(217, 10, 'Jasen', 'Super Administrator', 'TEST', 'Pusat Notifikasi', 'Pengguna User menguji notifikasi perangkat.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"notification_id":26}', '2026-08-15 15:54:59', '2026-08-15 15:54:59'),
(218, 10, 'Jasen', 'Super Administrator', 'BROADCAST', 'Pusat Notifikasi', 'Pengiriman Notifikasi Massal oleh Administrator: 🚨 Gangguan Putus Kabel Optik Segmen Solok (Target: ALL)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"title":"\ud83d\udea8 Gangguan Putus Kabel Optik Segmen Solok","type":"NOC","target_role":"ALL","recipients":2}', '2026-08-15 15:57:29', '2026-08-15 15:57:29'),
(219, 10, 'Jasen', 'Super Administrator', 'CREATE', 'OLT Management', 'Menambahkan perangkat OLT baru asdas (DASDASD) - IP: 1.1.1.1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"name":"asdas","code":"DASDASD","vendor":"ZTE","model":"ZXAN C300","vendor_key":"zte","location":"asdasd","ip_address":"1.1.1.1","total_ports":16,"deployment_mode":"direct","snmp_version":"v2c","snmp_community_type":"public","snmp_v3_username":null,"snmp_v3_auth_protocol":"SHA","snmp_v3_priv_protocol":"AES","snmp_port":161,"cli_protocol":"telnet","cli_username":null,"cli_port":23,"probe_agent_url":null,"status":"active","connection_mode":"simulation","updated_at":"2026-08-15T15:58:58.000000Z","created_at":"2026-08-15T15:58:58.000000Z","id":18}', '2026-08-15 15:58:58', '2026-08-15 15:58:58'),
(220, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Pusat Notifikasi', 'Memperbarui grup channel Telegram: Grup Utama NOC & Sistem (1596876497)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"id":1,"name":"Grup Utama NOC & Sistem","chat_id":"1596876497","topics":["NOC","TICKET","CUSTOMER","INFRASTRUCTURE","OLT_MGMT","USER_MGMT","BROADCAST","BILLING"],"is_active":true,"description":"Channel default untuk seluruh notifikasi sistem UNMS","created_at":"2026-08-15T15:53:14.000000Z","updated_at":"2026-08-15T15:53:14.000000Z"}', '{"id":1,"name":"Grup Utama NOC & Sistem","chat_id":"1596876497","topics":["NOC","TICKET","CUSTOMER","INFRASTRUCTURE","OLT_MGMT","USER_MGMT","BROADCAST","BILLING"],"is_active":false,"description":"Channel default untuk seluruh notifikasi sistem UNMS","created_at":"2026-08-15T15:53:14.000000Z","updated_at":"2026-08-15T16:04:33.000000Z"}', '2026-08-15 16:04:33', '2026-08-15 16:04:33'),
(221, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Pusat Notifikasi', 'Memperbarui grup channel Telegram: Grup Utama NOC & Sistem (1596876497)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"id":1,"name":"Grup Utama NOC & Sistem","chat_id":"1596876497","topics":["NOC","TICKET","CUSTOMER","INFRASTRUCTURE","OLT_MGMT","USER_MGMT","BROADCAST","BILLING"],"is_active":false,"description":"Channel default untuk seluruh notifikasi sistem UNMS","created_at":"2026-08-15T15:53:14.000000Z","updated_at":"2026-08-15T16:04:33.000000Z"}', '{"id":1,"name":"Grup Utama NOC & Sistem","chat_id":"1596876497","topics":["NOC","TICKET","CUSTOMER","INFRASTRUCTURE","OLT_MGMT","USER_MGMT","BROADCAST","BILLING"],"is_active":false,"description":"Channel default untuk seluruh notifikasi sistem UNMS","created_at":"2026-08-15T15:53:14.000000Z","updated_at":"2026-08-15T16:04:33.000000Z"}', '2026-08-15 16:04:37', '2026-08-15 16:04:37'),
(222, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Pusat Notifikasi', 'Memperbarui grup channel Telegram: Grup Utama NOC & Sistem (1596876497)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"id":1,"name":"Grup Utama NOC & Sistem","chat_id":"1596876497","topics":["NOC","TICKET","CUSTOMER","INFRASTRUCTURE","OLT_MGMT","USER_MGMT","BROADCAST","BILLING"],"is_active":false,"description":"Channel default untuk seluruh notifikasi sistem UNMS","created_at":"2026-08-15T15:53:14.000000Z","updated_at":"2026-08-15T16:04:33.000000Z"}', '{"id":1,"name":"Grup Utama NOC & Sistem","chat_id":"1596876497","topics":["NOC","TICKET","CUSTOMER","INFRASTRUCTURE","OLT_MGMT","USER_MGMT","BROADCAST","BILLING"],"is_active":false,"description":"Channel default untuk seluruh notifikasi sistem UNMS","created_at":"2026-08-15T15:53:14.000000Z","updated_at":"2026-08-15T16:04:33.000000Z"}', '2026-08-15 16:04:38', '2026-08-15 16:04:38'),
(223, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Pusat Notifikasi', 'Memperbarui grup channel Telegram: Grup Utama NOC & Sistem (1596876497)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"id":1,"name":"Grup Utama NOC & Sistem","chat_id":"1596876497","topics":["NOC","TICKET","CUSTOMER","INFRASTRUCTURE","OLT_MGMT","USER_MGMT","BROADCAST","BILLING"],"is_active":false,"description":"Channel default untuk seluruh notifikasi sistem UNMS","created_at":"2026-08-15T15:53:14.000000Z","updated_at":"2026-08-15T16:04:33.000000Z"}', '{"id":1,"name":"Grup Utama NOC & Sistem","chat_id":"1596876497","topics":["NOC","TICKET","CUSTOMER","INFRASTRUCTURE","OLT_MGMT","USER_MGMT","BROADCAST","BILLING"],"is_active":true,"description":"Channel default untuk seluruh notifikasi sistem UNMS","created_at":"2026-08-15T15:53:14.000000Z","updated_at":"2026-08-15T16:05:28.000000Z"}', '2026-08-15 16:05:28', '2026-08-15 16:05:28'),
(224, 10, 'Jasen', 'Super Administrator', 'CREATE', 'Pusat Notifikasi', 'Menambahkan grup channel Telegram baru: asdasd (24234234)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"name":"asdasd","chat_id":"24234234","topics":["NOC"],"is_active":true,"description":null,"updated_at":"2026-08-15T16:06:54.000000Z","created_at":"2026-08-15T16:06:54.000000Z","id":2}', '2026-08-15 16:06:54', '2026-08-15 16:06:54'),
(225, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Pusat Notifikasi', 'Memperbarui grup channel Telegram: asdasd (24234234)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"id":2,"name":"asdasd","chat_id":"24234234","topics":["NOC"],"is_active":true,"description":null,"created_at":"2026-08-15T16:06:54.000000Z","updated_at":"2026-08-15T16:06:54.000000Z"}', '{"id":2,"name":"asdasd","chat_id":"24234234","topics":["NOC"],"is_active":false,"description":null,"created_at":"2026-08-15T16:06:54.000000Z","updated_at":"2026-08-15T16:07:19.000000Z"}', '2026-08-15 16:07:19', '2026-08-15 16:07:19'),
(226, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Pusat Notifikasi', 'Memperbarui grup channel Telegram: asdasd (24234234)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"id":2,"name":"asdasd","chat_id":"24234234","topics":["NOC"],"is_active":false,"description":null,"created_at":"2026-08-15T16:06:54.000000Z","updated_at":"2026-08-15T16:07:19.000000Z"}', '{"id":2,"name":"asdasd","chat_id":"24234234","topics":["NOC"],"is_active":true,"description":null,"created_at":"2026-08-15T16:06:54.000000Z","updated_at":"2026-08-15T16:07:26.000000Z"}', '2026-08-15 16:07:26', '2026-08-15 16:07:26'),
(227, 10, 'Jasen', 'Super Administrator', 'DELETE', 'Pusat Notifikasi', 'Menghapus grup channel Telegram: asdasd (24234234)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"name":"asdasd","chat_id":"24234234"}', NULL, '2026-08-15 16:07:42', '2026-08-15 16:07:42'),
(228, NULL, 'Super Administrator', 'Super Administrator', 'UPDATE', 'Customer Management', 'Speed Test Non-Blocking Dispatch', '127.0.0.1', 'Symfony', '{"name":"Old"}', '{"name":"New"}', '2026-08-15 16:10:08', '2026-08-15 16:10:08'),
(229, 10, 'Jasen', 'Super Administrator', 'CREATE', 'OLT Management', 'Menambahkan perangkat OLT baru asdasd (ASDASD) - IP: 1.1.1.1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"name":"asdasd","code":"ASDASD","vendor":"ZTE","model":"ZXAN C300","vendor_key":"zte","location":"asdasd","ip_address":"1.1.1.1","total_ports":16,"deployment_mode":"direct","snmp_version":"v2c","snmp_community_type":"public","snmp_v3_username":null,"snmp_v3_auth_protocol":"SHA","snmp_v3_priv_protocol":"AES","snmp_port":161,"cli_protocol":"telnet","cli_username":null,"cli_port":23,"probe_agent_url":null,"status":"active","connection_mode":"simulation","updated_at":"2026-08-15T16:12:21.000000Z","created_at":"2026-08-15T16:12:21.000000Z","id":19}', '2026-08-15 16:12:21', '2026-08-15 16:12:21'),
(230, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'OLT Management', 'Perbarui data perangkat OLT asdasd (ASDASD)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"name":"asdasd","code":"ASDASD","ip_address":"1.1.1.1","location":"asdasd","total_ports":16}', '{"name":"asdasd","code":"ASDASD","vendor":"ZTE","model":"ZXAN C300","location":"asdasdasdasd","ip_address":"1.1.1.1","total_ports":16,"deployment_mode":"direct","snmp_version":"v2c","snmp_community_type":"public"}', '2026-08-15 16:12:51', '2026-08-15 16:12:51'),
(231, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan', 'Perbarui node POP: POP KANTOR CINOXa (POP-01)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"name":"POP KANTOR CINOXa","code":"POP-01","node_type":"POP","model":null,"status":"active","latitude":-0.7864416666666667,"longitude":100.65393333333334,"address":"KANTOR CINOX MEDIA NETWORK","parent_node_id":null,"olt_device_id":13,"olt_port_ref":null,"total_ports":16,"used_ports":0,"core_power":null,"core_color":null,"splitter_config":null,"tube_info":null,"splitter_count":0,"odc_topology_type":"tunggal"}', '2026-08-15 16:13:18', '2026-08-15 16:13:18'),
(232, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan', 'Perbarui node POP: POP KANTOR CINOX (POP-01)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"name":"POP KANTOR CINOX","code":"POP-01","node_type":"POP","model":null,"status":"active","latitude":-0.7864416666666667,"longitude":100.65393333333334,"address":"KANTOR CINOX MEDIA NETWORK","parent_node_id":null,"olt_device_id":13,"olt_port_ref":null,"total_ports":16,"used_ports":0,"core_power":null,"core_color":null,"splitter_config":null,"tube_info":null,"splitter_count":0,"odc_topology_type":"tunggal"}', '2026-08-15 16:13:53', '2026-08-15 16:13:53'),
(233, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan', 'Perbarui node ODP: ODP 0001a (ODP-SLK-0001)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"name":"ODP 0001a","code":"ODP-SLK-0001","node_type":"ODP","model":null,"status":"active","latitude":-0.7849888888888888,"longitude":100.65440833333334,"address":"KP JAWA","parent_node_id":15,"olt_device_id":13,"olt_port_ref":"gpon-olt_1\/1\/1","total_ports":8,"used_ports":1,"core_power":null,"core_color":"Biru","splitter_config":["1:8"],"tube_info":"Tube 1 (Biru)","splitter_count":1,"odc_topology_type":"tunggal"}', '2026-08-15 16:14:21', '2026-08-15 16:14:21'),
(234, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan', 'Perbarui node ODP: ODP 0001 (ODP-SLK-0001)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"name":"ODP 0001","code":"ODP-SLK-0001","node_type":"ODP","model":null,"status":"active","latitude":-0.7849888888888888,"longitude":100.65440833333334,"address":"KP JAWA","parent_node_id":15,"olt_device_id":13,"olt_port_ref":"gpon-olt_1\/1\/1","total_ports":8,"used_ports":1,"core_power":null,"core_color":"Biru","splitter_config":["1:8"],"tube_info":"Tube 1 (Biru)","splitter_count":1,"odc_topology_type":"tunggal"}', '2026-08-15 16:14:40', '2026-08-15 16:14:40'),
(235, NULL, 'Super Administrator', 'Super Administrator', 'OTDR_TRACE', 'OTDR Tracing', 'Eksekusi penembakan laser OTDR - Jarak terdeteksi: 650 meter', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"distance_meters":650,"cable_id":"12","break_coords":null,"nearest_node":null}', '2026-08-15 16:22:27', '2026-08-15 16:22:27'),
(236, NULL, 'Super Administrator', 'Super Administrator', 'OTDR_TRACE', 'OTDR Tracing', 'Eksekusi penembakan laser OTDR - Jarak terdeteksi: 650 meter', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"distance_meters":650,"cable_id":"12","break_coords":null,"nearest_node":null}', '2026-08-15 16:23:04', '2026-08-15 16:23:04'),
(237, 10, 'Jasen', 'Super Administrator', 'CREATE', 'Ticketing & Work Order', 'Membuat tiket gangguan baru TICK-2026-0001: sdasd (Prioritas: High)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"ticket_number":"TICK-2026-0001","title":"sdasd","priority":"High","status":"Open","technician":"asdd"}', '2026-08-15 16:30:02', '2026-08-15 16:30:02'),
(238, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Ticketing & Work Order', 'Memperbarui tiket gangguan TICK-2026-0001 - Status: In Progress', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"title":"sdasd","priority":"High","status":"Open","technician_name":"asdd","resolution_notes":null}', '{"title":"sdasd","priority":"High","status":"In Progress","technician_name":"asdd","resolution_notes":null}', '2026-08-15 16:30:37', '2026-08-15 16:30:37'),
(239, NULL, 'Super Administrator', 'Super Administrator', 'UPDATE', 'Customer Management', 'Audit Engine Full Verification', '127.0.0.1', 'Symfony', '{"nama":"Budi Santoso","paket":"100 Mbps","status":"Pending"}', '{"nama":"Budi Santoso","paket":"200 Mbps Fiber Ultra","status":"Active"}', '2026-08-15 16:30:58', '2026-08-15 16:30:58'),
(240, NULL, 'Super Administrator', 'Super Administrator', 'CREATE', 'Customer Management', 'Registrasi Pelanggan Baru: Budi Santoso (CUST-2026-089)', '127.0.0.1', 'Symfony', NULL, '{"name":"Budi Santoso","customer_number":"CUST-2026-089","phone":"08123456789","package_name":"Fiber Home 50 Mbps","odp_code":"ODP-SLK-01"}', '2026-08-15 16:35:46', '2026-08-15 16:35:46'),
(241, NULL, 'Super Administrator', 'Super Administrator', 'UPDATE', 'Customer Management', 'Pembaruan Paket Layanan Pelanggan: Budi Santoso', '127.0.0.1', 'Symfony', '{"package_name":"Fiber Home 50 Mbps","status":"Suspended"}', '{"package_name":"Fiber Ultra 100 Mbps","status":"Active"}', '2026-08-15 16:35:48', '2026-08-15 16:35:48'),
(242, NULL, 'Super Administrator', 'Super Administrator', 'DELETE', 'Customer Management', 'Penghapusan Data Pelanggan: CUST-2026-089', '127.0.0.1', 'Symfony', '{"name":"Budi Santoso","customer_number":"CUST-2026-089","phone":"08123456789"}', NULL, '2026-08-15 16:35:50', '2026-08-15 16:35:50'),
(243, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan', 'Perbarui node ODC: ODC 01a (ODC-SLK-01)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"name":"ODC 01a","code":"ODC-SLK-01","node_type":"ODC","model":null,"status":"active","latitude":-0.7839611111111111,"longitude":100.65491111111112,"address":"KP JAWA","parent_node_id":1,"olt_device_id":13,"olt_port_ref":"gpon-olt_1\/1\/1","total_ports":68,"used_ports":2,"core_power":"Biru, Orange, Hijau, Coklat, Abu","core_color":null,"splitter_config":["POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4"],"tube_info":"Tube 1 (Biru)","splitter_count":17,"odc_topology_type":"induk"}', '2026-08-15 16:36:36', '2026-08-15 16:36:36'),
(244, NULL, 'Super Administrator', 'Super Administrator', 'CREATE', 'Infrastruktur Jaringan ODP', 'Penambahan ODP Baru ODP 807', '127.0.0.1', 'Symfony', NULL, '{"name":"ODP 807","tube_info":"FIGURE","core_color":"COKLAT","core_power":"ODC 36","olt_port_ref":"1\/5\/14","device_type":"ODP 8 PORT","status":"ON","address":"PERUMAHAN BILQIS TRANSAD KEL.KAMPUNG JAWA KEC.TANJUNG HARAPAN KOTA SOLOK","total_ports":"8 pelanggan"}', '2026-08-15 16:38:42', '2026-08-15 16:38:42'),
(245, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan', 'Perbarui node ODC: ODC 01 (ODC-SLK-01)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"name":"ODC 01","code":"ODC-SLK-01","node_type":"ODC","model":null,"status":"active","latitude":-0.7839611111111111,"longitude":100.65491111111112,"address":"KP JAWA","parent_node_id":1,"olt_device_id":13,"olt_port_ref":"gpon-olt_1\/1\/1","total_ports":68,"used_ports":2,"core_power":"Biru, Orange, Hijau, Coklat, Abu","core_color":null,"splitter_config":["POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4"],"tube_info":"Tube 1 (Biru)","splitter_count":17,"odc_topology_type":"induk"}', '2026-08-15 16:39:53', '2026-08-15 16:39:53'),
(246, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan', 'Perbarui node ODP: ODP 0001a (ODP-SLK-0001)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"name":"ODP 0001a","code":"ODP-SLK-0001","node_type":"ODP","model":null,"status":"active","latitude":-0.7849888888888888,"longitude":100.65440833333334,"address":"KP JAWA","parent_node_id":15,"olt_device_id":13,"olt_port_ref":"gpon-olt_1\/1\/1","total_ports":8,"used_ports":1,"core_power":null,"core_color":"Biru","splitter_config":["1:8"],"tube_info":"Tube 1 (Biru)","splitter_count":1,"odc_topology_type":"tunggal"}', '2026-08-15 16:40:33', '2026-08-15 16:40:33'),
(247, NULL, 'Super Administrator', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan ODP', 'Perbarui ODP 01', '127.0.0.1', 'Symfony', '{"name":"ODP 01","code":"ODP-01","parent_node_id":12,"status":"active","address":"Jl. Sudirman Lama"}', '{"name":"ODP 001","code":"ODP-001","parent_node_id":12,"status":"active","address":"Jl. Sudirman No. 45 Baru"}', '2026-08-15 16:43:03', '2026-08-15 16:43:03'),
(248, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan', 'Perbarui node ODP: ODP 0001 (ODP-SLK-0001)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"name":"ODP 0001a","code":"ODP-SLK-0001","node_type":"ODP","model":null,"status":"active","latitude":"-0.7849889","longitude":"100.6544083","address":"KP JAWA","parent_node_id":15,"olt_device_id":13,"olt_port_ref":"gpon-olt_1\/1\/1","total_ports":8,"used_ports":1,"core_power":null,"core_color":"Biru","splitter_config":["1:8"],"tube_info":"Tube 1 (Biru)","splitter_count":1,"odc_topology_type":"tunggal"}', '{"name":"ODP 0001","code":"ODP-SLK-0001","node_type":"ODP","model":null,"status":"active","latitude":-0.7849888888888888,"longitude":100.65440833333334,"address":"KP JAWA","parent_node_id":15,"olt_device_id":13,"olt_port_ref":"gpon-olt_1\/1\/1","total_ports":8,"used_ports":1,"core_power":null,"core_color":"Biru","splitter_config":["1:8"],"tube_info":"Tube 1 (Biru)","splitter_count":1,"odc_topology_type":"tunggal"}', '2026-08-15 16:43:35', '2026-08-15 16:43:35'),
(249, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan', 'Perbarui node ODC: ODC 01a (ODC-SLK-01)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"name":"ODC 01","code":"ODC-SLK-01","node_type":"ODC","model":null,"status":"active","latitude":"-0.7839611","longitude":"100.6549111","address":"KP JAWA","parent_node_id":1,"olt_device_id":13,"olt_port_ref":"gpon-olt_1\/1\/1","total_ports":68,"used_ports":2,"core_power":"Biru, Orange, Hijau, Coklat, Abu","core_color":null,"splitter_config":["POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4"],"tube_info":"Tube 1 (Biru)","splitter_count":17,"odc_topology_type":"induk"}', '{"name":"ODC 01a","code":"ODC-SLK-01","node_type":"ODC","model":null,"status":"active","latitude":-0.7839611111111111,"longitude":100.65491111111112,"address":"KP JAWA","parent_node_id":1,"olt_device_id":13,"olt_port_ref":"gpon-olt_1\/1\/1","total_ports":68,"used_ports":2,"core_power":"Biru, Orange, Hijau, Coklat, Abu","core_color":null,"splitter_config":["POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4"],"tube_info":"Tube 1 (Biru)","splitter_count":17,"odc_topology_type":"induk"}', '2026-08-15 16:44:47', '2026-08-15 16:44:47'),
(250, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan', 'Perbarui node ODC: ODC 01a (ODC-SLK-01)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"name":"ODC 01a","code":"ODC-SLK-01","node_type":"ODC","model":null,"status":"active","latitude":"-0.7839611","longitude":"100.6549111","address":"KP JAWA","parent_node_id":1,"olt_device_id":13,"olt_port_ref":"gpon-olt_1\/1\/1","total_ports":68,"used_ports":2,"core_power":"Biru, Orange, Hijau, Coklat, Abu","core_color":null,"splitter_config":["POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4"],"tube_info":"Tube 1 (Biru)","splitter_count":17,"odc_topology_type":"induk"}', '{"name":"ODC 01a","code":"ODC-SLK-01","node_type":"ODC","model":null,"status":"active","latitude":-0.7839611111111111,"longitude":100.65491111111112,"address":"KP JAWA","parent_node_id":1,"olt_device_id":13,"olt_port_ref":"gpon-olt_1\/1\/1","total_ports":64,"used_ports":2,"core_power":"Biru, Orange, Hijau, Coklat, Abu","core_color":null,"splitter_config":["POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4"],"tube_info":"Tube 1 (Biru)","splitter_count":16,"odc_topology_type":"induk"}', '2026-08-15 16:46:07', '2026-08-15 16:46:07'),
(251, NULL, 'Super Administrator', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan ODP', 'Edit ODP 01', '127.0.0.1', 'Symfony', '{"name":"ODP 01","latitude":-0.78928,"longitude":100.65432,"status":"active"}', '{"name":"ODP 001","latitude":-0.78928,"longitude":100.65432,"status":"active"}', '2026-08-15 16:46:24', '2026-08-15 16:46:24'),
(252, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan', 'Perbarui node ODC: ODC 01 (ODC-SLK-01)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"name":"ODC 01a","code":"ODC-SLK-01","node_type":"ODC","model":null,"status":"active","latitude":"-0.7839611","longitude":"100.6549111","address":"KP JAWA","parent_node_id":1,"olt_device_id":13,"olt_port_ref":"gpon-olt_1\/1\/1","total_ports":64,"used_ports":2,"core_power":"Biru, Orange, Hijau, Coklat, Abu","core_color":null,"splitter_config":["POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4"],"tube_info":"Tube 1 (Biru)","splitter_count":16,"odc_topology_type":"induk"}', '{"name":"ODC 01","code":"ODC-SLK-01","node_type":"ODC","model":null,"status":"active","latitude":-0.7839611111111111,"longitude":100.65491111111112,"address":"KP JAWA","parent_node_id":1,"olt_device_id":13,"olt_port_ref":"gpon-olt_1\/1\/1","total_ports":68,"used_ports":2,"core_power":"Biru, Orange, Hijau, Coklat, Abu","core_color":null,"splitter_config":["POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4"],"tube_info":"Tube 1 (Biru)","splitter_count":17,"odc_topology_type":"induk"}', '2026-08-15 16:47:15', '2026-08-15 16:47:15'),
(253, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan', 'Perbarui node ODC: ODC 01a (ODC-SLK-01)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"name":"ODC 01","code":"ODC-SLK-01","node_type":"ODC","model":null,"status":"active","latitude":"-0.7839611","longitude":"100.6549111","address":"KP JAWA","parent_node_id":1,"olt_device_id":13,"olt_port_ref":"gpon-olt_1\/1\/1","total_ports":68,"used_ports":2,"core_power":"Biru, Orange, Hijau, Coklat, Abu","core_color":null,"splitter_config":["POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4"],"tube_info":"Tube 1 (Biru)","splitter_count":17,"odc_topology_type":"induk"}', '{"name":"ODC 01a","code":"ODC-SLK-01","node_type":"ODC","model":null,"status":"active","latitude":-0.7839611111111111,"longitude":100.65491111111112,"address":"KP JAWA","parent_node_id":1,"olt_device_id":13,"olt_port_ref":"gpon-olt_1\/1\/1","total_ports":68,"used_ports":2,"core_power":"Biru, Orange, Hijau, Coklat, Abu","core_color":null,"splitter_config":["POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4"],"tube_info":"Tube 1 (Biru)","splitter_count":17,"odc_topology_type":"induk"}', '2026-08-15 16:55:18', '2026-08-15 16:55:18'),
(254, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'Infrastruktur Jaringan', 'Perbarui node ODC: ODC 01 (ODC-SLK-01)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"name":"ODC 01a","code":"ODC-SLK-01","node_type":"ODC","model":null,"status":"active","latitude":"-0.7839611","longitude":"100.6549111","address":"KP JAWA","parent_node_id":1,"olt_device_id":13,"olt_port_ref":"gpon-olt_1\/1\/1","total_ports":68,"used_ports":2,"core_power":"Biru, Orange, Hijau, Coklat, Abu","core_color":null,"splitter_config":["POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4"],"tube_info":"Tube 1 (Biru)","splitter_count":17,"odc_topology_type":"induk"}', '{"name":"ODC 01","code":"ODC-SLK-01","node_type":"ODC","model":null,"status":"active","latitude":-0.7839611111111111,"longitude":100.65491111111112,"address":"KP JAWA","parent_node_id":1,"olt_device_id":13,"olt_port_ref":"gpon-olt_1\/1\/1","total_ports":68,"used_ports":2,"core_power":"Biru, Orange, Hijau, Coklat, Abu","core_color":null,"splitter_config":["POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4"],"tube_info":"Tube 1 (Biru)","splitter_count":17,"odc_topology_type":"induk"}', '2026-08-15 16:56:04', '2026-08-15 16:56:04'),
(255, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen (Super Administrator) telah logout dari sistem.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen"}', '2026-08-15 17:23:50', '2026-08-15 17:23:50'),
(256, NULL, 'Super Administrator', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-15 17:24:12', '2026-08-15 17:24:12'),
(257, 10, 'Jasen', 'Super Administrator', 'UPDATE', 'OLT Management', 'Perbarui konfigurasi koneksi SNMP/CLI OLT OLT-SOLOK-ZTE C300 (OLT-SLK-O1)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"deployment_mode":"direct","snmp_version":"v2c","snmp_port":1611,"cli_protocol":"ssh"}', '{"deployment_mode":"direct","snmp_version":"v2c","snmp_port":1611,"cli_protocol":"ssh"}', '2026-08-15 17:36:50', '2026-08-15 17:36:50'),
(258, 10, 'Jasen', 'Super Administrator', 'TEST', 'OLT Management', 'Uji koneksi ke OLT OLT-SOLOK-ZTE C300 (OLT-SLK-O1) - Mode: simulation, Ping: 0ms', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"olt_name":"OLT-SOLOK-ZTE C300","code":"OLT-SLK-O1","ip_address":"10.10.10.2","connection_mode":"simulation","ping_latency_ms":null,"snmp_reachable":false}', '2026-08-15 17:37:10', '2026-08-15 17:37:10'),
(259, NULL, 'Super Administrator', 'Super Administrator', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''jasen'' (Password salah atau user tidak ditemukan).', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', NULL, '{"attempt_username":"jasen","status":"FAILED"}', '2026-08-15 17:39:24', '2026-08-15 17:39:24'),
(260, NULL, 'Super Administrator', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-15 17:39:35', '2026-08-15 17:39:35'),
(261, 10, 'Jasen', 'Super Administrator', 'CREATE', 'OLT Management', 'Menambahkan perangkat OLT baru asdasd (ASDASD) - IP: 1.1.1.1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"name":"asdasd","code":"ASDASD","vendor":"ZTE","model":"ZXAN C300","vendor_key":"zte","location":"asdsad","ip_address":"1.1.1.1","total_ports":16,"deployment_mode":"direct","snmp_version":"v2c","snmp_community_type":"public","snmp_v3_username":null,"snmp_v3_auth_protocol":"SHA","snmp_v3_priv_protocol":"AES","snmp_port":161,"cli_protocol":"telnet","cli_username":null,"cli_port":23,"probe_agent_url":null,"status":"active","connection_mode":"simulation","updated_at":"2026-08-15T17:49:00.000000Z","created_at":"2026-08-15T17:49:00.000000Z","id":20}', '2026-08-15 17:49:00', '2026-08-15 17:49:00'),
(262, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen (Super Administrator) telah logout dari sistem.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen"}', '2026-08-15 17:54:49', '2026-08-15 17:54:49'),
(263, NULL, 'Super Administrator', 'Super Administrator', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdasds'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdasds","status":"FAILED"}', '2026-08-15 17:54:57', '2026-08-15 17:54:57'),
(264, NULL, 'Super Administrator', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-15 17:55:19', '2026-08-15 17:55:19'),
(265, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen (Super Administrator) telah logout dari sistem.', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', NULL, '{"user_id":10,"username":"jasen"}', '2026-08-15 18:01:01', '2026-08-15 18:01:01'),
(266, NULL, 'Super Administrator', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna tim1 (Teknisi Jointer) berhasil login ke sistem Fiber-UNMS Enterprise.', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', NULL, '{"user_id":13,"username":"tim1","role":"Teknisi Jointer","division":"Operasional Fiber"}', '2026-08-15 18:01:10', '2026-08-15 18:01:10'),
(267, 10, 'Jasen', 'Super Administrator', 'OTDR_TRACE', 'OTDR Tracing', 'Eksekusi penembakan laser OTDR - Jarak terdeteksi: 650 meter', '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 26_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1', NULL, '{"distance_meters":650,"cable_id":"12","break_coords":null,"nearest_node":null}', '2026-08-16 11:22:09', '2026-08-16 11:22:09'),
(268, 10, 'Jasen', 'Super Administrator', 'DELETE', 'Pusat Notifikasi', 'Menghapus grup channel Telegram: Grup Utama NOC & Sistem (1596876497)', '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 26_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1', '{"name":"Grup Utama NOC & Sistem","chat_id":"1596876497"}', NULL, '2026-08-16 11:29:11', '2026-08-16 11:29:11'),
(269, NULL, 'Super Administrator', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna tim1 (Teknisi Jointer) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0', NULL, '{"user_id":13,"username":"tim1","role":"Teknisi Jointer","division":"Operasional Fiber"}', '2026-08-16 11:35:11', '2026-08-16 11:35:11'),
(270, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen (Super Administrator) telah logout dari sistem.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen"}', '2026-08-16 11:50:28', '2026-08-16 11:50:28'),
(271, NULL, 'Super Administrator', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-16 11:54:43', '2026-08-16 11:54:43'),
(272, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen (Super Administrator) telah logout dari sistem.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen"}', '2026-08-16 11:55:02', '2026-08-16 11:55:02'),
(273, NULL, 'Super Administrator', 'Super Administrator', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdas'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdas","status":"FAILED"}', '2026-08-16 12:05:21', '2026-08-16 12:05:21'),
(274, NULL, 'Super Administrator', 'Super Administrator', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''asdas'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"asdas","status":"FAILED"}', '2026-08-16 12:06:43', '2026-08-16 12:06:43'),
(275, NULL, 'Super Administrator', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-16 12:06:53', '2026-08-16 12:06:53'),
(276, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen (Super Administrator) telah logout dari sistem.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen"}', '2026-08-16 12:06:58', '2026-08-16 12:06:58'),
(277, NULL, 'Super Administrator', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-16 12:18:03', '2026-08-16 12:18:03'),
(278, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen (Super Administrator) telah logout dari sistem.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen"}', '2026-08-16 12:19:45', '2026-08-16 12:19:45'),
(279, NULL, 'Super Administrator', 'Super Administrator', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''bzbzja'' (Password salah atau user tidak ditemukan).', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', NULL, '{"attempt_username":"bzbzja","status":"FAILED"}', '2026-08-16 12:21:07', '2026-08-16 12:21:07'),
(280, NULL, 'Super Administrator', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-16 12:21:46', '2026-08-16 12:21:46'),
(281, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen (Super Administrator) telah logout dari sistem.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen"}', '2026-08-16 12:23:39', '2026-08-16 12:23:39'),
(282, NULL, 'Super Administrator', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-16 12:23:52', '2026-08-16 12:23:52'),
(314, 10, 'Jasen', 'Super Administrator', 'LOGOUT', 'Authentication', 'Pengguna Jasen (Super Administrator) telah logout dari sistem.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen"}', '2026-08-17 13:51:33', '2026-08-17 13:51:33'),
(315, NULL, 'Super Administrator', 'Super Administrator', 'LOGIN_FAILED', 'Authentication', 'Percobaan login gagal untuk username ''jasen'' (Password salah atau user tidak ditemukan).', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"attempt_username":"jasen","status":"FAILED"}', '2026-08-17 14:02:39', '2026-08-17 14:02:39'),
(316, NULL, 'Super Administrator', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-17 14:02:53', '2026-08-17 14:02:53'),
(317, 10, 'Jasen', 'Super Administrator', 'OTDR_TRACE', 'OTDR Tracing', 'Eksekusi penembakan OTDR dari ODC 01 [ODC] ke ODP 0001 [ODP] - Jarak: 100m (Dekat ODC 01 [ODC])', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"distance_meters":100,"cable_id":null,"start_node":"ODC 01 [ODC]","end_node":"ODP 0001 [ODP]","break_coords":{"lat":-0.784769,"lng":100.654516},"nearest_node":"ODC 01 [ODC]"}', '2026-08-17 14:19:19', '2026-08-17 14:19:19'),
(318, 10, 'Jasen', 'Super Administrator', 'OTDR_TRACE', 'OTDR Tracing', 'Eksekusi penembakan OTDR dari ODC 01 [ODC] ke ODP 0001 [ODP] - Jarak: 3384m (Dekat Tiang #73)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"distance_meters":3384,"cable_id":"12","start_node":"ODC 01 [ODC]","end_node":"ODP 0001 [ODP]","break_coords":{"lat":-0.814201,"lng":100.650678},"nearest_node":"Tiang #73"}', '2026-08-17 14:25:08', '2026-08-17 14:25:08'),
(319, 10, 'Jasen', 'Super Administrator', 'OTDR_TRACE', 'OTDR Tracing', 'Eksekusi penembakan OTDR dari ODC 01 [ODC] ke ODP 0001 [ODP] - Jarak: 56m (Dekat Kelokan Tiang Jalan #1)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"distance_meters":56,"cable_id":null,"start_node":"ODC 01 [ODC]","end_node":"ODP 0001 [ODP]","break_coords":{"lat":-0.784391,"lng":100.654635},"nearest_node":"Kelokan Tiang Jalan #1"}', '2026-08-17 14:27:55', '2026-08-17 14:27:55'),
(320, 10, 'Jasen', 'Super Administrator', 'OTDR_TRACE', 'OTDR Tracing', 'Eksekusi penembakan OTDR dari ODC 01 [ODC] ke ODP 0001 [ODP] - Jarak: 47m (Dekat Kelokan Tiang Jalan #1)', '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 26_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1', NULL, '{"distance_meters":47,"cable_id":null,"start_node":"ODC 01 [ODC]","end_node":"ODP 0001 [ODP]","break_coords":{"lat":-0.784002,"lng":100.654842},"nearest_node":"Kelokan Tiang Jalan #1"}', '2026-08-17 14:39:46', '2026-08-17 14:39:46'),
(321, NULL, 'Super Administrator', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-17 15:31:29', '2026-08-17 15:31:29'),
(322, NULL, 'Super Administrator', 'Super Administrator', 'LOGIN', 'Authentication', 'Pengguna Jasen (Super Administrator) berhasil login ke sistem Fiber-UNMS Enterprise.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"user_id":10,"username":"jasen","role":"Super Administrator","division":"TIM FO"}', '2026-08-17 15:44:40', '2026-08-17 15:44:40'),
(323, 10, 'Jasen', 'Super Administrator', 'CREATE', 'Infrastruktur Jaringan', 'Membuat node POP baru: asdasd (POP-ASD-01)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', NULL, '{"name":"asdasd","code":"POP-ASD-01","node_type":"POP","model":null,"status":"active","latitude":null,"longitude":null,"address":null,"parent_node_id":null,"olt_device_id":13,"olt_port_ref":null,"total_ports":16,"used_ports":0,"core_power":null,"core_color":null,"splitter_config":null,"tube_info":null,"splitter_count":0,"odc_topology_type":"tunggal","updated_at":"2026-08-17T15:56:53.000000Z","created_at":"2026-08-17T15:56:53.000000Z","id":32,"splitter_type":null}', '2026-08-17 15:56:53', '2026-08-17 15:56:53'),
(324, 10, 'Jasen', 'Super Administrator', 'DELETE', 'Infrastruktur Jaringan', 'Menghapus node POP: asdasd (POP-ASD-01)', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '{"name":"asdasd","code":"POP-ASD-01","type":"POP"}', NULL, '2026-08-17 15:57:09', '2026-08-17 15:57:09');

SELECT setval('public.audit_logs_id_seq', COALESCE((SELECT MAX("id") FROM "audit_logs"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "billing_invoices"
-- ----------------------------------------------------------

TRUNCATE TABLE "billing_invoices" CASCADE;

SELECT setval('public.billing_invoices_id_seq', COALESCE((SELECT MAX("id") FROM "billing_invoices"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "billing_payments"
-- ----------------------------------------------------------

TRUNCATE TABLE "billing_payments" CASCADE;

SELECT setval('public.billing_payments_id_seq', COALESCE((SELECT MAX("id") FROM "billing_payments"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "brands"
-- ----------------------------------------------------------

TRUNCATE TABLE "brands" CASCADE;

INSERT INTO "brands" ("id", "name", "slug", "description", "created_at", "updated_at", "deleted_at") VALUES
(1, 'Huawei', 'huawei', NULL, '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL),
(2, 'Cisco', 'cisco', NULL, '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL),
(3, 'ZTE', 'zte', NULL, '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL);

SELECT setval('public.brands_id_seq', COALESCE((SELECT MAX("id") FROM "brands"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "bts_sites"
-- ----------------------------------------------------------

TRUNCATE TABLE "bts_sites" CASCADE;

INSERT INTO "bts_sites" ("id", "name", "link_segment", "code", "measurement_date", "sfp_sm_link_length", "sfp_vendor", "tx_power", "rx_power", "cable_length_km", "tube_number", "tube_color", "core_number", "core_color", "latitude", "longitude", "address", "mikrotik_ip", "sfp_port_name", "notes", "created_by", "created_at", "updated_at", "deleted_at") VALUES
(1, 'BTS SMK 3', 'LINK -VIA KP JAWA(SMK3)', 'BTS-SMK3-01', '2026-08-17', '10Km', 'WTD', -3.350, -10.600, 5.17, 1, 'Biru (Blue)', 1, 'Biru (Blue)', -0.7925140, 100.6582310, 'SMK Negeri 3 Kota Solok, Jl. Ki Hajar Dewantara', '10.20.10.1', 'sfp-sfpplus1', NULL, NULL, '2026-08-17 15:08:59', '2026-08-17 16:18:43', NULL),
(2, 'BTS SMK 3 (SW-FO-KP JAWA 01)', 'SW -FO- KP JAWA 01', 'BTS-SMK3-02', '2025-05-27', '20Km', 'HISENSE', -3.147, -6.734, 5.17, 1, 'Biru (Blue)', 2, 'Orange', -0.7931100, 100.6591000, 'Switch Hub FO Kampung Jawa, Kota Solok', '10.20.10.2', 'sfp-sfpplus2', NULL, NULL, '2026-08-17 15:08:59', '2026-08-17 15:13:01', '2026-08-17 15:13:01'),
(3, 'BTS PRUMNAS KOBAR', 'BACKBONE FEEDER PRUMNAS', 'BTS-KOBAR-01', '2026-08-17', '20Km', 'HISENSE', -3.600, -10.120, 8.38, 2, 'Orange', 3, 'Hijau (Green)', -0.8042150, 100.6412050, 'Perumahan Nasional Koto Baru, Solok', '10.20.20.1', 'sfp-sfpplus1', NULL, NULL, '2026-08-17 15:08:59', '2026-08-17 16:14:48', '2026-08-17 16:14:48'),
(4, 'BTS SMPN 6 KOTA SOLOK', 'TO-BTS-SMPN 6', 'BTS-SMP6-01', '2026-08-17', '20Km', 'MIKROBITS', -3.460, -9.870, 4.16, 1, 'Biru (Blue)', 4, 'Coklat (Brown)', -0.7834000, 100.6651200, 'SMPN 6 Kota Solok, Jl. Tembok Raya', '10.20.30.1', 'sfp1', NULL, NULL, '2026-08-17 15:08:59', '2026-08-17 15:12:57', '2026-08-17 15:12:57'),
(5, 'BTS SD IT KOTA SOLOK', 'FEEDER LINK SD IT', 'BTS-SDIT-01', '2026-08-17', '10Km', 'TARMOC', -3.590, -10.130, 3.10, 1, 'Biru (Blue)', 5, 'Abu-abu (Slate)', -0.7789000, 100.6487000, 'SD IT Kota Solok, Jl. Bypass', '10.20.40.1', 'sfp1', NULL, NULL, '2026-08-17 15:08:59', '2026-08-17 16:14:51', '2026-08-17 16:14:51');

SELECT setval('public.bts_sites_id_seq', COALESCE((SELECT MAX("id") FROM "bts_sites"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "cable_types"
-- ----------------------------------------------------------

TRUNCATE TABLE "cable_types" CASCADE;

INSERT INTO "cable_types" ("id", "name", "core_capacity", "jacket_color", "installation_type", "description", "created_at", "updated_at", "deleted_at", "tube_count", "cores_per_tube") VALUES
(4, 'FTTH Drop Cable 6 Core Aerial', 6, 'Black', 'Aerial', 'Kabel feeder 6 core 1 tube — Aerial/udara. Digunakan untuk distribusi ODP→ODC jarak pendek.', '2026-08-04 13:48:22', '2026-08-04 13:48:22', NULL, 1, 6),
(5, 'FTTH Drop Cable 6 Core Underground', 6, 'Black', 'Underground', 'Kabel 6 core 1 tube — Underground/galian. Armored, cocok untuk persilangan jalan.', '2026-08-04 13:48:22', '2026-08-04 13:48:22', NULL, 1, 6),
(6, 'FTTH Cable 12 Core 1 Tube Aerial', 12, 'Black', 'Aerial', 'Kabel distribusi 12 core 1 tube — Aerial. Digunakan untuk jalur ODC→ODP.', '2026-08-04 13:48:22', '2026-08-04 13:48:22', NULL, 1, 12),
(7, 'FTTH Cable 12 Core 2 Tube Aerial', 12, 'Black', 'Aerial', 'Kabel distribusi 12 core 2 tube — Aerial. Setiap tube berisi 6 core.', '2026-08-04 13:48:22', '2026-08-04 13:48:22', NULL, 2, 6),
(8, 'FTTH Cable 12 Core 2 Tube Underground', 12, 'Black', 'Underground', 'Kabel 12 core 2 tube — Underground/galian.', '2026-08-04 13:48:22', '2026-08-04 13:48:22', NULL, 2, 6),
(9, 'FTTH Cable 24 Core 2 Tube Aerial', 24, 'Black', 'Aerial', 'Kabel feeder 24 core 2 tube — Aerial. Digunakan untuk jalur utama POP→ODC.', '2026-08-04 13:48:22', '2026-08-04 13:48:22', NULL, 2, 12),
(10, 'FTTH Cable 24 Core 4 Tube Aerial', 24, 'Black', 'Aerial', 'Kabel distribusi 24 core 4 tube — Aerial. Setiap tube berisi 6 core.', '2026-08-04 13:48:22', '2026-08-04 13:48:22', NULL, 4, 6),
(11, 'FTTH Cable 24 Core 4 Tube Underground', 24, 'Black', 'Underground', 'Kabel 24 core 4 tube — Underground/duct.', '2026-08-04 13:48:22', '2026-08-04 13:48:22', NULL, 4, 6),
(12, 'FTTH Backbone 48 Core 4 Tube Aerial', 48, 'Black', 'Aerial', 'Kabel backbone 48 core 4 tube — Aerial. Jalur utama OLT→POP atau antar POP.', '2026-08-04 13:48:22', '2026-08-04 13:48:22', NULL, 4, 12),
(13, 'FTTH Backbone 48 Core 8 Tube Aerial', 48, 'Black', 'Aerial', 'Kabel backbone 48 core 8 tube — Aerial. Setiap tube berisi 6 core.', '2026-08-04 13:48:22', '2026-08-04 13:48:22', NULL, 8, 6),
(14, 'FTTH Backbone 48 Core 4 Tube Underground', 48, 'Black', 'Underground', 'Kabel backbone 48 core 4 tube — Underground/duct. Armored, untuk jalur utama.', '2026-08-04 13:48:22', '2026-08-04 13:48:22', NULL, 4, 12),
(15, 'FTTH Backbone 48 Core 8 Tube Underground', 48, 'Black', 'Underground', 'Kabel backbone 48 core 8 tube — Underground. Kapasitas besar untuk area padat.', '2026-08-04 13:48:22', '2026-08-04 13:48:22', NULL, 8, 6);

SELECT setval('public.cable_types_id_seq', COALESCE((SELECT MAX("id") FROM "cable_types"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "cache"
-- ----------------------------------------------------------

TRUNCATE TABLE "cache" CASCADE;

INSERT INTO "cache" ("key", "value", "expiration") VALUES
('fiber-unms-enterprise-cache-road_route_-0.78396_100.65491_-0.78499_100.65441', 'a:5:{i:0;a:3:{s:3:"lat";d:-0.783944;s:3:"lng";d:100.654867;s:4:"name";s:10:"Titik Awal";}i:1;a:3:{s:3:"lat";d:-0.783985;s:3:"lng";d:100.654851;s:4:"name";s:22:"Kelokan Tiang Jalan #1";}i:2;a:3:{s:3:"lat";d:-0.784777;s:3:"lng";d:100.65443;s:4:"name";s:22:"Kelokan Tiang Jalan #2";}i:3;a:3:{s:3:"lat";d:-0.784823;s:3:"lng";d:100.654407;s:4:"name";s:22:"Kelokan Tiang Jalan #3";}i:4;a:3:{s:3:"lat";d:-0.784954;s:3:"lng";d:100.65434;s:4:"name";s:11:"Titik Ujung";}}', 1787063274),
('fiber-unms-enterprise-cache-road_route_-0.78396_100.65491_-0.78644_100.65393', 'a:15:{i:0;a:3:{s:3:"lat";d:-0.783944;s:3:"lng";d:100.654867;s:4:"name";s:10:"Titik Awal";}i:1;a:3:{s:3:"lat";d:-0.783985;s:3:"lng";d:100.654851;s:4:"name";s:22:"Kelokan Tiang Jalan #1";}i:2;a:3:{s:3:"lat";d:-0.784777;s:3:"lng";d:100.65443;s:4:"name";s:22:"Kelokan Tiang Jalan #2";}i:3;a:3:{s:3:"lat";d:-0.784823;s:3:"lng";d:100.654407;s:4:"name";s:22:"Kelokan Tiang Jalan #3";}i:4;a:3:{s:3:"lat";d:-0.785266;s:3:"lng";d:100.654181;s:4:"name";s:22:"Kelokan Tiang Jalan #4";}i:5;a:3:{s:3:"lat";d:-0.785334;s:3:"lng";d:100.654157;s:4:"name";s:22:"Kelokan Tiang Jalan #5";}i:6;a:3:{s:3:"lat";d:-0.785405;s:3:"lng";d:100.654145;s:4:"name";s:22:"Kelokan Tiang Jalan #6";}i:7;a:3:{s:3:"lat";d:-0.785478;s:3:"lng";d:100.654131;s:4:"name";s:22:"Kelokan Tiang Jalan #7";}i:8;a:3:{s:3:"lat";d:-0.785547;s:3:"lng";d:100.654116;s:4:"name";s:22:"Kelokan Tiang Jalan #8";}i:9;a:3:{s:3:"lat";d:-0.785579;s:3:"lng";d:100.654108;s:4:"name";s:22:"Kelokan Tiang Jalan #9";}i:10;a:3:{s:3:"lat";d:-0.785911;s:3:"lng";d:100.654031;s:4:"name";s:23:"Kelokan Tiang Jalan #10";}i:11;a:3:{s:3:"lat";d:-0.786069;s:3:"lng";d:100.653972;s:4:"name";s:23:"Kelokan Tiang Jalan #11";}i:12;a:3:{s:3:"lat";d:-0.78618;s:3:"lng";d:100.653919;s:4:"name";s:23:"Kelokan Tiang Jalan #12";}i:13;a:3:{s:3:"lat";d:-0.786439;s:3:"lng";d:100.653733;s:4:"name";s:23:"Kelokan Tiang Jalan #13";}i:14;a:3:{s:3:"lat";d:-0.786537;s:3:"lng";d:100.653805;s:4:"name";s:11:"Titik Ujung";}}', 1787063161);


-- ----------------------------------------------------------
-- Struktur & Data Tabel: "cache_locks"
-- ----------------------------------------------------------

TRUNCATE TABLE "cache_locks" CASCADE;


-- ----------------------------------------------------------
-- Struktur & Data Tabel: "customer_contacts"
-- ----------------------------------------------------------

TRUNCATE TABLE "customer_contacts" CASCADE;

SELECT setval('public.customer_contacts_id_seq', COALESCE((SELECT MAX("id") FROM "customer_contacts"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "customer_notes"
-- ----------------------------------------------------------

TRUNCATE TABLE "customer_notes" CASCADE;

SELECT setval('public.customer_notes_id_seq', COALESCE((SELECT MAX("id") FROM "customer_notes"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "customer_services"
-- ----------------------------------------------------------

TRUNCATE TABLE "customer_services" CASCADE;

INSERT INTO "customer_services" ("id", "service_number", "customer_id", "service_package_id", "status", "installation_date", "activated_at", "terminated_at", "onu_serial", "onu_mac", "pppoe_username", "pppoe_password", "ip_address", "installation_notes", "installed_by", "created_at", "updated_at", "deleted_at") VALUES
(20, 'SRV-980269', 28, 1, 'active', '2026-08-14', NULL, NULL, 'ZTEG-C881A201', NULL, NULL, NULL, NULL, NULL, NULL, '2026-08-14 12:41:20', '2026-08-14 12:41:20', NULL);

SELECT setval('public.customer_services_id_seq', COALESCE((SELECT MAX("id") FROM "customer_services"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "customers"
-- ----------------------------------------------------------

TRUNCATE TABLE "customers" CASCADE;

INSERT INTO "customers" ("id", "customer_number", "name", "nik", "phone", "email", "address", "province_id", "regency_id", "district_id", "village_id", "postal_code", "latitude", "longitude", "status", "customer_type", "id_card_photo", "house_photo", "notes", "created_by", "created_at", "updated_at", "deleted_at") VALUES
(28, 'CMN 0001', 'AGUS', NULL, '-', NULL, 'kp JAWA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', 'residential', NULL, NULL, NULL, NULL, '2026-08-14 12:41:20', '2026-08-14 12:41:20', NULL);

SELECT setval('public.customers_id_seq', COALESCE((SELECT MAX("id") FROM "customers"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "designations"
-- ----------------------------------------------------------

TRUNCATE TABLE "designations" CASCADE;

INSERT INTO "designations" ("id", "division_id", "name", "code", "description", "created_at", "updated_at", "deleted_at") VALUES
(1, 1, 'NOC Manager', 'NOC_MGR', NULL, '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL),
(2, 2, 'Field Engineer', 'FIELD_ENG', NULL, '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL),
(3, 3, 'Customer Support Rep', 'CSR', NULL, '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL);

SELECT setval('public.designations_id_seq', COALESCE((SELECT MAX("id") FROM "designations"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "device_types"
-- ----------------------------------------------------------

TRUNCATE TABLE "device_types" CASCADE;

INSERT INTO "device_types" ("id", "name", "code", "category", "description", "created_at", "updated_at", "deleted_at") VALUES
(1, 'OLT', 'OLT', 'OLT', 'Optical Line Terminal', '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL),
(2, 'ONT', 'ONT', 'ONT', 'Optical Network Terminal', '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL),
(3, 'Router', 'RTR', 'ROUTER', 'Customer router', '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL),
(4, 'Switch', 'SW', 'SWITCH', 'Layer 2/3 switch', '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL);

SELECT setval('public.device_types_id_seq', COALESCE((SELECT MAX("id") FROM "device_types"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "districts"
-- ----------------------------------------------------------

TRUNCATE TABLE "districts" CASCADE;

SELECT setval('public.districts_id_seq', COALESCE((SELECT MAX("id") FROM "districts"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "divisions"
-- ----------------------------------------------------------

TRUNCATE TABLE "divisions" CASCADE;

INSERT INTO "divisions" ("id", "name", "code", "description", "created_at", "updated_at", "deleted_at") VALUES
(1, 'Network Operations Center', 'NOC', ' pusat pengawasan jaringan', '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL),
(2, 'Field Technician', 'TECH', 'Tim teknisi lapangan', '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL),
(3, 'Customer Service', 'CS', 'Layanan pelanggan', '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL),
(4, 'Inventory', 'INV', 'Manajemen inventaris', '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL),
(5, 'Finance', 'FIN', 'Keuangan', '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL),
(6, 'Management', 'MGT', 'Manajemen perusahaan', '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL);

SELECT setval('public.divisions_id_seq', COALESCE((SELECT MAX("id") FROM "divisions"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "failed_jobs"
-- ----------------------------------------------------------

TRUNCATE TABLE "failed_jobs" CASCADE;

SELECT setval('public.failed_jobs_id_seq', COALESCE((SELECT MAX("id") FROM "failed_jobs"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "item_categories"
-- ----------------------------------------------------------

TRUNCATE TABLE "item_categories" CASCADE;

INSERT INTO "item_categories" ("id", "name", "code", "description", "created_at", "updated_at", "deleted_at") VALUES
(1, 'Fiber Optic Cable', 'FO_CABLE', NULL, '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL),
(2, 'Splitter', 'SPLITTER', NULL, '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL),
(3, 'Connector', 'CONNECTOR', NULL, '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL);

SELECT setval('public.item_categories_id_seq', COALESCE((SELECT MAX("id") FROM "item_categories"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "item_units"
-- ----------------------------------------------------------

TRUNCATE TABLE "item_units" CASCADE;

INSERT INTO "item_units" ("id", "name", "symbol", "description", "created_at", "updated_at", "deleted_at") VALUES
(1, 'Piece', 'pcs', NULL, '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL),
(2, 'Meter', 'm', NULL, '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL),
(3, 'Roll', 'rl', NULL, '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL);

SELECT setval('public.item_units_id_seq', COALESCE((SELECT MAX("id") FROM "item_units"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "job_batches"
-- ----------------------------------------------------------

TRUNCATE TABLE "job_batches" CASCADE;


-- ----------------------------------------------------------
-- Struktur & Data Tabel: "jobs"
-- ----------------------------------------------------------

TRUNCATE TABLE "jobs" CASCADE;

SELECT setval('public.jobs_id_seq', COALESCE((SELECT MAX("id") FROM "jobs"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "migrations"
-- ----------------------------------------------------------

TRUNCATE TABLE "migrations" CASCADE;

INSERT INTO "migrations" ("id", "migration", "batch") VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2026_08_04_000001_create_master_data_tables', 1),
(5, '2026_08_04_000002_create_crm_tables', 1),
(6, '2026_08_04_000003_create_network_infrastructure_tables', 1),
(7, '2026_08_04_000004_create_service_config_tables', 1),
(8, '2026_08_04_100929_create_olt_devices_table', 2),
(9, '2026_08_04_133829_add_tube_columns_to_cable_types_and_splitter_to_network_nodes', 3),
(10, '2026_08_04_145207_add_tube_and_destination_to_network_cable_cores', 4),
(11, '2026_08_04_152737_make_cable_type_id_nullable_on_network_cables', 5),
(12, '2026_08_04_152936_make_nullable_fields_on_network_cables', 6),
(13, '2026_08_05_091202_add_olt_device_id_to_network_nodes_and_destination_to_network_ports', 7),
(14, '2026_08_05_165000_add_core_power_and_splitter_config_to_network_nodes', 8),
(15, '2026_08_05_104321_add_tube_to_network_nodes', 9),
(16, '2026_08_05_121406_add_core_color_to_network_nodes', 10),
(17, '2026_08_09_000001_make_customers_phone_nullable', 11),
(18, '2026_08_09_200000_add_route_coordinates_to_network_cables', 12),
(20, '2026_08_09_150633_create_tickets_table', 13),
(21, '2026_08_09_152701_add_rbac_fields_to_users_table', 14),
(22, '2026_08_09_153751_create_audit_logs_table', 15),
(23, '2026_08_09_160000_add_username_to_users_table', 16),
(24, '2026_08_14_000001_create_notifications_tables', 17),
(25, '2026_08_14_000002_create_system_settings_table', 18),
(26, '2026_08_15_000001_create_telegram_channels_table', 19),
(27, '2026_08_16_000001_create_voice_calls_table', 20),
(28, '2026_08_17_000001_create_bts_sites_table', 21);

SELECT setval('public.migrations_id_seq', COALESCE((SELECT MAX("id") FROM "migrations"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "network_cable_cores"
-- ----------------------------------------------------------

TRUNCATE TABLE "network_cable_cores" CASCADE;

INSERT INTO "network_cable_cores" ("id", "cable_id", "core_number", "color", "status", "customer_service_id", "notes", "created_at", "updated_at", "tube_number", "tube_color", "destination_type", "destination_name", "destination_node_id", "odf_cassette_label") VALUES
(133, 12, 1, 'Biru', 'used', NULL, 'INTERFACE 1/1/1', '2026-08-04 15:32:04', '2026-08-09 14:34:13', 1, 'Biru', 'ODC', 'ODC 01', 15, 'Tube-Biru / Core-Biru'),
(134, 12, 2, 'Oranye', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(135, 12, 3, 'Hijau', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(136, 12, 4, 'Cokelat', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(137, 12, 5, 'Abu-abu', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(138, 12, 6, 'Putih', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(139, 12, 7, 'Merah', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(140, 12, 8, 'Hitam', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(141, 12, 9, 'Kuning', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(142, 12, 10, 'Ungu', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(143, 12, 11, 'Pink', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(144, 12, 12, 'Toska', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(145, 12, 13, 'Biru', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(146, 12, 14, 'Oranye', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(147, 12, 15, 'Hijau', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(148, 12, 16, 'Cokelat', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(149, 12, 17, 'Abu-abu', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(150, 12, 18, 'Putih', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(151, 12, 19, 'Merah', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(152, 12, 20, 'Hitam', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(153, 12, 21, 'Kuning', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(154, 12, 22, 'Ungu', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(155, 12, 23, 'Pink', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(156, 12, 24, 'Toska', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(157, 12, 25, 'Biru', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(158, 12, 26, 'Oranye', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(159, 12, 27, 'Hijau', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(160, 12, 28, 'Cokelat', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(161, 12, 29, 'Abu-abu', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(162, 12, 30, 'Putih', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(163, 12, 31, 'Merah', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(164, 12, 32, 'Hitam', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(165, 12, 33, 'Kuning', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(166, 12, 34, 'Ungu', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(167, 12, 35, 'Pink', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(168, 12, 36, 'Toska', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(169, 12, 37, 'Biru', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(170, 12, 38, 'Oranye', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(171, 12, 39, 'Hijau', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(172, 12, 40, 'Cokelat', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(173, 12, 41, 'Abu-abu', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(174, 12, 42, 'Putih', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(175, 12, 43, 'Merah', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(176, 12, 44, 'Hitam', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(177, 12, 45, 'Kuning', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(178, 12, 46, 'Ungu', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(179, 12, 47, 'Pink', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(180, 12, 48, 'Toska', 'available', NULL, NULL, '2026-08-04 15:32:04', '2026-08-04 15:32:04', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(301, 16, 1, 'Biru', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(302, 16, 2, 'Oranye', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(303, 16, 3, 'Hijau', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(304, 16, 4, 'Cokelat', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(305, 16, 5, 'Abu-abu', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(306, 16, 6, 'Putih', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(307, 16, 7, 'Merah', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(308, 16, 8, 'Hitam', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(309, 16, 9, 'Kuning', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(310, 16, 10, 'Ungu', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(311, 16, 11, 'Pink', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(312, 16, 12, 'Toska', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 1, 'Biru', 'UNASSIGNED', NULL, NULL, NULL),
(313, 16, 13, 'Biru', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(314, 16, 14, 'Oranye', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(315, 16, 15, 'Hijau', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(316, 16, 16, 'Cokelat', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(317, 16, 17, 'Abu-abu', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(318, 16, 18, 'Putih', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(319, 16, 19, 'Merah', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(320, 16, 20, 'Hitam', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(321, 16, 21, 'Kuning', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(322, 16, 22, 'Ungu', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(323, 16, 23, 'Pink', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(324, 16, 24, 'Toska', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 2, 'Oranye', 'UNASSIGNED', NULL, NULL, NULL),
(325, 16, 25, 'Biru', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(326, 16, 26, 'Oranye', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(327, 16, 27, 'Hijau', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(328, 16, 28, 'Cokelat', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(329, 16, 29, 'Abu-abu', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(330, 16, 30, 'Putih', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(331, 16, 31, 'Merah', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(332, 16, 32, 'Hitam', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(333, 16, 33, 'Kuning', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(334, 16, 34, 'Ungu', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(335, 16, 35, 'Pink', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(336, 16, 36, 'Toska', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 3, 'Hijau', 'UNASSIGNED', NULL, NULL, NULL),
(337, 16, 37, 'Biru', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(338, 16, 38, 'Oranye', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(339, 16, 39, 'Hijau', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(340, 16, 40, 'Cokelat', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(341, 16, 41, 'Abu-abu', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(342, 16, 42, 'Putih', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(343, 16, 43, 'Merah', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(344, 16, 44, 'Hitam', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(345, 16, 45, 'Kuning', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(346, 16, 46, 'Ungu', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(347, 16, 47, 'Pink', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL),
(348, 16, 48, 'Toska', 'available', NULL, NULL, '2026-08-12 15:21:43', '2026-08-12 15:21:43', 4, 'Cokelat', 'UNASSIGNED', NULL, NULL, NULL);

SELECT setval('public.network_cable_cores_id_seq', COALESCE((SELECT MAX("id") FROM "network_cable_cores"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "network_cables"
-- ----------------------------------------------------------

TRUNCATE TABLE "network_cables" CASCADE;

INSERT INTO "network_cables" ("id", "name", "code", "cable_type_id", "from_node_id", "to_node_id", "length_meters", "core_count_total", "core_count_used", "installation_type", "route_description", "status", "installed_at", "notes", "created_at", "updated_at", "deleted_at", "route_coordinates") VALUES
(12, 'ARAH KOTO BARU', 'KBR-A-01', NULL, 1, NULL, 8459.00, 48, 1, 'Aerial', 'Dari POP ke arah KOTO BARU', 'active', '2026-08-04', 'Merek Kabe Fiber Home', '2026-08-04 15:32:04', '2026-08-09 14:48:27', NULL, '[{"lat":-0.786407,"lng":100.653815,"name":"Tiang #01"},{"lat":-0.786611,"lng":100.653638,"name":"Tiang #02"},{"lat":-0.786978,"lng":100.653343,"name":"Tiang #03"},{"lat":-0.787134,"lng":100.653206,"name":"Tiang #04"},{"lat":-0.787488,"lng":100.653453,"name":"Tiang #05"},{"lat":-0.787799,"lng":100.653682,"name":"Tiang #06"},{"lat":-0.788271,"lng":100.654073,"name":"Tiang #07"},{"lat":-0.788711,"lng":100.654427,"name":"Tiang #08"},{"lat":-0.789414,"lng":100.654938,"name":"Tiang #09"},{"lat":-0.789869,"lng":100.655245,"name":"Tiang #10"},{"lat":-0.790376,"lng":100.655518,"name":"Tiang #11"},{"lat":-0.790486,"lng":100.655211,"name":"Tiang #12"},{"lat":-0.790599,"lng":100.654907,"name":"Tiang #13"},{"lat":-0.790886,"lng":100.654402,"name":"Tiang #14"},{"lat":-0.790985,"lng":100.654306,"name":"Tiang #15"},{"lat":-0.791328,"lng":100.654207,"name":"Tiang #16"},{"lat":-0.791774,"lng":100.654089,"name":"Tiang #17"},{"lat":-0.792235,"lng":100.65393,"name":"Tiang #18"},{"lat":-0.792436,"lng":100.653812,"name":"Tiang #19"},{"lat":-0.792629,"lng":100.653665,"name":"Tiang #20"},{"lat":-0.792881,"lng":100.653448,"name":"Tiang #21"},{"lat":-0.793107,"lng":100.653574,"name":"Tiang #22"},{"lat":-0.793683,"lng":100.653874,"name":"Tiang #23"},{"lat":-0.794262,"lng":100.654014,"name":"Tiang #24"},{"lat":-0.794657,"lng":100.653995,"name":"Tiang #25"},{"lat":-0.795,"lng":100.653901,"name":"Tiang #26"},{"lat":-0.795558,"lng":100.653788,"name":"Tiang #27"},{"lat":-0.795941,"lng":100.653705,"name":"Tiang #28"},{"lat":-0.796301,"lng":100.653646,"name":"Tiang #29"},{"lat":-0.796775,"lng":100.65352,"name":"Tiang #30"},{"lat":-0.797028,"lng":100.653445,"name":"Tiang #31"},{"lat":-0.79729,"lng":100.653338,"name":"Tiang #32"},{"lat":-0.797524,"lng":100.653314,"name":"Tiang #33"},{"lat":-0.797835,"lng":100.653367,"name":"Tiang #34"},{"lat":-0.798095,"lng":100.653397,"name":"Tiang #35"},{"lat":-0.798403,"lng":100.65341,"name":"Tiang #36"},{"lat":-0.798782,"lng":100.653375,"name":"Tiang #37"},{"lat":-0.799152,"lng":100.653348,"name":"Tiang #38"},{"lat":-0.799484,"lng":100.653297,"name":"Tiang #39"},{"lat":-0.799849,"lng":100.653255,"name":"Tiang #40"},{"lat":-0.800238,"lng":100.653171,"name":"Tiang #41"},{"lat":-0.800699,"lng":100.653107,"name":"Tiang #42"},{"lat":-0.801343,"lng":100.653,"name":"Tiang #43"},{"lat":-0.80197,"lng":100.652895,"name":"Tiang #44"},{"lat":-0.802426,"lng":100.65282,"name":"Tiang #45"},{"lat":-0.802973,"lng":100.65271,"name":"Tiang #46"},{"lat":-0.803606,"lng":100.652611,"name":"Tiang #47"},{"lat":-0.803942,"lng":100.652565,"name":"Tiang #48"},{"lat":-0.804285,"lng":100.652549,"name":"Tiang #49"},{"lat":-0.80466,"lng":100.652595,"name":"Tiang #50"},{"lat":-0.805009,"lng":100.652673,"name":"Tiang #51"},{"lat":-0.805604,"lng":100.652801,"name":"Tiang #52"},{"lat":-0.806135,"lng":100.652828,"name":"Tiang #53"},{"lat":-0.806522,"lng":100.65285,"name":"Tiang #54"},{"lat":-0.806884,"lng":100.652847,"name":"Tiang #55"},{"lat":-0.80749,"lng":100.652804,"name":"Tiang #56"},{"lat":-0.807857,"lng":100.652737,"name":"Tiang #57"},{"lat":-0.808107,"lng":100.65274,"name":"Tiang #58"},{"lat":-0.808724,"lng":100.652646,"name":"Tiang #59"},{"lat":-0.809115,"lng":100.652571,"name":"Tiang #60"},{"lat":-0.809394,"lng":100.652506,"name":"Tiang #61"},{"lat":-0.809786,"lng":100.652396,"name":"Tiang #62"},{"lat":-0.81036,"lng":100.652219,"name":"Tiang #63"},{"lat":-0.81095,"lng":100.652015,"name":"Tiang #64"},{"lat":-0.811387,"lng":100.651809,"name":"Tiang #65"},{"lat":-0.811577,"lng":100.651685,"name":"Tiang #66"},{"lat":-0.812025,"lng":100.651484,"name":"Tiang #67"},{"lat":-0.812449,"lng":100.651348,"name":"Tiang #68"},{"lat":-0.812913,"lng":100.651149,"name":"Tiang #69"},{"lat":-0.813248,"lng":100.651004,"name":"Tiang #70"},{"lat":-0.813516,"lng":100.650935,"name":"Tiang #71"},{"lat":-0.813913,"lng":100.650763,"name":"Tiang #72"},{"lat":-0.814168,"lng":100.650682,"name":"Tiang #73"},{"lat":-0.81435,"lng":100.650658,"name":"Tiang #74"},{"lat":-0.814525,"lng":100.650634,"name":"Tiang #75"},{"lat":-0.814809,"lng":100.650623,"name":"Tiang #76"},{"lat":-0.815074,"lng":100.650674,"name":"Tiang #77"},{"lat":-0.815364,"lng":100.650712,"name":"Tiang #78"},{"lat":-0.815536,"lng":100.650827,"name":"Tiang #79"},{"lat":-0.815882,"lng":100.651004,"name":"Tiang #80"},{"lat":-0.816128,"lng":100.651147,"name":"Tiang #81"},{"lat":-0.816311,"lng":100.651305,"name":"Tiang #82"},{"lat":-0.816638,"lng":100.651557,"name":"Tiang #83"},{"lat":-0.816895,"lng":100.651801,"name":"Tiang #84"},{"lat":-0.817059,"lng":100.652032,"name":"Tiang #85"},{"lat":-0.817233,"lng":100.652228,"name":"Tiang #86"},{"lat":-0.817365,"lng":100.652346,"name":"Tiang #87"},{"lat":-0.817512,"lng":100.652475,"name":"Tiang #88"},{"lat":-0.817729,"lng":100.652611,"name":"Tiang #89"},{"lat":-0.817906,"lng":100.652697,"name":"Tiang #90"},{"lat":-0.81822,"lng":100.652925,"name":"Tiang #91"},{"lat":-0.818475,"lng":100.653083,"name":"Tiang #92"},{"lat":-0.818518,"lng":100.653145,"name":"Tiang #93"},{"lat":-0.818539,"lng":100.65323,"name":"Tiang #94"},{"lat":-0.818569,"lng":100.653351,"name":"Tiang #95"},{"lat":-0.81859,"lng":100.653523,"name":"Tiang #96"},{"lat":-0.818604,"lng":100.653705,"name":"Tiang #97"},{"lat":-0.818625,"lng":100.65388,"name":"Tiang #98"},{"lat":-0.818663,"lng":100.654043,"name":"Tiang #99"},{"lat":-0.818706,"lng":100.654186,"name":"Tiang #100"},{"lat":-0.818848,"lng":100.654382,"name":"Tiang #101"},{"lat":-0.818955,"lng":100.654513,"name":"Tiang #102"},{"lat":-0.819079,"lng":100.654618,"name":"Tiang #103"},{"lat":-0.819242,"lng":100.654735,"name":"Tiang #104"},{"lat":-0.819363,"lng":100.654808,"name":"Tiang #105"},{"lat":-0.819494,"lng":100.65488,"name":"Tiang #106"},{"lat":-0.819677,"lng":100.655003,"name":"Tiang #107"},{"lat":-0.819867,"lng":100.655119,"name":"Tiang #108"},{"lat":-0.820028,"lng":100.655189,"name":"Tiang #109"},{"lat":-0.820167,"lng":100.655272,"name":"Tiang #110"},{"lat":-0.820301,"lng":100.655355,"name":"Tiang #111"},{"lat":-0.820492,"lng":100.655433,"name":"Tiang #112"},{"lat":-0.820607,"lng":100.655462,"name":"Tiang #113"},{"lat":-0.820755,"lng":100.6555,"name":"Tiang #114"},{"lat":-0.820891,"lng":100.655553,"name":"Tiang #115"},{"lat":-0.821087,"lng":100.655591,"name":"Tiang #116"},{"lat":-0.821296,"lng":100.655615,"name":"Tiang #117"},{"lat":-0.821444,"lng":100.655604,"name":"Tiang #118"},{"lat":-0.821634,"lng":100.655575,"name":"Tiang #119"},{"lat":-0.821911,"lng":100.65551,"name":"Tiang #120"},{"lat":-0.822085,"lng":100.655467,"name":"Tiang #121"},{"lat":-0.822254,"lng":100.655465,"name":"Tiang #122"},{"lat":-0.822452,"lng":100.655451,"name":"Tiang #123"},{"lat":-0.822785,"lng":100.655449,"name":"Tiang #124"},{"lat":-0.823254,"lng":100.655438,"name":"Tiang #125"},{"lat":-0.823635,"lng":100.6554,"name":"Tiang #126"},{"lat":-0.824013,"lng":100.655368,"name":"Tiang #127"},{"lat":-0.824201,"lng":100.655344,"name":"Tiang #128"},{"lat":-0.82437,"lng":100.655215,"name":"Tiang #129"},{"lat":-0.82448,"lng":100.655132,"name":"Tiang #130"},{"lat":-0.824646,"lng":100.65502,"name":"Tiang #131"},{"lat":-0.824751,"lng":100.654982,"name":"Tiang #132"},{"lat":-0.824933,"lng":100.65495,"name":"Tiang #133"},{"lat":-0.825175,"lng":100.654912,"name":"Tiang #134"},{"lat":-0.825327,"lng":100.654859,"name":"Tiang #135"},{"lat":-0.825531,"lng":100.654808,"name":"Tiang #136"},{"lat":-0.825783,"lng":100.654757,"name":"Tiang #137"},{"lat":-0.826073,"lng":100.6547,"name":"Tiang #138"},{"lat":-0.826218,"lng":100.654679,"name":"Tiang #139"},{"lat":-0.826609,"lng":100.654571,"name":"Tiang #140"},{"lat":-0.826859,"lng":100.654531,"name":"Tiang #141"},{"lat":-0.827033,"lng":100.654459,"name":"Tiang #142"},{"lat":-0.827234,"lng":100.654384,"name":"Tiang #143"},{"lat":-0.827419,"lng":100.654338,"name":"Tiang #144"},{"lat":-0.827578,"lng":100.654325,"name":"Tiang #145"},{"lat":-0.827733,"lng":100.65429,"name":"Tiang #146"},{"lat":-0.827899,"lng":100.654309,"name":"Tiang #147"},{"lat":-0.828103,"lng":100.654333,"name":"Tiang #148"},{"lat":-0.828299,"lng":100.654346,"name":"Tiang #149"},{"lat":-0.828699,"lng":100.6544,"name":"Tiang #150"},{"lat":-0.829096,"lng":100.654448,"name":"Tiang #151"},{"lat":-0.829884,"lng":100.654572,"name":"Tiang #152"},{"lat":-0.83034,"lng":100.654615,"name":"Tiang #153"},{"lat":-0.83079,"lng":100.65461,"name":"Tiang #154"},{"lat":-0.831263,"lng":100.654567,"name":"Tiang #155"},{"lat":-0.831885,"lng":100.654368,"name":"Tiang #156"},{"lat":-0.832394,"lng":100.654191,"name":"Tiang #157"},{"lat":-0.832974,"lng":100.653982,"name":"Tiang #158"},{"lat":-0.833703,"lng":100.653719,"name":"Tiang #159"},{"lat":-0.834416,"lng":100.653467,"name":"Tiang #160"},{"lat":-0.834926,"lng":100.653236,"name":"Tiang #161"},{"lat":-0.835403,"lng":100.653054,"name":"Tiang #162"},{"lat":-0.835902,"lng":100.65285,"name":"Tiang #163"},{"lat":-0.836187,"lng":100.652668,"name":"Tiang #164"},{"lat":-0.836492,"lng":100.652368,"name":"Tiang #165"},{"lat":-0.83676,"lng":100.651997,"name":"Tiang #166"},{"lat":-0.837061,"lng":100.651659,"name":"Tiang #167"},{"lat":-0.83735,"lng":100.651402,"name":"Tiang #168"},{"lat":-0.837581,"lng":100.651225,"name":"Tiang #169"},{"lat":-0.837898,"lng":100.651005,"name":"Tiang #170"},{"lat":-0.838252,"lng":100.650892,"name":"Tiang #171"},{"lat":-0.838568,"lng":100.650769,"name":"Tiang #172"},{"lat":-0.838981,"lng":100.650549,"name":"Tiang #173"},{"lat":-0.839394,"lng":100.650425,"name":"Tiang #174"},{"lat":-0.83978,"lng":100.650377,"name":"Tiang #175"},{"lat":-0.840129,"lng":100.650415,"name":"Tiang #176"},{"lat":-0.840445,"lng":100.650501,"name":"Tiang #177"},{"lat":-0.840778,"lng":100.650527,"name":"Tiang #178"},{"lat":-0.841137,"lng":100.650479,"name":"Tiang #179"},{"lat":-0.841534,"lng":100.650425,"name":"Tiang #180"},{"lat":-0.841765,"lng":100.650372,"name":"Tiang #181"},{"lat":-0.84199,"lng":100.650195,"name":"Tiang #182"},{"lat":-0.842221,"lng":100.650018,"name":"Tiang #183"},{"lat":-0.842425,"lng":100.6499,"name":"Tiang #184"},{"lat":-0.842661,"lng":100.649808,"name":"Tiang #185"},{"lat":-0.842843,"lng":100.649642,"name":"Tiang #186"},{"lat":-0.842999,"lng":100.649465,"name":"Tiang #187"},{"lat":-0.843106,"lng":100.649197,"name":"Tiang #188"},{"lat":-0.843229,"lng":100.648955,"name":"Tiang #189"},{"lat":-0.843438,"lng":100.648569,"name":"Tiang #190"},{"lat":-0.843632,"lng":100.648451,"name":"Tiang #191"},{"lat":-0.844039,"lng":100.648365,"name":"Tiang #192"},{"lat":-0.84434,"lng":100.648322,"name":"Tiang #193"},{"lat":-0.844833,"lng":100.64822,"name":"Tiang #194"},{"lat":-0.845101,"lng":100.648204,"name":"Tiang #195"},{"lat":-0.845477,"lng":100.648108,"name":"Tiang #196"},{"lat":-0.845874,"lng":100.648065,"name":"Tiang #197"},{"lat":-0.846222,"lng":100.647974,"name":"Tiang #198"},{"lat":-0.846625,"lng":100.647942,"name":"Tiang #199"},{"lat":-0.847086,"lng":100.647958,"name":"Tiang #200"},{"lat":-0.847386,"lng":100.64807,"name":"Tiang #201"},{"lat":-0.847885,"lng":100.648221,"name":"Tiang #202"},{"lat":-0.848164,"lng":100.648261,"name":"Tiang #203"},{"lat":-0.848239,"lng":100.648063,"name":"Tiang #204"},{"lat":-0.848373,"lng":100.64765,"name":"Tiang #205"},{"lat":-0.84854,"lng":100.647049,"name":"Tiang #206"},{"lat":-0.848642,"lng":100.646716,"name":"Tiang #207"},{"lat":-0.84877,"lng":100.646566,"name":"Tiang #208"},{"lat":-0.848776,"lng":100.646495,"name":"Tiang #209"},{"lat":-0.848797,"lng":100.646319,"name":"Tiang #210"},{"lat":-0.848805,"lng":100.646152,"name":"Tiang #211"},{"lat":-0.848825,"lng":100.645813,"name":"Tiang #212"},{"lat":-0.848848,"lng":100.645609,"name":"Tiang #213"},{"lat":-0.848847,"lng":100.645348,"name":"Tiang #214"},{"lat":-0.848856,"lng":100.645191,"name":"Tiang #215"},{"lat":-0.848816,"lng":100.645097,"name":"Tiang #216"},{"lat":-0.848741,"lng":100.645007,"name":"Tiang #217"},{"lat":-0.848648,"lng":100.644924,"name":"Tiang #218"},{"lat":-0.848511,"lng":100.644921,"name":"Tiang #219"},{"lat":-0.848297,"lng":100.644914,"name":"Tiang #220"},{"lat":-0.848082,"lng":100.64492,"name":"Tiang #221"},{"lat":-0.847832,"lng":100.644901,"name":"Tiang #222"},{"lat":-0.847692,"lng":100.644831,"name":"Tiang #223"},{"lat":-0.847606,"lng":100.644778,"name":"Tiang #224"},{"lat":-0.847553,"lng":100.644659,"name":"Tiang #225"},{"lat":-0.847429,"lng":100.644531,"name":"Tiang #226"},{"lat":-0.847354,"lng":100.644338,"name":"Tiang #227"},{"lat":-0.847247,"lng":100.644123,"name":"Tiang #228"},{"lat":-0.847236,"lng":100.643935,"name":"Tiang #229"},{"lat":-0.847223,"lng":100.6438,"name":"Tiang #230"},{"lat":-0.84724,"lng":100.643641,"name":"Tiang #231"},{"lat":-0.847275,"lng":100.643541,"name":"Tiang #232"},{"lat":-0.847308,"lng":100.643377,"name":"Tiang #233"},{"lat":-0.847357,"lng":100.643123,"name":"Tiang #234"},{"lat":-0.847358,"lng":100.642989,"name":"Tiang #235"},{"lat":-0.847381,"lng":100.64287,"name":"Tiang #236"},{"lat":-0.847405,"lng":100.642752,"name":"Tiang #237"},{"lat":-0.84727,"lng":100.642697,"name":"Tiang #238"}]'),
(16, 'asdasd', 'CBL-01-02', NULL, 1, 15, 123.00, 48, 0, 'Aerial', 'asdasd', 'active', '2026-08-12', 'asdasd', '2026-08-12 15:21:43', '2026-08-12 15:21:54', '2026-08-12 15:21:54', NULL);

SELECT setval('public.network_cables_id_seq', COALESCE((SELECT MAX("id") FROM "network_cables"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "network_nodes"
-- ----------------------------------------------------------

TRUNCATE TABLE "network_nodes" CASCADE;

INSERT INTO "network_nodes" ("id", "name", "code", "node_type", "device_type_id", "brand_id", "model", "serial_number", "status", "latitude", "longitude", "address", "province_id", "regency_id", "district_id", "village_id", "parent_node_id", "total_ports", "used_ports", "installed_at", "notes", "created_by", "created_at", "updated_at", "deleted_at", "splitter_type_id", "splitter_cascade_level", "olt_port_ref", "olt_device_id", "core_power", "splitter_config", "tube_count", "tube_info", "splitter_count", "odc_topology_type", "core_color") VALUES
(1, 'POP KANTOR CINOX', 'POP-01', 'POP', 1, 1, NULL, 'SN-OLT-2026-001', 'active', -0.7864417, 100.6539333, 'KANTOR CINOX MEDIA NETWORK', NULL, NULL, NULL, NULL, NULL, 16, 0, NULL, NULL, NULL, '2026-08-04 08:46:01', '2026-08-15 16:13:53', NULL, NULL, 0, NULL, 13, NULL, NULL, NULL, NULL, 0, 'tunggal', NULL),
(10, 'POP GUGUAK', 'POP-GGK-01_deleted_10_1786119230', 'POP', NULL, NULL, NULL, NULL, 'active', -0.9109980, 100.6400804, 'TOWER GUGUAK TALANG', NULL, NULL, NULL, NULL, NULL, 16, 0, NULL, NULL, NULL, '2026-08-05 08:18:22', '2026-08-07 16:13:50', '2026-08-07 16:13:50', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'tunggal', NULL),
(15, 'ODC 01', 'ODC-SLK-01', 'ODC', NULL, NULL, NULL, NULL, 'active', -0.7839611, 100.6549111, 'KP JAWA', NULL, NULL, NULL, NULL, 1, 68, 2, NULL, NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, 0, 'gpon-olt_1/1/1', 13, 'Biru, Orange, Hijau, Coklat, Abu', '["POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","POWER:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4","DIST:1:4"]', NULL, 'Tube 1 (Biru)', 17, 'induk', NULL),
(17, 'ODP 0001', 'ODP-SLK-0001_deleted_17_1786094707', 'ODP', NULL, NULL, NULL, NULL, 'active', -0.9073728, 100.6400642, 'asd', NULL, NULL, NULL, NULL, 15, 16, 0, NULL, NULL, NULL, '2026-08-05 11:54:41', '2026-08-07 09:25:07', '2026-08-07 09:25:07', NULL, 0, NULL, 13, NULL, NULL, NULL, NULL, 0, 'tunggal', NULL),
(18, 'ODP 0002', 'ODP-SLK-0002_deleted_18_1786093000', 'ODP', NULL, NULL, NULL, NULL, 'inactive', NULL, NULL, 'asdasd', NULL, NULL, NULL, NULL, 15, 16, 2, NULL, NULL, NULL, '2026-08-05 11:56:10', '2026-08-07 08:56:40', '2026-08-07 08:56:40', NULL, 0, NULL, 13, NULL, '["1:8","1:8"]', NULL, 'BIRU', 2, 'tunggal', 'ORANGE'),
(19, 'ODP 0002', 'ODP-SLK-0002_deleted_19_1786094704', 'ODP', NULL, NULL, NULL, NULL, 'active', -0.7854399, 100.6541956, NULL, NULL, NULL, NULL, NULL, 15, 8, 0, NULL, NULL, NULL, '2026-08-07 08:58:10', '2026-08-07 09:25:04', '2026-08-07 09:25:04', NULL, 0, NULL, 13, NULL, '["1:8"]', NULL, NULL, 1, 'tunggal', NULL),
(20, 'ODP 0001', 'ODP-SLK-0001', 'ODP', NULL, NULL, NULL, NULL, 'active', -0.7849889, 100.6544083, 'KP JAWA', NULL, NULL, NULL, NULL, 15, 8, 1, NULL, NULL, NULL, '2026-08-07 09:26:13', '2026-08-15 16:43:35', NULL, NULL, 0, 'gpon-olt_1/1/1', 13, NULL, '["1:8"]', NULL, 'Tube 1 (Biru)', 1, 'tunggal', 'Biru'),
(21, 'POP-SMK-PARIAMANn', 'POP-03_deleted_21_1786715164', 'POP', NULL, NULL, NULL, NULL, 'active', -0.6312361, 100.1210222, 'SMK PARIAMAN', NULL, NULL, NULL, NULL, NULL, 48, 0, NULL, NULL, NULL, '2026-08-07 16:10:40', '2026-08-14 13:46:04', '2026-08-14 13:46:04', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'tunggal', NULL),
(22, 'asdas', 'DASDASD_deleted_22_1786120862', 'ODC', NULL, NULL, NULL, NULL, 'active', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 15, 8, 0, NULL, NULL, NULL, '2026-08-07 16:39:44', '2026-08-07 16:41:02', '2026-08-07 16:41:02', NULL, 0, NULL, 13, 'asd', '["POWER:1:2","POWER:1:2","DIST:1:2","DIST:1:2"]', NULL, 'asd', 4, 'tunggal', NULL),
(23, 'asdasd', 'ASDAS_deleted_23_1786120866', 'ODP', NULL, NULL, NULL, NULL, 'active', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 22, 8, 0, NULL, NULL, NULL, '2026-08-07 16:40:33', '2026-08-07 16:41:06', '2026-08-07 16:41:06', NULL, 0, NULL, 13, NULL, '["1:8"]', NULL, 'asdad', 1, 'tunggal', 'asd'),
(24, 'POP-GUGUAK-02', 'POP-PG0-01_deleted_24_1786278537', 'POP', NULL, NULL, NULL, NULL, 'active', NULL, NULL, 'GUGUAK', NULL, NULL, NULL, NULL, NULL, 48, 0, NULL, NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:57', '2026-08-09 12:28:57', NULL, 0, NULL, 13, NULL, NULL, NULL, NULL, 0, 'tunggal', NULL),
(25, 'POP GUGUAK 02', 'POP-G0-01_deleted_25_1786278568', 'POP', NULL, NULL, NULL, NULL, 'active', NULL, NULL, 'asdasd', NULL, NULL, NULL, NULL, NULL, 48, 0, NULL, NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:28', '2026-08-09 12:29:28', NULL, 0, NULL, 13, NULL, NULL, NULL, NULL, 0, 'tunggal', NULL),
(26, 'asasderteterasdasd', 'POP-ASA-01_deleted_26_1786808937', 'POP', NULL, NULL, NULL, NULL, 'active', -0.7878861, 100.6570194, 'asdasd', NULL, NULL, NULL, NULL, NULL, 144, 0, NULL, NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 15:48:57', '2026-08-15 15:48:57', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'tunggal', NULL),
(27, 'BTS SMK 3', 'BTS-SMK3-01', 'BTS', NULL, NULL, NULL, NULL, 'active', -0.7925140, 100.6582310, 'SMK Negeri 3 Kota Solok, Jl. Ki Hajar Dewantara', NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 'BTS FO Link: LINK -VIA KP JAWA(SMK3) | SFP: WTD (10Km) | Tx: -3.350 dBm, Rx: -10.600 dBm | Jarak: 5.17 Km', NULL, '2026-08-17 15:08:59', '2026-08-17 16:18:43', NULL, NULL, 0, NULL, NULL, '-10.600 dBm', NULL, NULL, 'Tube 1 (Biru (Blue))', NULL, NULL, 'Biru (Blue)'),
(28, 'BTS SMK 3 (SW-FO-KP JAWA 01)', 'BTS-SMK3-02', 'BTS', NULL, NULL, NULL, NULL, 'active', -0.7931100, 100.6591000, 'Switch Hub FO Kampung Jawa, Kota Solok', NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 'BTS FO Link: SW -FO- KP JAWA 01 | SFP: HISENSE (20Km) | Tx: -3.147 dBm, Rx: -6.734 dBm | Jarak: 5.17 Km', NULL, '2026-08-17 15:08:59', '2026-08-17 15:13:01', '2026-08-17 15:13:01', NULL, 0, NULL, NULL, '-6.734 dBm', NULL, NULL, 'Tube 1 (Biru (Blue))', NULL, NULL, 'Orange'),
(29, 'BTS PRUMNAS KOBAR', 'BTS-KOBAR-01', 'BTS', NULL, NULL, NULL, NULL, 'active', -0.8042150, 100.6412050, 'Perumahan Nasional Koto Baru, Solok', NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 'BTS FO Link: BACKBONE FEEDER PRUMNAS | SFP: HISENSE (20Km) | Tx: -3.600 dBm, Rx: -10.120 dBm | Jarak: 8.38 Km', NULL, '2026-08-17 15:08:59', '2026-08-17 16:14:48', '2026-08-17 16:14:48', NULL, 0, NULL, NULL, '-10.120 dBm', NULL, NULL, 'Tube 2 (Orange)', NULL, NULL, 'Hijau (Green)'),
(30, 'BTS SMPN 6 KOTA SOLOK', 'BTS-SMP6-01', 'BTS', NULL, NULL, NULL, NULL, 'active', -0.7834000, 100.6651200, 'SMPN 6 Kota Solok, Jl. Tembok Raya', NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 'BTS FO Link: TO-BTS-SMPN 6 | SFP: MIKROBITS (20Km) | Tx: -3.460 dBm, Rx: -9.870 dBm | Jarak: 4.16 Km', NULL, '2026-08-17 15:08:59', '2026-08-17 15:12:57', '2026-08-17 15:12:57', NULL, 0, NULL, NULL, '-9.870 dBm', NULL, NULL, 'Tube 1 (Biru (Blue))', NULL, NULL, 'Coklat (Brown)'),
(31, 'BTS SD IT KOTA SOLOK', 'BTS-SDIT-01', 'BTS', NULL, NULL, NULL, NULL, 'active', -0.7789000, 100.6487000, 'SD IT Kota Solok, Jl. Bypass', NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 'BTS FO Link: FEEDER LINK SD IT | SFP: TARMOC (10Km) | Tx: -3.590 dBm, Rx: -10.130 dBm | Jarak: 3.10 Km', NULL, '2026-08-17 15:08:59', '2026-08-17 16:14:51', '2026-08-17 16:14:51', NULL, 0, NULL, NULL, '-10.130 dBm', NULL, NULL, 'Tube 1 (Biru (Blue))', NULL, NULL, 'Abu-abu (Slate)'),
(32, 'asdasd', 'POP-ASD-01_deleted_32_1786982229', 'POP', NULL, NULL, NULL, NULL, 'active', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 16, 0, NULL, NULL, NULL, '2026-08-17 15:56:53', '2026-08-17 15:57:09', '2026-08-17 15:57:09', NULL, 0, NULL, 13, NULL, NULL, NULL, NULL, 0, 'tunggal', NULL);

SELECT setval('public.network_nodes_id_seq', COALESCE((SELECT MAX("id") FROM "network_nodes"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "network_ports"
-- ----------------------------------------------------------

TRUNCATE TABLE "network_ports" CASCADE;

INSERT INTO "network_ports" ("id", "node_id", "port_number", "port_type", "status", "connected_to_port_id", "notes", "created_at", "updated_at", "customer_service_id", "customer_name_cache", "destination_label") VALUES
(1, 1, 'PON-0/0/1', 'PON', 'available', NULL, NULL, '2026-08-04 08:46:01', '2026-08-15 16:13:53', NULL, NULL, NULL),
(2, 1, 'PON-0/0/2', 'PON', 'available', NULL, NULL, '2026-08-04 08:46:01', '2026-08-15 16:13:53', NULL, NULL, NULL),
(3, 1, 'PON-0/0/3', 'PON', 'available', NULL, NULL, '2026-08-04 08:46:01', '2026-08-15 16:13:53', NULL, NULL, NULL),
(4, 1, 'PON-0/0/4', 'PON', 'available', NULL, NULL, '2026-08-04 08:46:01', '2026-08-15 16:13:53', NULL, NULL, NULL),
(5, 10, 1, 'PON', 'available', NULL, NULL, '2026-08-05 08:18:22', '2026-08-07 15:49:36', NULL, NULL, NULL),
(6, 10, 2, 'PON', 'available', NULL, NULL, '2026-08-05 08:18:22', '2026-08-07 15:49:36', NULL, NULL, NULL),
(7, 10, 3, 'PON', 'available', NULL, NULL, '2026-08-05 08:18:22', '2026-08-07 15:49:36', NULL, NULL, NULL),
(8, 10, 4, 'PON', 'available', NULL, NULL, '2026-08-05 08:18:22', '2026-08-07 15:49:36', NULL, NULL, NULL),
(9, 10, 5, 'PON', 'available', NULL, NULL, '2026-08-05 08:18:22', '2026-08-07 15:49:36', NULL, NULL, NULL),
(10, 10, 6, 'PON', 'available', NULL, NULL, '2026-08-05 08:18:22', '2026-08-07 15:49:36', NULL, NULL, NULL),
(11, 10, 7, 'PON', 'available', NULL, NULL, '2026-08-05 08:18:22', '2026-08-07 15:49:36', NULL, NULL, NULL),
(12, 10, 8, 'PON', 'available', NULL, NULL, '2026-08-05 08:18:22', '2026-08-07 15:49:36', NULL, NULL, NULL),
(13, 10, 9, 'PON', 'available', NULL, NULL, '2026-08-05 08:18:22', '2026-08-07 15:49:36', NULL, NULL, NULL),
(14, 10, 10, 'PON', 'available', NULL, NULL, '2026-08-05 08:18:22', '2026-08-07 15:49:36', NULL, NULL, NULL),
(15, 10, 11, 'PON', 'available', NULL, NULL, '2026-08-05 08:18:22', '2026-08-07 15:49:36', NULL, NULL, NULL),
(16, 10, 12, 'PON', 'available', NULL, NULL, '2026-08-05 08:18:22', '2026-08-07 15:49:36', NULL, NULL, NULL),
(17, 10, 13, 'PON', 'available', NULL, NULL, '2026-08-05 08:18:22', '2026-08-07 15:49:36', NULL, NULL, NULL),
(18, 10, 14, 'PON', 'available', NULL, NULL, '2026-08-05 08:18:22', '2026-08-07 15:49:36', NULL, NULL, NULL),
(19, 10, 15, 'PON', 'available', NULL, NULL, '2026-08-05 08:18:22', '2026-08-07 15:49:36', NULL, NULL, NULL),
(20, 10, 16, 'PON', 'available', NULL, NULL, '2026-08-05 08:18:22', '2026-08-07 15:49:36', NULL, NULL, NULL),
(169, 15, 1, 'PON', 'used', NULL, '-', '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, '-', 'POWER KE ODC 03'),
(170, 15, 2, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(171, 15, 3, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(172, 15, 4, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(173, 15, 5, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(174, 15, 6, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(175, 15, 7, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(176, 15, 8, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(177, 15, 9, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(178, 15, 10, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(179, 15, 11, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(180, 15, 12, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(181, 15, 13, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(182, 15, 14, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(183, 15, 15, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(184, 15, 16, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(185, 15, 17, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(186, 15, 18, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(187, 15, 19, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(188, 15, 20, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(189, 15, 21, 'PON', 'used', NULL, '-', '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, '-', 'ODP 0001'),
(190, 15, 22, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(191, 15, 23, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(192, 15, 24, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(193, 15, 25, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(194, 15, 26, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(195, 15, 27, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(196, 15, 28, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(197, 15, 29, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(198, 15, 30, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(199, 15, 31, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(200, 15, 32, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(201, 15, 33, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(202, 15, 34, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(203, 15, 35, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(204, 15, 36, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(205, 15, 37, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(206, 15, 38, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(207, 15, 39, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(208, 15, 40, 'PON', 'available', NULL, NULL, '2026-08-05 11:42:32', '2026-08-15 16:56:04', NULL, NULL, NULL),
(253, 17, 1, 'SC_APC', 'available', NULL, NULL, '2026-08-05 11:54:41', '2026-08-07 09:25:05', NULL, NULL, NULL),
(254, 17, 2, 'SC_APC', 'available', NULL, NULL, '2026-08-05 11:54:41', '2026-08-07 09:25:05', NULL, NULL, NULL),
(255, 17, 3, 'SC_APC', 'available', NULL, NULL, '2026-08-05 11:54:41', '2026-08-07 09:25:05', NULL, NULL, NULL),
(256, 17, 4, 'SC_APC', 'available', NULL, NULL, '2026-08-05 11:54:41', '2026-08-07 09:25:05', NULL, NULL, NULL),
(257, 17, 5, 'SC_APC', 'available', NULL, NULL, '2026-08-05 11:54:41', '2026-08-07 09:25:05', NULL, NULL, NULL),
(258, 17, 6, 'SC_APC', 'available', NULL, NULL, '2026-08-05 11:54:41', '2026-08-07 09:25:05', NULL, NULL, NULL),
(259, 17, 7, 'SC_APC', 'available', NULL, NULL, '2026-08-05 11:54:41', '2026-08-07 09:25:05', NULL, NULL, NULL),
(260, 17, 8, 'SC_APC', 'available', NULL, NULL, '2026-08-05 11:54:41', '2026-08-07 09:25:05', NULL, NULL, NULL),
(261, 18, 1, 'SC_APC', 'used', NULL, NULL, '2026-08-05 11:56:10', '2026-08-05 12:42:43', NULL, 'Budi Santoso', NULL),
(262, 18, 2, 'SC_APC', 'used', NULL, NULL, '2026-08-05 11:56:10', '2026-08-05 12:42:43', NULL, 'Siti Rahma', NULL),
(263, 18, 3, 'SC_APC', 'available', NULL, NULL, '2026-08-05 11:56:10', '2026-08-05 11:56:10', NULL, NULL, NULL),
(264, 18, 4, 'SC_APC', 'available', NULL, NULL, '2026-08-05 11:56:10', '2026-08-05 11:56:10', NULL, NULL, NULL),
(265, 18, 5, 'SC_APC', 'available', NULL, NULL, '2026-08-05 11:56:10', '2026-08-05 11:56:10', NULL, NULL, NULL),
(266, 18, 6, 'SC_APC', 'available', NULL, NULL, '2026-08-05 11:56:10', '2026-08-05 11:56:10', NULL, NULL, NULL),
(267, 18, 7, 'SC_APC', 'available', NULL, NULL, '2026-08-05 11:56:10', '2026-08-05 11:56:10', NULL, NULL, NULL),
(268, 18, 8, 'SC_APC', 'available', NULL, NULL, '2026-08-05 11:56:10', '2026-08-05 11:56:10', NULL, NULL, NULL),
(269, 19, 1, 'SC_APC', 'available', NULL, 1, '2026-08-07 08:58:10', '2026-08-07 09:25:04', NULL, NULL, NULL),
(270, 19, 2, 'SC_APC', 'available', NULL, NULL, '2026-08-07 08:58:10', '2026-08-07 09:25:04', NULL, NULL, NULL),
(271, 19, 3, 'SC_APC', 'available', NULL, NULL, '2026-08-07 08:58:10', '2026-08-07 09:25:04', NULL, NULL, NULL),
(272, 19, 4, 'SC_APC', 'available', NULL, NULL, '2026-08-07 08:58:10', '2026-08-07 09:25:04', NULL, NULL, NULL),
(273, 19, 5, 'SC_APC', 'available', NULL, NULL, '2026-08-07 08:58:10', '2026-08-07 09:25:04', NULL, NULL, NULL),
(274, 19, 6, 'SC_APC', 'available', NULL, NULL, '2026-08-07 08:58:10', '2026-08-07 09:25:04', NULL, NULL, NULL),
(275, 19, 7, 'SC_APC', 'available', NULL, NULL, '2026-08-07 08:58:10', '2026-08-07 09:25:04', NULL, NULL, NULL),
(276, 19, 8, 'SC_APC', 'available', NULL, NULL, '2026-08-07 08:58:10', '2026-08-07 09:25:04', NULL, NULL, NULL),
(277, 19, 9, 'SC_APC', 'available', NULL, NULL, '2026-08-07 08:58:10', '2026-08-07 09:25:04', NULL, NULL, NULL),
(278, 19, 10, 'SC_APC', 'available', NULL, NULL, '2026-08-07 08:58:10', '2026-08-07 09:25:04', NULL, NULL, NULL),
(279, 19, 11, 'SC_APC', 'available', NULL, NULL, '2026-08-07 08:58:10', '2026-08-07 09:25:04', NULL, NULL, NULL),
(280, 19, 12, 'SC_APC', 'available', NULL, NULL, '2026-08-07 08:58:10', '2026-08-07 09:25:04', NULL, NULL, NULL),
(281, 19, 13, 'SC_APC', 'available', NULL, NULL, '2026-08-07 08:58:10', '2026-08-07 09:25:04', NULL, NULL, NULL),
(282, 19, 14, 'SC_APC', 'available', NULL, NULL, '2026-08-07 08:58:10', '2026-08-07 09:25:04', NULL, NULL, NULL),
(283, 19, 15, 'SC_APC', 'available', NULL, NULL, '2026-08-07 08:58:10', '2026-08-07 09:25:04', NULL, NULL, NULL),
(284, 19, 16, 'SC_APC', 'available', NULL, NULL, '2026-08-07 08:58:10', '2026-08-07 09:25:04', NULL, NULL, NULL),
(285, 20, 1, 'SC_APC', 'used', NULL, 'asd', '2026-08-07 09:26:13', '2026-08-15 17:42:54', 20, 'AGUS', NULL),
(286, 20, 2, 'SC_APC', 'available', NULL, NULL, '2026-08-07 09:26:13', '2026-08-15 17:42:54', NULL, NULL, NULL),
(287, 20, 3, 'SC_APC', 'available', NULL, NULL, '2026-08-07 09:26:13', '2026-08-15 17:42:54', NULL, NULL, NULL),
(288, 20, 4, 'SC_APC', 'available', NULL, NULL, '2026-08-07 09:26:13', '2026-08-15 17:42:54', NULL, NULL, NULL),
(289, 20, 5, 'SC_APC', 'available', NULL, NULL, '2026-08-07 09:26:13', '2026-08-15 17:42:54', NULL, NULL, NULL),
(290, 20, 6, 'SC_APC', 'available', NULL, NULL, '2026-08-07 09:26:13', '2026-08-15 17:42:54', NULL, NULL, NULL),
(291, 20, 7, 'SC_APC', 'available', NULL, NULL, '2026-08-07 09:26:13', '2026-08-15 17:42:54', NULL, NULL, NULL),
(292, 20, 8, 'SC_APC', 'available', NULL, NULL, '2026-08-07 09:26:13', '2026-08-15 17:42:54', NULL, NULL, NULL),
(325, 1, 1, 'PON', 'available', NULL, NULL, '2026-08-07 15:54:29', '2026-08-15 16:13:53', NULL, NULL, NULL),
(326, 1, 2, 'PON', 'available', NULL, NULL, '2026-08-07 15:54:29', '2026-08-15 16:13:53', NULL, NULL, NULL),
(327, 1, 3, 'PON', 'available', NULL, NULL, '2026-08-07 15:54:29', '2026-08-15 16:13:53', NULL, NULL, NULL),
(328, 1, 4, 'PON', 'available', NULL, NULL, '2026-08-07 15:54:29', '2026-08-15 16:13:53', NULL, NULL, NULL),
(329, 1, 5, 'PON', 'available', NULL, NULL, '2026-08-07 15:54:29', '2026-08-15 16:13:53', NULL, NULL, NULL),
(330, 1, 6, 'PON', 'available', NULL, NULL, '2026-08-07 15:54:29', '2026-08-15 16:13:53', NULL, NULL, NULL),
(331, 1, 7, 'PON', 'available', NULL, NULL, '2026-08-07 15:54:29', '2026-08-15 16:13:53', NULL, NULL, NULL),
(332, 1, 8, 'PON', 'available', NULL, NULL, '2026-08-07 15:54:29', '2026-08-15 16:13:53', NULL, NULL, NULL),
(333, 1, 9, 'PON', 'available', NULL, NULL, '2026-08-07 15:54:29', '2026-08-15 16:13:53', NULL, NULL, NULL),
(334, 1, 10, 'PON', 'available', NULL, NULL, '2026-08-07 15:54:29', '2026-08-15 16:13:53', NULL, NULL, NULL),
(335, 1, 11, 'PON', 'available', NULL, NULL, '2026-08-07 15:54:29', '2026-08-15 16:13:53', NULL, NULL, NULL),
(336, 1, 12, 'PON', 'available', NULL, NULL, '2026-08-07 15:54:29', '2026-08-15 16:13:53', NULL, NULL, NULL),
(337, 1, 13, 'PON', 'available', NULL, NULL, '2026-08-07 15:54:29', '2026-08-15 16:13:53', NULL, NULL, NULL),
(338, 1, 14, 'PON', 'available', NULL, NULL, '2026-08-07 15:54:29', '2026-08-15 16:13:53', NULL, NULL, NULL),
(339, 1, 15, 'PON', 'available', NULL, NULL, '2026-08-07 15:54:29', '2026-08-15 16:13:53', NULL, NULL, NULL),
(340, 1, 16, 'PON', 'available', NULL, NULL, '2026-08-07 15:54:29', '2026-08-15 16:13:53', NULL, NULL, NULL),
(341, 21, 1, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(342, 21, 2, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(343, 21, 3, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(344, 21, 4, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(345, 21, 5, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(346, 21, 6, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(347, 21, 7, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(348, 21, 8, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(349, 21, 9, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(350, 21, 10, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(351, 21, 11, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(352, 21, 12, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(353, 21, 13, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(354, 21, 14, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(355, 21, 15, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(356, 21, 16, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(357, 21, 17, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(358, 21, 18, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(359, 21, 19, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(360, 21, 20, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(361, 21, 21, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(362, 21, 22, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(363, 21, 23, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(364, 21, 24, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(365, 21, 25, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(366, 21, 26, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(367, 21, 27, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(368, 21, 28, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(369, 21, 29, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(370, 21, 30, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(371, 21, 31, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(372, 21, 32, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(373, 21, 33, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(374, 21, 34, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(375, 21, 35, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(376, 21, 36, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(377, 21, 37, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(378, 21, 38, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(379, 21, 39, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(380, 21, 40, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(381, 21, 41, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(382, 21, 42, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(383, 21, 43, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(384, 21, 44, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(385, 21, 45, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(386, 21, 46, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(387, 21, 47, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(388, 21, 48, 'PON', 'available', NULL, NULL, '2026-08-07 16:10:40', '2026-08-09 15:42:17', NULL, NULL, NULL),
(389, 15, 41, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(390, 15, 42, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(391, 15, 43, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(392, 15, 44, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(393, 15, 45, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(394, 15, 46, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(395, 15, 47, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(396, 15, 48, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(397, 15, 49, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(398, 15, 50, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(399, 15, 51, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(400, 15, 52, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(401, 15, 53, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(402, 15, 54, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(403, 15, 55, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(404, 15, 56, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(405, 15, 57, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(406, 15, 58, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(407, 15, 59, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(408, 15, 60, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(409, 15, 61, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(410, 15, 62, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(411, 15, 63, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(412, 15, 64, 'PON', 'available', NULL, NULL, '2026-08-07 16:25:21', '2026-08-15 16:56:04', NULL, NULL, NULL),
(417, 22, 1, 'PON', 'available', NULL, NULL, '2026-08-07 16:39:44', '2026-08-07 16:39:44', NULL, NULL, NULL),
(418, 22, 2, 'PON', 'available', NULL, NULL, '2026-08-07 16:39:44', '2026-08-07 16:39:44', NULL, NULL, NULL),
(419, 22, 3, 'PON', 'available', NULL, NULL, '2026-08-07 16:39:44', '2026-08-07 16:39:44', NULL, NULL, NULL),
(420, 22, 4, 'PON', 'available', NULL, NULL, '2026-08-07 16:39:44', '2026-08-07 16:39:44', NULL, NULL, NULL),
(421, 22, 5, 'PON', 'available', NULL, NULL, '2026-08-07 16:39:44', '2026-08-07 16:39:44', NULL, NULL, NULL),
(422, 22, 6, 'PON', 'available', NULL, NULL, '2026-08-07 16:39:44', '2026-08-07 16:39:44', NULL, NULL, NULL),
(423, 22, 7, 'PON', 'available', NULL, NULL, '2026-08-07 16:39:44', '2026-08-07 16:39:44', NULL, NULL, NULL),
(424, 22, 8, 'PON', 'available', NULL, NULL, '2026-08-07 16:39:44', '2026-08-07 16:39:44', NULL, NULL, NULL),
(425, 23, 1, 'SC_APC', 'available', NULL, NULL, '2026-08-07 16:40:33', '2026-08-07 16:41:03', NULL, NULL, NULL),
(426, 23, 2, 'SC_APC', 'available', NULL, NULL, '2026-08-07 16:40:33', '2026-08-07 16:41:03', NULL, NULL, NULL),
(427, 23, 3, 'SC_APC', 'available', NULL, NULL, '2026-08-07 16:40:33', '2026-08-07 16:41:03', NULL, NULL, NULL),
(428, 23, 4, 'SC_APC', 'available', NULL, NULL, '2026-08-07 16:40:33', '2026-08-07 16:41:03', NULL, NULL, NULL);

INSERT INTO "network_ports" ("id", "node_id", "port_number", "port_type", "status", "connected_to_port_id", "notes", "created_at", "updated_at", "customer_service_id", "customer_name_cache", "destination_label") VALUES
(429, 23, 5, 'SC_APC', 'available', NULL, NULL, '2026-08-07 16:40:33', '2026-08-07 16:41:03', NULL, NULL, NULL),
(430, 23, 6, 'SC_APC', 'available', NULL, NULL, '2026-08-07 16:40:33', '2026-08-07 16:41:03', NULL, NULL, NULL),
(431, 23, 7, 'SC_APC', 'available', NULL, NULL, '2026-08-07 16:40:33', '2026-08-07 16:41:03', NULL, NULL, NULL),
(432, 23, 8, 'SC_APC', 'available', NULL, NULL, '2026-08-07 16:40:33', '2026-08-07 16:41:03', NULL, NULL, NULL),
(433, 24, 1, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(434, 24, 2, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(435, 24, 3, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(436, 24, 4, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(437, 24, 5, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(438, 24, 6, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(439, 24, 7, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(440, 24, 8, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(441, 24, 9, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(442, 24, 10, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(443, 24, 11, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(444, 24, 12, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(445, 24, 13, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(446, 24, 14, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(447, 24, 15, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(448, 24, 16, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(449, 24, 17, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(450, 24, 18, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(451, 24, 19, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(452, 24, 20, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(453, 24, 21, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(454, 24, 22, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(455, 24, 23, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(456, 24, 24, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(457, 24, 25, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(458, 24, 26, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(459, 24, 27, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(460, 24, 28, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(461, 24, 29, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(462, 24, 30, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(463, 24, 31, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(464, 24, 32, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(465, 24, 33, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(466, 24, 34, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(467, 24, 35, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(468, 24, 36, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(469, 24, 37, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(470, 24, 38, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(471, 24, 39, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(472, 24, 40, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(473, 24, 41, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(474, 24, 42, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(475, 24, 43, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(476, 24, 44, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(477, 24, 45, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(478, 24, 46, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(479, 24, 47, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(480, 24, 48, 'PON', 'available', NULL, NULL, '2026-08-09 12:28:37', '2026-08-09 12:28:37', NULL, NULL, NULL),
(481, 25, 1, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(482, 25, 2, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(483, 25, 3, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(484, 25, 4, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(485, 25, 5, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(486, 25, 6, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(487, 25, 7, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(488, 25, 8, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(489, 25, 9, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(490, 25, 10, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(491, 25, 11, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(492, 25, 12, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(493, 25, 13, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(494, 25, 14, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(495, 25, 15, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(496, 25, 16, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(497, 25, 17, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(498, 25, 18, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(499, 25, 19, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(500, 25, 20, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(501, 25, 21, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(502, 25, 22, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(503, 25, 23, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(504, 25, 24, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(505, 25, 25, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(506, 25, 26, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(507, 25, 27, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(508, 25, 28, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(509, 25, 29, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(510, 25, 30, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(511, 25, 31, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(512, 25, 32, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(513, 25, 33, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(514, 25, 34, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(515, 25, 35, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(516, 25, 36, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(517, 25, 37, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(518, 25, 38, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(519, 25, 39, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(520, 25, 40, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(521, 25, 41, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(522, 25, 42, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(523, 25, 43, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(524, 25, 44, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(525, 25, 45, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(526, 25, 46, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(527, 25, 47, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(528, 25, 48, 'PON', 'available', NULL, NULL, '2026-08-09 12:29:12', '2026-08-09 12:29:12', NULL, NULL, NULL),
(533, 26, 1, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(534, 26, 2, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(535, 26, 3, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(536, 26, 4, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(537, 26, 5, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(538, 26, 6, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(539, 26, 7, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(540, 26, 8, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(541, 26, 9, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(542, 26, 10, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(543, 26, 11, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(544, 26, 12, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(545, 26, 13, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(546, 26, 14, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(547, 26, 15, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(548, 26, 16, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(549, 26, 17, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(550, 26, 18, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(551, 26, 19, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(552, 26, 20, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(553, 26, 21, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(554, 26, 22, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(555, 26, 23, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(556, 26, 24, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(557, 26, 25, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(558, 26, 26, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(559, 26, 27, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(560, 26, 28, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(561, 26, 29, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(562, 26, 30, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(563, 26, 31, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(564, 26, 32, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(565, 26, 33, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(566, 26, 34, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(567, 26, 35, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(568, 26, 36, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(569, 26, 37, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(570, 26, 38, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(571, 26, 39, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(572, 26, 40, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(573, 26, 41, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(574, 26, 42, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(575, 26, 43, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(576, 26, 44, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(577, 26, 45, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(578, 26, 46, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(579, 26, 47, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(580, 26, 48, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(581, 26, 49, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(582, 26, 50, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(583, 26, 51, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(584, 26, 52, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(585, 26, 53, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(586, 26, 54, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(587, 26, 55, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(588, 26, 56, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(589, 26, 57, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(590, 26, 58, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(591, 26, 59, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(592, 26, 60, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(593, 26, 61, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(594, 26, 62, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(595, 26, 63, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(596, 26, 64, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(597, 26, 65, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(598, 26, 66, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(599, 26, 67, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(600, 26, 68, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(601, 26, 69, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(602, 26, 70, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(603, 26, 71, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(604, 26, 72, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(605, 26, 73, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(606, 26, 74, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(607, 26, 75, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(608, 26, 76, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(609, 26, 77, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(610, 26, 78, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(611, 26, 79, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(612, 26, 80, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(613, 26, 81, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(614, 26, 82, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(615, 26, 83, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(616, 26, 84, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(617, 26, 85, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(618, 26, 86, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(619, 26, 87, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(620, 26, 88, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(621, 26, 89, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(622, 26, 90, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(623, 26, 91, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(624, 26, 92, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(625, 26, 93, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(626, 26, 94, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(627, 26, 95, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(628, 26, 96, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(629, 26, 97, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(630, 26, 98, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(631, 26, 99, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(632, 26, 100, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL);

INSERT INTO "network_ports" ("id", "node_id", "port_number", "port_type", "status", "connected_to_port_id", "notes", "created_at", "updated_at", "customer_service_id", "customer_name_cache", "destination_label") VALUES
(633, 26, 101, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(634, 26, 102, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(635, 26, 103, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(636, 26, 104, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(637, 26, 105, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(638, 26, 106, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(639, 26, 107, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(640, 26, 108, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(641, 26, 109, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(642, 26, 110, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(643, 26, 111, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(644, 26, 112, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(645, 26, 113, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(646, 26, 114, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(647, 26, 115, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(648, 26, 116, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(649, 26, 117, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(650, 26, 118, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(651, 26, 119, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(652, 26, 120, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(653, 26, 121, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(654, 26, 122, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(655, 26, 123, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(656, 26, 124, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(657, 26, 125, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(658, 26, 126, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(659, 26, 127, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(660, 26, 128, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(661, 26, 129, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(662, 26, 130, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(663, 26, 131, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(664, 26, 132, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(665, 26, 133, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(666, 26, 134, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(667, 26, 135, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(668, 26, 136, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(669, 26, 137, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(670, 26, 138, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(671, 26, 139, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(672, 26, 140, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(673, 26, 141, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(674, 26, 142, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(675, 26, 143, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(676, 26, 144, 'PON', 'available', NULL, NULL, '2026-08-15 13:59:50', '2026-08-15 14:02:48', NULL, NULL, NULL),
(677, 15, 65, 'PON', 'available', NULL, NULL, '2026-08-15 16:47:15', '2026-08-15 16:56:04', NULL, NULL, NULL),
(678, 15, 66, 'PON', 'available', NULL, NULL, '2026-08-15 16:47:15', '2026-08-15 16:56:04', NULL, NULL, NULL),
(679, 15, 67, 'PON', 'available', NULL, NULL, '2026-08-15 16:47:15', '2026-08-15 16:56:04', NULL, NULL, NULL),
(680, 15, 68, 'PON', 'available', NULL, NULL, '2026-08-15 16:47:15', '2026-08-15 16:56:04', NULL, NULL, NULL),
(681, 32, 1, 'PON', 'available', NULL, NULL, '2026-08-17 15:56:53', '2026-08-17 15:56:53', NULL, NULL, NULL),
(682, 32, 2, 'PON', 'available', NULL, NULL, '2026-08-17 15:56:53', '2026-08-17 15:56:53', NULL, NULL, NULL),
(683, 32, 3, 'PON', 'available', NULL, NULL, '2026-08-17 15:56:53', '2026-08-17 15:56:53', NULL, NULL, NULL),
(684, 32, 4, 'PON', 'available', NULL, NULL, '2026-08-17 15:56:53', '2026-08-17 15:56:53', NULL, NULL, NULL),
(685, 32, 5, 'PON', 'available', NULL, NULL, '2026-08-17 15:56:53', '2026-08-17 15:56:53', NULL, NULL, NULL),
(686, 32, 6, 'PON', 'available', NULL, NULL, '2026-08-17 15:56:53', '2026-08-17 15:56:53', NULL, NULL, NULL),
(687, 32, 7, 'PON', 'available', NULL, NULL, '2026-08-17 15:56:53', '2026-08-17 15:56:53', NULL, NULL, NULL),
(688, 32, 8, 'PON', 'available', NULL, NULL, '2026-08-17 15:56:53', '2026-08-17 15:56:53', NULL, NULL, NULL),
(689, 32, 9, 'PON', 'available', NULL, NULL, '2026-08-17 15:56:53', '2026-08-17 15:56:53', NULL, NULL, NULL),
(690, 32, 10, 'PON', 'available', NULL, NULL, '2026-08-17 15:56:53', '2026-08-17 15:56:53', NULL, NULL, NULL),
(691, 32, 11, 'PON', 'available', NULL, NULL, '2026-08-17 15:56:53', '2026-08-17 15:56:53', NULL, NULL, NULL),
(692, 32, 12, 'PON', 'available', NULL, NULL, '2026-08-17 15:56:53', '2026-08-17 15:56:53', NULL, NULL, NULL),
(693, 32, 13, 'PON', 'available', NULL, NULL, '2026-08-17 15:56:53', '2026-08-17 15:56:53', NULL, NULL, NULL),
(694, 32, 14, 'PON', 'available', NULL, NULL, '2026-08-17 15:56:53', '2026-08-17 15:56:53', NULL, NULL, NULL),
(695, 32, 15, 'PON', 'available', NULL, NULL, '2026-08-17 15:56:53', '2026-08-17 15:56:53', NULL, NULL, NULL),
(696, 32, 16, 'PON', 'available', NULL, NULL, '2026-08-17 15:56:53', '2026-08-17 15:56:53', NULL, NULL, NULL);

SELECT setval('public.network_ports_id_seq', COALESCE((SELECT MAX("id") FROM "network_ports"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "network_splitters"
-- ----------------------------------------------------------

TRUNCATE TABLE "network_splitters" CASCADE;

SELECT setval('public.network_splitters_id_seq', COALESCE((SELECT MAX("id") FROM "network_splitters"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "olt_devices"
-- ----------------------------------------------------------

TRUNCATE TABLE "olt_devices" CASCADE;

INSERT INTO "olt_devices" ("id", "name", "code", "vendor", "model", "vendor_key", "location", "ip_address", "total_ports", "deployment_mode", "snmp_version", "snmp_community_type", "snmp_community_string", "snmp_v3_username", "snmp_v3_auth_protocol", "snmp_v3_auth_password", "snmp_v3_priv_protocol", "snmp_v3_priv_password", "snmp_port", "snmp_timeout", "snmp_retries", "cli_protocol", "cli_username", "cli_password", "cli_port", "probe_agent_url", "probe_agent_token", "status", "connection_mode", "last_connected_at", "last_ping_ms", "last_telemetry_snapshot", "created_at", "updated_at") VALUES
(13, 'OLT-SOLOK-ZTE C300', 'OLT-SLK-O1', 'ZTE', 'ZXAN C300', 'zte', 'KANTOR CINOX MEDIA NETWORK', '10.10.10.2', 16, 'direct', 'v2c', 'public', 'eyJpdiI6IlNhdDhhOXdVc1lid09NWDlycktIcUE9PSIsInZhbHVlIjoiajJrY2oxYWcwVmUrbE91TWE5OFZKUT09IiwibWFjIjoiYWU5ZTEyMTFhNmE0ODkyYWQ2NGJiOWY1MDBmZTEwYzgzMmViYjA2NDI2Zjc4OGFjNjcxZmY0YzQ2NTlkNjZmMSIsInRhZyI6IiJ9', NULL, 'SHA', NULL, 'AES', NULL, 1611, 5, 2, 'ssh', 'admin', 'eyJpdiI6IldMUzdMY3h5Y3ZYSWUyQWxoMExHbFE9PSIsInZhbHVlIjoiaDhoWURmR2lKY3Jia21NbDNla3NkUT09IiwibWFjIjoiOWUwOGNmYmFkMzhhMTgzOTZkNzI5YWZlMmExOGI1ZGY3N2M5NjQ0ZGNkNmMwNTYyNzY2YzFhOTI2YzUzNjRiMyIsInRhZyI6IiJ9', 22, NULL, NULL, 'active', 'simulation', '2026-08-15 17:37:10', NULL, NULL, '2026-08-05 09:53:04', '2026-08-15 17:37:10'),
(20, 'asdasd', 'ASDASD', 'ZTE', 'ZXAN C300', 'zte', 'asdsad', '1.1.1.1', 16, 'direct', 'v2c', 'public', 'eyJpdiI6ImhQRzNMTjRNUUNmdEF1a05VZzhWcUE9PSIsInZhbHVlIjoiSFVjWnpyUVhmUVJzVUs1QTdMeFJCQT09IiwibWFjIjoiNmRhOGViODQ1NWY0NTM1M2ZiM2IwMTNmMWUwZDUzYzk3NWQwYWFiZGIwNmJlMWQwYTNjODhiNTBjMmI1ODAzOCIsInRhZyI6IiJ9', NULL, 'SHA', NULL, 'AES', NULL, 161, 5, 2, 'telnet', NULL, NULL, 23, NULL, NULL, 'active', 'simulation', NULL, NULL, NULL, '2026-08-15 17:49:00', '2026-08-15 17:49:00');

SELECT setval('public.olt_devices_id_seq', COALESCE((SELECT MAX("id") FROM "olt_devices"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "ont_registrations"
-- ----------------------------------------------------------

TRUNCATE TABLE "ont_registrations" CASCADE;

INSERT INTO "ont_registrations" ("id", "customer_service_id", "olt_port_id", "onu_serial", "onu_mac", "onu_type", "profile_name", "vlan_id", "status", "registered_at", "last_online_at", "rx_power", "tx_power", "notes", "created_at", "updated_at", "deleted_at") VALUES
(17, 20, NULL, 'ZTEG-C881A201', NULL, 'ZTE ONU', NULL, NULL, 'active', '2026-08-14 12:41:20', NULL, -19.50, NULL, NULL, '2026-08-14 12:41:20', '2026-08-14 12:41:20', NULL);

SELECT setval('public.ont_registrations_id_seq', COALESCE((SELECT MAX("id") FROM "ont_registrations"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "password_reset_tokens"
-- ----------------------------------------------------------

TRUNCATE TABLE "password_reset_tokens" CASCADE;


-- ----------------------------------------------------------
-- Struktur & Data Tabel: "permissions"
-- ----------------------------------------------------------

TRUNCATE TABLE "permissions" CASCADE;

INSERT INTO "permissions" ("id", "name", "slug", "group", "created_at", "updated_at") VALUES
(1, 'View Customers', 'view_customers', 'customers', '2026-08-04 08:46:01', '2026-08-04 08:46:01'),
(2, 'Edit Devices', 'edit_devices', 'devices', '2026-08-04 08:46:01', '2026-08-04 08:46:01'),
(3, 'Create Work Orders', 'create_workorders', 'workorders', '2026-08-04 08:46:01', '2026-08-04 08:46:01'),
(4, 'Assign Tickets', 'assign_tickets', 'tickets', '2026-08-04 08:46:01', '2026-08-04 08:46:01');

SELECT setval('public.permissions_id_seq', COALESCE((SELECT MAX("id") FROM "permissions"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "pppoe_profiles"
-- ----------------------------------------------------------

TRUNCATE TABLE "pppoe_profiles" CASCADE;

INSERT INTO "pppoe_profiles" ("id", "name", "service_package_id", "max_rate_kbps", "burst_kbps", "access_type", "description", "created_at", "updated_at") VALUES
(1, 'Home 20Mbps', 1, 20480, 25600, 'static', 'PPPoE profile for 20 Mbps residential package', '2026-08-04 08:46:01', '2026-08-04 08:46:01');

SELECT setval('public.pppoe_profiles_id_seq', COALESCE((SELECT MAX("id") FROM "pppoe_profiles"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "provinces"
-- ----------------------------------------------------------

TRUNCATE TABLE "provinces" CASCADE;

SELECT setval('public.provinces_id_seq', COALESCE((SELECT MAX("id") FROM "provinces"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "push_subscriptions"
-- ----------------------------------------------------------

TRUNCATE TABLE "push_subscriptions" CASCADE;

SELECT setval('public.push_subscriptions_id_seq', COALESCE((SELECT MAX("id") FROM "push_subscriptions"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "regencies"
-- ----------------------------------------------------------

TRUNCATE TABLE "regencies" CASCADE;

SELECT setval('public.regencies_id_seq', COALESCE((SELECT MAX("id") FROM "regencies"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "role_permission"
-- ----------------------------------------------------------

TRUNCATE TABLE "role_permission" CASCADE;

INSERT INTO "role_permission" ("role_id", "permission_id") VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4);


-- ----------------------------------------------------------
-- Struktur & Data Tabel: "roles"
-- ----------------------------------------------------------

TRUNCATE TABLE "roles" CASCADE;

INSERT INTO "roles" ("id", "name", "slug", "description", "created_at", "updated_at") VALUES
(1, 'Administrator', 'admin', NULL, '2026-08-04 08:46:01', '2026-08-04 08:46:01'),
(2, 'Network Engineer', 'net_eng', NULL, '2026-08-04 08:46:01', '2026-08-04 08:46:01'),
(3, 'Field Technician', 'tech', NULL, '2026-08-04 08:46:01', '2026-08-04 08:46:01'),
(4, 'Customer Service', 'cs', NULL, '2026-08-04 08:46:01', '2026-08-04 08:46:01');

SELECT setval('public.roles_id_seq', COALESCE((SELECT MAX("id") FROM "roles"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "service_packages"
-- ----------------------------------------------------------

TRUNCATE TABLE "service_packages" CASCADE;

INSERT INTO "service_packages" ("id", "name", "code", "speed_mbps", "price", "description", "is_active", "created_at", "updated_at", "deleted_at") VALUES
(1, 'Home Basic 20Mbps', 'HOME_20', 20, 250000.00, NULL, TRUE, '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL),
(2, 'Business Pro 100Mbps', 'BUS_100', 100, 900000.00, NULL, TRUE, '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL);

SELECT setval('public.service_packages_id_seq', COALESCE((SELECT MAX("id") FROM "service_packages"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "service_quotas"
-- ----------------------------------------------------------

TRUNCATE TABLE "service_quotas" CASCADE;

SELECT setval('public.service_quotas_id_seq', COALESCE((SELECT MAX("id") FROM "service_quotas"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "service_surveys"
-- ----------------------------------------------------------

TRUNCATE TABLE "service_surveys" CASCADE;

SELECT setval('public.service_surveys_id_seq', COALESCE((SELECT MAX("id") FROM "service_surveys"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "sessions"
-- ----------------------------------------------------------

TRUNCATE TABLE "sessions" CASCADE;

INSERT INTO "sessions" ("id", "user_id", "ip_address", "user_agent", "payload", "last_activity") VALUES
('dEzqUeBdgeaUByDgoJEKnaMtkWzUirR5t9ot8ULD', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', 'eyJfdG9rZW4iOiJtdXdhVFVCRHZoY1RsUjBnNlNmaDBjcmNHU05heVRjaTZRVXRFT0l3IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MDAwXC9kYXNoYm9hcmQiLCJyb3V0ZSI6bnVsbH0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=', 1786983825),
('xcoQ9hfDKEVfFLamrKuPYBhLSvgTDY5p9WGDsHEN', NULL, '192.168.0.100', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36', 'eyJfdG9rZW4iOiJOemNQUnY2NUxmZ0xyRlM2YjNwOHpGYmZFcGtpSkxMRWFvTU5PenB5IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzE5Mi4xNjguMC4xMDE6ODAwMCIsInJvdXRlIjpudWxsfSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1786980663);


-- ----------------------------------------------------------
-- Struktur & Data Tabel: "splitter_types"
-- ----------------------------------------------------------

TRUNCATE TABLE "splitter_types" CASCADE;

INSERT INTO "splitter_types" ("id", "name", "ratio", "input_ports", "output_ports", "loss_db", "description", "created_at", "updated_at", "deleted_at") VALUES
(4, 'PLC 1:2', '1:2', 1, 2, 3.40, 'Level 1 — Dipasang di POP pada konfigurasi A (1:2→1:8→1:8). Membagi 1 core OLT menjadi 2 output ke 2 ODC.', '2026-08-04 13:48:22', '2026-08-04 13:48:22', NULL),
(5, 'PLC 1:4', '1:4', 1, 4, 6.90, 'Level 1/2 — Dipasang di ODC Induk pada konfigurasi B (1:4→1:4→1:8). Membagi 1 core OLT menjadi 4 output ke 4 ODC Anak.', '2026-08-04 13:48:22', '2026-08-04 13:48:22', NULL),
(6, 'PLC 1:8', '1:8', 1, 8, 10.30, 'Level 2 — Dipasang di ODC pada konfigurasi A (1:2→1:8→1:8). Juga dipakai di ODC Anak pada konfigurasi B (1:4→1:4→1:8). Membagi ke 8 ODP.', '2026-08-04 13:48:22', '2026-08-04 13:48:22', NULL),
(7, 'PLC 1:8 ODP', '1:8', 1, 8, 10.30, 'Level 3 — Dipasang di dalam ODP (last mile). Digunakan di kedua konfigurasi A & B. Membagi ke max 8 pelanggan (port drop ke ONT).', '2026-08-04 13:48:22', '2026-08-04 13:48:22', NULL),
(8, 'PLC 1:4 ODP', '1:4', 1, 4, 6.90, 'Level 3 — ODP kapasitas kecil 4 port, digunakan di lokasi dengan kepadatan pelanggan rendah.', '2026-08-04 13:48:22', '2026-08-04 13:48:22', NULL),
(9, 'PLC 1:16', '1:16', 1, 16, 13.50, 'Splitter 1:16 — Umumnya dipasang di ODC besar menggantikan dua tingkat split (ODC+ODP dalam satu titik).', '2026-08-04 13:48:22', '2026-08-04 13:48:22', NULL),
(10, 'PLC 1:32', '1:32', 1, 32, 16.70, 'Splitter 1:32 — Kapasitas besar, digunakan di gedung/apartemen dengan banyak unit.', '2026-08-04 13:48:22', '2026-08-04 13:48:22', NULL);

SELECT setval('public.splitter_types_id_seq', COALESCE((SELECT MAX("id") FROM "splitter_types"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "system_notifications"
-- ----------------------------------------------------------

TRUNCATE TABLE "system_notifications" CASCADE;

INSERT INTO "system_notifications" ("id", "user_id", "type", "title", "body", "url", "icon", "is_read", "read_at", "created_at", "updated_at", "deleted_at") VALUES
(1, NULL, 'NOC', ' Notifikasi Tes Perangkat Berhasil!', 'Halo User, notifikasi sistem UNMS di perangkat Anda telah aktif & berfungsi 100% normal.', '/dashboard', NULL, TRUE, '2026-08-14 14:29:55', '2026-08-14 14:22:05', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(2, NULL, 'NOC', ' Notifikasi Tes Perangkat Berhasil!', 'Halo User, notifikasi sistem UNMS di perangkat Windows / Mobile telah aktif & berfungsi 100% normal.', '/dashboard', NULL, TRUE, '2026-08-14 14:30:11', '2026-08-14 14:26:17', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(3, NULL, 'NOC', ' Notifikasi Tes Perangkat Berhasil!', 'Halo User, notifikasi sistem UNMS di perangkat Windows / Mobile telah aktif & berfungsi 100% normal.', '/dashboard', NULL, TRUE, '2026-08-14 14:36:22', '2026-08-14 14:30:50', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(4, NULL, 'NOC', ' Notifikasi Tes Perangkat Berhasil!', 'Halo User, notifikasi sistem UNMS di perangkat Windows / Mobile telah aktif & berfungsi 100% normal.', '/dashboard', NULL, TRUE, '2026-08-14 14:40:35', '2026-08-14 14:40:08', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(5, NULL, 'NOC', ' Notifikasi Tes Perangkat Berhasil!', 'Halo User, notifikasi sistem UNMS di perangkat Windows / Mobile telah aktif & berfungsi 100% normal.', '/dashboard', NULL, TRUE, '2026-08-14 14:41:07', '2026-08-14 14:40:47', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(6, NULL, 'NOC', ' Notifikasi Tes Perangkat Berhasil!', 'Halo User, notifikasi sistem UNMS di perangkat Windows / Mobile telah aktif & berfungsi 100% normal.', '/dashboard', NULL, TRUE, '2026-08-14 14:42:08', '2026-08-14 14:41:09', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(7, NULL, 'NOC', ' Notifikasi Tes Perangkat Berhasil!', 'Halo User, notifikasi sistem UNMS di perangkat Windows / Mobile telah aktif & berfungsi 100% normal.', '/dashboard', NULL, TRUE, '2026-08-14 14:42:08', '2026-08-14 14:41:29', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(8, NULL, 'NOC', ' Notifikasi Tes Perangkat Berhasil!', 'Halo User, notifikasi sistem UNMS di perangkat Windows / Mobile telah aktif & berfungsi 100% normal.', '/dashboard', NULL, TRUE, '2026-08-14 14:42:27', '2026-08-14 14:42:16', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(9, NULL, 'NOC', ' Notifikasi Tes Perangkat Berhasil!', 'Halo User, notifikasi sistem UNMS di perangkat Windows / Mobile telah aktif & berfungsi 100% normal.', '/dashboard', NULL, TRUE, '2026-08-14 14:42:47', '2026-08-14 14:42:34', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(10, NULL, 'NOC', ' Alert Siaran UNMS Sistem', 'Notifikasi ini otomatis dikirim ke seluruh user (Super Admin, NOC, CS, Teknisi) di sistem UNMS.', '/dashboard', NULL, TRUE, '2026-08-14 14:44:38', '2026-08-14 14:44:15', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(11, NULL, 'NOC', ' Notifikasi Tes Perangkat Berhasil!', 'Halo User, notifikasi sistem UNMS di perangkat Windows / Mobile telah aktif & berfungsi 100% normal.', '/dashboard', NULL, TRUE, '2026-08-14 14:46:18', '2026-08-14 14:45:51', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(12, NULL, 'NOC', ' Notifikasi Tes Perangkat Berhasil!', 'Halo User, notifikasi sistem UNMS di perangkat Windows / Mobile telah aktif & berfungsi 100% normal.', '/dashboard', NULL, TRUE, '2026-08-14 14:46:47', '2026-08-14 14:46:32', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(13, NULL, 'NOC', '🚨 Perhatian: Pemeliharaan Sistem NOC Solok', 'Diberitahukan kepada seluruh tim NOC dan teknisi bahwa akan dilakukan pemeliharaan perangkat OLT Solok pada pukul 23:00 WIB.', '/dashboard', NULL, TRUE, '2026-08-14 14:47:28', '2026-08-14 14:47:14', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(14, NULL, 'NOC', 'Gangguan Putus Kabel Optik Segmen Solok', 'Diharapkan tim teknisi jointer meluncur ke lokasi ODC-SLK-01 untuk perbaikan penyambungan core fiber.', '/tickets', NULL, TRUE, '2026-08-14 14:48:23', '2026-08-14 14:48:07', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(15, NULL, 'NOC', 'Gangguan Putus Kabel Optik Segmen Solok', 'Diharapkan tim teknisi jointer meluncur ke lokasi ODC-SLK-01 untuk perbaikan penyambungan core fiber.', '/tickets', NULL, TRUE, '2026-08-14 14:50:47', '2026-08-14 14:50:30', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(16, NULL, 'NOC', 'Gangguan Putus Kabel Optik Segmen Solok', 'Diharapkan tim teknisi jointer meluncur ke lokasi ODC-SLK-01 untuk perbaikan penyambungan core fiber.', '/tickets', NULL, TRUE, '2026-08-14 14:53:19', '2026-08-14 14:52:44', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(17, NULL, 'NOC', ' Notifikasi Tes Perangkat Berhasil!', 'Halo User, notifikasi sistem UNMS di perangkat Windows / Mobile telah aktif & berfungsi 100% normal.', '/dashboard', NULL, TRUE, '2026-08-14 14:53:19', '2026-08-14 14:53:07', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(18, NULL, 'NOC', ' Notifikasi Tes Perangkat Berhasil!', 'Halo User, notifikasi sistem UNMS di perangkat Windows / Mobile telah aktif & berfungsi 100% normal.', '/dashboard', NULL, TRUE, '2026-08-14 14:56:39', '2026-08-14 14:56:21', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(19, NULL, 'NOC', ' Notifikasi Tes Perangkat Berhasil!', 'Halo User, notifikasi sistem UNMS di perangkat Windows / Mobile telah aktif & berfungsi 100% normal.', '/dashboard', NULL, TRUE, '2026-08-14 14:57:07', '2026-08-14 14:56:57', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(20, NULL, 'NOC', 'Gangguan Putus Kabel Optik Segmen Solok', 'Diharapkan tim teknisi jointer meluncur ke lokasi ODC-SLK-01 untuk perbaikan penyambungan core fiber.', '/tickets', NULL, TRUE, '2026-08-14 14:57:44', '2026-08-14 14:57:12', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(21, NULL, 'NOC', ' Notifikasi Tes Perangkat Berhasil!', 'Halo User, notifikasi sistem UNMS di perangkat Windows / Mobile telah aktif & berfungsi 100% normal.', '/dashboard', NULL, TRUE, '2026-08-14 14:57:41', '2026-08-14 14:57:30', '2026-08-14 14:59:13', '2026-08-14 14:59:13'),
(22, NULL, 'NOC', 'Tiket Gangguan Baru #TICK-2026-0001', 'Prioritas Critical: asasd', '/tickets', NULL, TRUE, '2026-08-14 15:01:43', '2026-08-14 15:01:17', '2026-08-14 15:50:33', '2026-08-14 15:50:33'),
(23, NULL, 'NOC', 'Gangguan Putus Kabel Optik Segmen Solok', 'Diharapkan tim teknisi jointer meluncur ke lokasi ODC-SLK-01 untuk perbaikan penyambungan core fiber.', '/tickets', NULL, TRUE, '2026-08-14 15:50:19', '2026-08-14 15:49:24', '2026-08-14 15:50:33', '2026-08-14 15:50:33'),
(24, NULL, 'NOC', ' Notifikasi Tes Perangkat Berhasil!', 'Halo User, notifikasi sistem UNMS di perangkat Windows / Mobile telah aktif & berfungsi 100% normal.', '/dashboard', NULL, TRUE, '2026-08-14 15:50:19', '2026-08-14 15:50:12', '2026-08-14 15:50:33', '2026-08-14 15:50:33'),
(25, NULL, 'NOC', 'Gangguan Putus Kabel Optik Segmen Solok', 'Diharapkan tim teknisi jointer meluncur ke lokasi ODC-SLK-01 untuk perbaikan penyambungan core fiber.', '/tickets', NULL, FALSE, NULL, '2026-08-14 15:50:23', '2026-08-14 15:50:33', '2026-08-14 15:50:33'),
(26, NULL, 'NOC', ' Notifikasi Tes Perangkat Berhasil!', 'Halo User, notifikasi sistem UNMS di perangkat Windows / Mobile telah aktif & berfungsi 100% normal.', '/dashboard', NULL, TRUE, '2026-08-15 15:55:18', '2026-08-15 15:54:59', '2026-08-15 15:57:23', '2026-08-15 15:57:23'),
(27, NULL, 'NOC', '🚨 Gangguan Putus Kabel Optik Segmen Solok', 'Diharapkan tim teknisi jointer meluncur ke lokasi ODC-SLK-01 untuk perbaikan penyambungan core fiber.', '/tickets', NULL, FALSE, NULL, '2026-08-15 15:57:28', '2026-08-15 15:57:57', '2026-08-15 15:57:57'),
(28, NULL, 'NOC', 'Tiket Gangguan Baru #TICK-2026-0001', 'Prioritas High: sdasd', '/tickets', NULL, TRUE, '2026-08-15 17:02:36', '2026-08-15 16:30:02', '2026-08-15 17:02:36', NULL),
(29, NULL, 'NOC', '🚨 ALERT PUTUS OTDR: ODC 01 [ODC] → ODP 0001 [ODP]', 'Hasil penembakan OTDR disiarkan ke tim lapangan. Klik untuk melihat peta detail lokasi putus.', '/otdr-tracing', NULL, TRUE, '2026-08-17 14:24:21', '2026-08-17 14:20:33', '2026-08-17 14:24:21', NULL),
(30, NULL, 'NOC', '🚨 ALERT PUTUS OTDR: ODC 01 [ODC] → ODP 0001 [ODP]', 'Hasil penembakan OTDR disiarkan ke tim lapangan. Klik untuk melihat peta detail lokasi putus.', '/otdr-tracing', NULL, TRUE, '2026-08-17 14:46:20', '2026-08-17 14:29:26', '2026-08-17 14:46:20', NULL);

SELECT setval('public.system_notifications_id_seq', COALESCE((SELECT MAX("id") FROM "system_notifications"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "system_settings"
-- ----------------------------------------------------------

TRUNCATE TABLE "system_settings" CASCADE;

INSERT INTO "system_settings" ("id", "key", "value", "created_at", "updated_at") VALUES
(1, 'telegram_enabled', 'true', '2026-08-14 15:10:31', '2026-08-14 15:43:39'),
(2, 'telegram_bot_token', '8940294417:AAHoVnbFHl6xNFA6nq0AZ933kDXqnAqhooU', '2026-08-14 15:10:31', '2026-08-14 15:43:39'),
(3, 'telegram_chat_id', 1596876497, '2026-08-14 15:10:31', '2026-08-14 15:48:52');

SELECT setval('public.system_settings_id_seq', COALESCE((SELECT MAX("id") FROM "system_settings"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "telegram_channels"
-- ----------------------------------------------------------

TRUNCATE TABLE "telegram_channels" CASCADE;

SELECT setval('public.telegram_channels_id_seq', COALESCE((SELECT MAX("id") FROM "telegram_channels"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "tickets"
-- ----------------------------------------------------------

TRUNCATE TABLE "tickets" CASCADE;

INSERT INTO "tickets" ("id", "ticket_number", "title", "description", "category", "priority", "status", "customer_id", "network_node_id", "network_cable_id", "technician_name", "dispatch_team", "initial_power_dbm", "final_power_dbm", "materials_used", "timeline_logs", "sla_deadline", "is_sla_breached", "resolution_notes", "resolved_at", "created_at", "updated_at") VALUES
(8, 'TICK-2026-0001', 'sdasd', 'asd', 'Redaman Tinggi', 'High', 'In Progress', NULL, NULL, NULL, 'asdd', 'asd', 'asdd', NULL, NULL, '[{"time":"16:30","user":"Administrator","action":"Tiket dibuat dengan status ''Open'' dan prioritas ''High''."},{"time":"16:30 (15 Aug)","user":"Operator","action":"Status tiket diperbarui dari ''Open'' menjadi ''In Progress''."}]', '2026-08-15 20:30:02', FALSE, NULL, NULL, '2026-08-15 16:30:02', '2026-08-15 16:30:36');

SELECT setval('public.tickets_id_seq', COALESCE((SELECT MAX("id") FROM "tickets"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "user_role"
-- ----------------------------------------------------------

TRUNCATE TABLE "user_role" CASCADE;


-- ----------------------------------------------------------
-- Struktur & Data Tabel: "users"
-- ----------------------------------------------------------

TRUNCATE TABLE "users" CASCADE;

INSERT INTO "users" ("id", "name", "email", "email_verified_at", "password", "remember_token", "created_at", "updated_at", "role", "division", "phone", "status", "last_login_at", "username") VALUES
(10, 'Jasen', 'jasen@fiber-unms.id', NULL, '$2y$12$8qVpWDJeWaGIp9DDlj2GQeP9vOg1S.cBFKRgrnYYfMdJd0Wkzu1cK', NULL, '2026-08-09 15:51:41', '2026-08-17 16:31:29', 'Super Administrator', 'TIM FO', NULL, 'Active', '2026-08-17 15:44:40', 'jasen'),
(13, 'tim1', 'tim1@gmail.com', NULL, '$2y$12$LUltY5A6QVTria8gqHOC/ux.9Gd.mNwN5GsAkrexN7S.HS9n.ZB2e', NULL, '2026-08-12 14:45:15', '2026-08-16 12:26:05', 'Teknisi Jointer', 'Operasional Fiber', 08888888888, 'Active', '2026-08-16 11:35:11', 'tim1');

SELECT setval('public.users_id_seq', COALESCE((SELECT MAX("id") FROM "users"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "vendors"
-- ----------------------------------------------------------

TRUNCATE TABLE "vendors" CASCADE;

INSERT INTO "vendors" ("id", "name", "code", "contact_person", "phone", "email", "address", "is_active", "created_at", "updated_at", "deleted_at") VALUES
(1, 'FiberMax', 'FMAX', 'John Doe', '021-1234567', 'contact@fibermax.co.id', NULL, TRUE, '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL),
(2, 'OptiCable', 'OPTC', 'Jane Smith', '021-7654321', 'sales@opticable.com', NULL, TRUE, '2026-08-04 08:46:01', '2026-08-04 08:46:01', NULL);

SELECT setval('public.vendors_id_seq', COALESCE((SELECT MAX("id") FROM "vendors"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "villages"
-- ----------------------------------------------------------

TRUNCATE TABLE "villages" CASCADE;

SELECT setval('public.villages_id_seq', COALESCE((SELECT MAX("id") FROM "villages"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "vlan_assignments"
-- ----------------------------------------------------------

TRUNCATE TABLE "vlan_assignments" CASCADE;

SELECT setval('public.vlan_assignments_id_seq', COALESCE((SELECT MAX("id") FROM "vlan_assignments"), 1), true);

-- ----------------------------------------------------------
-- Struktur & Data Tabel: "voice_calls"
-- ----------------------------------------------------------

TRUNCATE TABLE "voice_calls" CASCADE;

INSERT INTO "voice_calls" ("id", "caller_id", "receiver_id", "status", "sdp_offer", "sdp_answer", "caller_ice", "receiver_ice", "started_at", "ended_at", "duration_seconds", "created_at", "updated_at") VALUES
(1, 13, 10, 'ended', '{"sdp":"v=0\r\no=- 1541169118553514236 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0\r\na=extmap-allow-mixed\r\na=msid-semantic: WMS acd8f2dd-52ee-4fdc-97ef-c20c56e29a96\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111 63 9 0 8 13 110 126\r\nc=IN IP4 0.0.0.0\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=ice-ufrag:KxB9\r\na=ice-pwd:1iL08uR86Un60B8PfDMRGLyh\r\na=ice-options:trickle\r\na=fingerprint:sha-256 6B:D9:BD:69:4B:98:62:61:D3:8A:F6:24:07:EF:E3:74:D2:B5:6F:3D:CA:63:8E:6B:3B:35:FE:66:8E:39:32:14\r\na=setup:actpass\r\na=mid:0\r\na=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level\r\na=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=extmap:4 urn:ietf:params:rtp-hdrext:sdes:mid\r\na=sendrecv\r\na=msid:acd8f2dd-52ee-4fdc-97ef-c20c56e29a96 486d24f2-cd8a-4506-9e62-85740b0b6405\r\na=rtcp-mux\r\na=rtcp-rsize\r\na=rtcp-xr:rcvr-rtt=all\r\na=rtcp-fb:111 rrtr\r\na=rtcp-fb:63 rrtr\r\na=rtcp-fb:9 rrtr\r\na=rtcp-fb:0 rrtr\r\na=rtcp-fb:8 rrtr\r\na=rtcp-fb:13 rrtr\r\na=rtcp-fb:110 rrtr\r\na=rtcp-fb:126 rrtr\r\na=rtpmap:111 opus/48000/2\r\na=rtcp-fb:111 transport-cc\r\na=fmtp:111 minptime=10;useinbandfec=1\r\na=rtpmap:63 red/48000/2\r\na=fmtp:63 111/111\r\na=rtpmap:9 G722/8000\r\na=rtpmap:0 PCMU/8000\r\na=rtpmap:8 PCMA/8000\r\na=rtpmap:13 CN/8000\r\na=rtpmap:110 telephone-event/48000\r\na=rtpmap:126 telephone-event/8000\r\na=ssrc:3440558791 cname:CgySANTdffHs3x5w\r\na=ssrc:3440558791 msid:acd8f2dd-52ee-4fdc-97ef-c20c56e29a96 486d24f2-cd8a-4506-9e62-85740b0b6405\r\n","type":"offer"}', '{"sdp":"v=0\r\no=- 7488264119078299199 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0\r\na=extmap-allow-mixed\r\na=msid-semantic: WMS 98973feb-32fa-4003-9fab-2066e165b1a4\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111 63 9 0 8 13 110 126\r\nc=IN IP4 0.0.0.0\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=ice-ufrag:bYNZ\r\na=ice-pwd:WtW4fdDYtPxvSOJ5kut9aw9d\r\na=ice-options:trickle\r\na=fingerprint:sha-256 F6:06:0D:F2:BA:5C:E9:EC:D5:23:A4:F6:A7:EC:67:E2:24:FC:12:E0:0E:B5:CE:B6:D4:E7:D0:5E:C2:A6:78:3F\r\na=setup:active\r\na=mid:0\r\na=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level\r\na=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=extmap:4 urn:ietf:params:rtp-hdrext:sdes:mid\r\na=sendrecv\r\na=msid:98973feb-32fa-4003-9fab-2066e165b1a4 37c41308-58fa-48d7-bb47-b44f9ee2c004\r\na=rtcp-mux\r\na=rtcp-rsize\r\na=rtcp-xr:rcvr-rtt=all\r\na=rtcp-fb:111 rrtr\r\na=rtcp-fb:63 rrtr\r\na=rtcp-fb:9 rrtr\r\na=rtcp-fb:0 rrtr\r\na=rtcp-fb:8 rrtr\r\na=rtcp-fb:13 rrtr\r\na=rtcp-fb:110 rrtr\r\na=rtcp-fb:126 rrtr\r\na=rtpmap:111 opus/48000/2\r\na=rtcp-fb:111 transport-cc\r\na=fmtp:111 minptime=10;useinbandfec=1\r\na=rtpmap:63 red/48000/2\r\na=fmtp:63 111/111\r\na=rtpmap:9 G722/8000\r\na=rtpmap:0 PCMU/8000\r\na=rtpmap:8 PCMA/8000\r\na=rtpmap:13 CN/8000\r\na=rtpmap:110 telephone-event/48000\r\na=rtpmap:126 telephone-event/8000\r\na=ssrc:1171340028 cname:UoMQBO4QNfvTWZIl\r\n","type":"answer"}', '[]', '[{"candidate":"candidate:553971815 1 udp 2122260223 192.168.0.107 62807 typ host generation 0 ufrag bYNZ network-id 1","sdpMid":"0","sdpMLineIndex":0,"usernameFragment":"bYNZ"},{"candidate":"candidate:3771377453 1 udp 1686052607 103.84.209.90 62807 typ srflx raddr 192.168.0.107 rport 62807 generation 0 ufrag bYNZ network-id 1","sdpMid":"0","sdpMLineIndex":0,"usernameFragment":"bYNZ"},{"candidate":"candidate:3752731891 1 tcp 1518280447 192.168.0.107 9 typ host tcptype active generation 0 ufrag bYNZ network-id 1","sdpMid":"0","sdpMLineIndex":0,"usernameFragment":"bYNZ"}]', '2026-08-15 18:06:23', '2026-08-15 18:08:02', 99, '2026-08-15 18:06:16', '2026-08-15 18:08:02'),
(2, 10, 13, 'ended', '{"type":"offer","sdp":"v=0\\r\\ntest-offer"}', '{"type":"answer","sdp":"v=0\\r\\ntest-answer"}', '[{"candidate":"candidate:1 1 UDP 2122260223 192.168.1.100 54321 typ host"}]', '[]', '2026-08-15 18:07:00', '2026-08-15 18:07:00', 0, '2026-08-15 18:07:00', '2026-08-15 18:07:00'),
(3, 13, 10, 'ended', '{"sdp":"v=0\r\no=- 6796792629799173399 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0\r\na=extmap-allow-mixed\r\na=msid-semantic: WMS df413c39-ebc8-4666-acd6-6ccf235a1930\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111 63 9 0 8 13 110 126\r\nc=IN IP4 0.0.0.0\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=ice-ufrag:WKvJ\r\na=ice-pwd:rbA8lY/6HIMGC/fXMzBXgpAy\r\na=ice-options:trickle\r\na=fingerprint:sha-256 E8:89:36:F7:EC:F3:04:FE:3F:DE:C0:10:92:68:03:25:98:04:99:9D:85:C0:17:3F:8A:2B:F2:BE:84:3F:AA:9D\r\na=setup:actpass\r\na=mid:0\r\na=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level\r\na=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=extmap:4 urn:ietf:params:rtp-hdrext:sdes:mid\r\na=sendrecv\r\na=msid:df413c39-ebc8-4666-acd6-6ccf235a1930 9bf8223d-7486-49a5-a06a-a7d2c1a965b1\r\na=rtcp-mux\r\na=rtcp-rsize\r\na=rtcp-xr:rcvr-rtt=all\r\na=rtcp-fb:111 rrtr\r\na=rtcp-fb:63 rrtr\r\na=rtcp-fb:9 rrtr\r\na=rtcp-fb:0 rrtr\r\na=rtcp-fb:8 rrtr\r\na=rtcp-fb:13 rrtr\r\na=rtcp-fb:110 rrtr\r\na=rtcp-fb:126 rrtr\r\na=rtpmap:111 opus/48000/2\r\na=rtcp-fb:111 transport-cc\r\na=fmtp:111 minptime=10;useinbandfec=1\r\na=rtpmap:63 red/48000/2\r\na=fmtp:63 111/111\r\na=rtpmap:9 G722/8000\r\na=rtpmap:0 PCMU/8000\r\na=rtpmap:8 PCMA/8000\r\na=rtpmap:13 CN/8000\r\na=rtpmap:110 telephone-event/48000\r\na=rtpmap:126 telephone-event/8000\r\na=ssrc:1204540873 cname:Z7+0LLzzSvshBV1o\r\na=ssrc:1204540873 msid:df413c39-ebc8-4666-acd6-6ccf235a1930 9bf8223d-7486-49a5-a06a-a7d2c1a965b1\r\n","type":"offer"}', '{"sdp":"v=0\r\no=- 5176159094833117337 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0\r\na=extmap-allow-mixed\r\na=msid-semantic: WMS 6476d0e2-5c22-422e-9341-e5ad8de98c54\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111 63 9 0 8 13 110 126\r\nc=IN IP4 0.0.0.0\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=ice-ufrag:uYgT\r\na=ice-pwd:ggpOH/6TW8Xzupq4IvwoTYlP\r\na=ice-options:trickle\r\na=fingerprint:sha-256 52:52:B1:1E:F7:7F:17:F7:49:E0:59:EB:71:D3:CE:79:D8:D4:DA:B3:D5:CF:6E:D1:D6:A2:A9:BD:A8:9F:FB:0D\r\na=setup:active\r\na=mid:0\r\na=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level\r\na=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=extmap:4 urn:ietf:params:rtp-hdrext:sdes:mid\r\na=sendrecv\r\na=msid:6476d0e2-5c22-422e-9341-e5ad8de98c54 8f63d7b2-1afd-4a58-9226-6bdf6b2ed11e\r\na=rtcp-mux\r\na=rtcp-rsize\r\na=rtcp-xr:rcvr-rtt=all\r\na=rtcp-fb:111 rrtr\r\na=rtcp-fb:63 rrtr\r\na=rtcp-fb:9 rrtr\r\na=rtcp-fb:0 rrtr\r\na=rtcp-fb:8 rrtr\r\na=rtcp-fb:13 rrtr\r\na=rtcp-fb:110 rrtr\r\na=rtcp-fb:126 rrtr\r\na=rtpmap:111 opus/48000/2\r\na=rtcp-fb:111 transport-cc\r\na=fmtp:111 minptime=10;useinbandfec=1\r\na=rtpmap:63 red/48000/2\r\na=fmtp:63 111/111\r\na=rtpmap:9 G722/8000\r\na=rtpmap:0 PCMU/8000\r\na=rtpmap:8 PCMA/8000\r\na=rtpmap:13 CN/8000\r\na=rtpmap:110 telephone-event/48000\r\na=rtpmap:126 telephone-event/8000\r\na=ssrc:3691839848 cname:PYwWNdHfh6kPMnbH\r\n","type":"answer"}', '[]', '[{"candidate":"candidate:4232828690 1 udp 2122260223 192.168.0.107 64845 typ host generation 0 ufrag uYgT network-id 1","sdpMid":"0","sdpMLineIndex":0,"usernameFragment":"uYgT"},{"candidate":"candidate:1392588332 1 udp 1686052607 103.84.209.90 64845 typ srflx raddr 192.168.0.107 rport 64845 generation 0 ufrag uYgT network-id 1","sdpMid":"0","sdpMLineIndex":0,"usernameFragment":"uYgT"},{"candidate":"candidate:2189702538 1 tcp 1518280447 192.168.0.107 9 typ host tcptype active generation 0 ufrag uYgT network-id 1","sdpMid":"0","sdpMLineIndex":0,"usernameFragment":"uYgT"}]', '2026-08-15 18:08:42', '2026-08-15 18:09:17', 35, '2026-08-15 18:08:30', '2026-08-15 18:09:17'),
(4, 13, 10, 'ended', '{"sdp":"v=0\r\no=- 370926905570779993 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0\r\na=extmap-allow-mixed\r\na=msid-semantic: WMS 8a6f1810-36cd-4b96-9910-829748db47a1\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111 63 9 0 8 13 110 126\r\nc=IN IP4 0.0.0.0\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=ice-ufrag:diFC\r\na=ice-pwd:DBIWGfp9mguJknX7Ozl4O2aS\r\na=ice-options:trickle\r\na=fingerprint:sha-256 11:D2:69:AE:AF:60:7D:D4:4A:CD:45:F9:B1:50:1E:A5:35:E7:78:A0:43:CF:DD:FD:84:89:C7:6F:15:F2:47:84\r\na=setup:actpass\r\na=mid:0\r\na=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level\r\na=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=extmap:4 urn:ietf:params:rtp-hdrext:sdes:mid\r\na=sendrecv\r\na=msid:8a6f1810-36cd-4b96-9910-829748db47a1 74f9bb3b-bb00-45b9-b27d-9c3f4d1ee6d3\r\na=rtcp-mux\r\na=rtcp-rsize\r\na=rtcp-xr:rcvr-rtt=all\r\na=rtcp-fb:111 rrtr\r\na=rtcp-fb:63 rrtr\r\na=rtcp-fb:9 rrtr\r\na=rtcp-fb:0 rrtr\r\na=rtcp-fb:8 rrtr\r\na=rtcp-fb:13 rrtr\r\na=rtcp-fb:110 rrtr\r\na=rtcp-fb:126 rrtr\r\na=rtpmap:111 opus/48000/2\r\na=rtcp-fb:111 transport-cc\r\na=fmtp:111 minptime=10;useinbandfec=1\r\na=rtpmap:63 red/48000/2\r\na=fmtp:63 111/111\r\na=rtpmap:9 G722/8000\r\na=rtpmap:0 PCMU/8000\r\na=rtpmap:8 PCMA/8000\r\na=rtpmap:13 CN/8000\r\na=rtpmap:110 telephone-event/48000\r\na=rtpmap:126 telephone-event/8000\r\na=ssrc:2458151125 cname:wE8rl6vJ+aODXZi8\r\na=ssrc:2458151125 msid:8a6f1810-36cd-4b96-9910-829748db47a1 74f9bb3b-bb00-45b9-b27d-9c3f4d1ee6d3\r\n","type":"offer"}', NULL, '[]', '[{"candidate":"candidate:3432588280 1 udp 2122260223 192.168.0.107 58786 typ host generation 0 ufrag Htav network-id 1","sdpMid":"0","sdpMLineIndex":0,"usernameFragment":"Htav"},{"candidate":"candidate:1674822342 1 udp 1686052607 103.84.209.90 58786 typ srflx raddr 192.168.0.107 rport 58786 generation 0 ufrag Htav network-id 1","sdpMid":"0","sdpMLineIndex":0,"usernameFragment":"Htav"},{"candidate":"candidate:2992030048 1 tcp 1518280447 192.168.0.107 9 typ host tcptype active generation 0 ufrag Htav network-id 1","sdpMid":"0","sdpMLineIndex":0,"usernameFragment":"Htav"},{"candidate":"candidate:762319596 1 udp 2122260223 192.168.0.107 60925 typ host generation 0 ufrag DCXJ network-id 1","sdpMid":"0","sdpMLineIndex":0,"usernameFragment":"DCXJ"},{"candidate":"candidate:3971892646 1 udp 1686052607 103.84.209.90 60925 typ srflx raddr 192.168.0.107 rport 60925 generation 0 ufrag DCXJ network-id 1","sdpMid":"0","sdpMLineIndex":0,"usernameFragment":"DCXJ"},{"candidate":"candidate:3554330232 1 tcp 1518280447 192.168.0.107 9 typ host tcptype active generation 0 ufrag DCXJ network-id 1","sdpMid":"0","sdpMLineIndex":0,"usernameFragment":"DCXJ"}]', NULL, '2026-08-15 18:10:26', 0, '2026-08-15 18:09:30', '2026-08-15 18:10:26'),
(5, 10, 13, 'ended', '{"sdp":"v=0\r\no=- 4320185553601451235 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0\r\na=extmap-allow-mixed\r\na=msid-semantic: WMS 81a67f8a-61bc-4cb3-bf8f-745d8088eb62\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111 63 9 0 8 13 110 126\r\nc=IN IP4 0.0.0.0\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=ice-ufrag:ZT/Q\r\na=ice-pwd:1DjlsgGe0/qHaDGn4U8hMosE\r\na=ice-options:trickle\r\na=fingerprint:sha-256 37:37:74:89:98:11:A2:BE:2C:08:4E:C3:59:9C:7F:5F:42:A5:2F:7A:80:54:87:DF:1F:62:0F:7B:0F:1C:4B:6A\r\na=setup:actpass\r\na=mid:0\r\na=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level\r\na=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=extmap:4 urn:ietf:params:rtp-hdrext:sdes:mid\r\na=sendrecv\r\na=msid:81a67f8a-61bc-4cb3-bf8f-745d8088eb62 2ec8d453-9aef-4d6b-ad6a-19d9c232bc70\r\na=rtcp-mux\r\na=rtcp-rsize\r\na=rtcp-xr:rcvr-rtt=all\r\na=rtcp-fb:111 rrtr\r\na=rtcp-fb:63 rrtr\r\na=rtcp-fb:9 rrtr\r\na=rtcp-fb:0 rrtr\r\na=rtcp-fb:8 rrtr\r\na=rtcp-fb:13 rrtr\r\na=rtcp-fb:110 rrtr\r\na=rtcp-fb:126 rrtr\r\na=rtpmap:111 opus/48000/2\r\na=rtcp-fb:111 transport-cc\r\na=fmtp:111 minptime=10;useinbandfec=1\r\na=rtpmap:63 red/48000/2\r\na=fmtp:63 111/111\r\na=rtpmap:9 G722/8000\r\na=rtpmap:0 PCMU/8000\r\na=rtpmap:8 PCMA/8000\r\na=rtpmap:13 CN/8000\r\na=rtpmap:110 telephone-event/48000\r\na=rtpmap:126 telephone-event/8000\r\na=ssrc:4076580716 cname:59UrHCIfBtXixj/s\r\na=ssrc:4076580716 msid:81a67f8a-61bc-4cb3-bf8f-745d8088eb62 2ec8d453-9aef-4d6b-ad6a-19d9c232bc70\r\n","type":"offer"}', '{"sdp":"v=0\r\no=- 8283929139146956635 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0\r\na=extmap-allow-mixed\r\na=msid-semantic: WMS ba43c5eb-ed5c-4f43-bff6-2a2c0005eaf0\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111 63 9 0 8 13 110 126\r\nc=IN IP4 0.0.0.0\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=ice-ufrag:KwHE\r\na=ice-pwd:eC119fVUhOygSE2Tra2Sr/Bm\r\na=ice-options:trickle\r\na=fingerprint:sha-256 B3:E9:C0:B5:4B:96:C7:0C:DD:D7:86:FD:67:4E:6B:AA:38:F3:56:F4:64:07:85:F3:8F:60:30:09:76:E8:0F:0C\r\na=setup:active\r\na=mid:0\r\na=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level\r\na=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=extmap:4 urn:ietf:params:rtp-hdrext:sdes:mid\r\na=sendrecv\r\na=msid:ba43c5eb-ed5c-4f43-bff6-2a2c0005eaf0 6cf8234b-2726-4f57-9fa7-1cc07e80d2bf\r\na=rtcp-mux\r\na=rtcp-rsize\r\na=rtcp-xr:rcvr-rtt=all\r\na=rtcp-fb:111 rrtr\r\na=rtcp-fb:63 rrtr\r\na=rtcp-fb:9 rrtr\r\na=rtcp-fb:0 rrtr\r\na=rtcp-fb:8 rrtr\r\na=rtcp-fb:13 rrtr\r\na=rtcp-fb:110 rrtr\r\na=rtcp-fb:126 rrtr\r\na=rtpmap:111 opus/48000/2\r\na=rtcp-fb:111 transport-cc\r\na=fmtp:111 minptime=10;useinbandfec=1\r\na=rtpmap:63 red/48000/2\r\na=fmtp:63 111/111\r\na=rtpmap:9 G722/8000\r\na=rtpmap:0 PCMU/8000\r\na=rtpmap:8 PCMA/8000\r\na=rtpmap:13 CN/8000\r\na=rtpmap:110 telephone-event/48000\r\na=rtpmap:126 telephone-event/8000\r\na=ssrc:1436901408 cname:Fwh27YrxslUaKKLi\r\n","type":"answer"}', '[]', '[{"candidate":"candidate:3342792431 1 udp 2122260223 192.168.0.107 62290 typ host generation 0 ufrag KwHE network-id 1","sdpMid":"0","sdpMLineIndex":0,"usernameFragment":"KwHE"},{"candidate":"candidate:1752438737 1 udp 1686052607 103.84.209.90 62290 typ srflx raddr 192.168.0.107 rport 62290 generation 0 ufrag KwHE network-id 1","sdpMid":"0","sdpMLineIndex":0,"usernameFragment":"KwHE"},{"candidate":"candidate:3119584375 1 tcp 1518280447 192.168.0.107 9 typ host tcptype active generation 0 ufrag KwHE network-id 1","sdpMid":"0","sdpMLineIndex":0,"usernameFragment":"KwHE"}]', '2026-08-15 18:11:17', '2026-08-15 18:11:49', 32, '2026-08-15 18:10:41', '2026-08-15 18:11:49'),
(6, 10, 13, 'rejected', '{"sdp":"v=0\r\no=- 4683382973043077422 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0\r\na=extmap-allow-mixed\r\na=msid-semantic: WMS cd88dc32-2180-45d2-b4e1-e9484afafe79\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111 63 9 0 8 13 110 126\r\nc=IN IP4 0.0.0.0\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=ice-ufrag:c9Zn\r\na=ice-pwd:a129M/JtU7IK8OU4UbESBSUt\r\na=ice-options:trickle\r\na=fingerprint:sha-256 96:31:29:20:ED:02:A7:22:E7:FF:EB:91:95:45:81:1B:9B:84:40:29:A2:5D:20:CB:FE:54:21:19:E5:3A:CA:A0\r\na=setup:actpass\r\na=mid:0\r\na=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level\r\na=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=extmap:4 urn:ietf:params:rtp-hdrext:sdes:mid\r\na=sendrecv\r\na=msid:cd88dc32-2180-45d2-b4e1-e9484afafe79 e7126f1f-6f7f-4bcc-859e-0782a65e0563\r\na=rtcp-mux\r\na=rtcp-rsize\r\na=rtcp-xr:rcvr-rtt=all\r\na=rtcp-fb:111 rrtr\r\na=rtcp-fb:63 rrtr\r\na=rtcp-fb:9 rrtr\r\na=rtcp-fb:0 rrtr\r\na=rtcp-fb:8 rrtr\r\na=rtcp-fb:13 rrtr\r\na=rtcp-fb:110 rrtr\r\na=rtcp-fb:126 rrtr\r\na=rtpmap:111 opus/48000/2\r\na=rtcp-fb:111 transport-cc\r\na=fmtp:111 minptime=10;useinbandfec=1\r\na=rtpmap:63 red/48000/2\r\na=fmtp:63 111/111\r\na=rtpmap:9 G722/8000\r\na=rtpmap:0 PCMU/8000\r\na=rtpmap:8 PCMA/8000\r\na=rtpmap:13 CN/8000\r\na=rtpmap:110 telephone-event/48000\r\na=rtpmap:126 telephone-event/8000\r\na=ssrc:3415777179 cname:toMQCALMLFqdwPvg\r\na=ssrc:3415777179 msid:cd88dc32-2180-45d2-b4e1-e9484afafe79 e7126f1f-6f7f-4bcc-859e-0782a65e0563\r\n","type":"offer"}', NULL, '[]', '[]', NULL, '2026-08-15 18:13:01', 0, '2026-08-15 18:12:08', '2026-08-15 18:13:01'),
(7, 10, 13, 'rejected', '{"sdp":"v=0\r\no=- 4146489436298955526 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0\r\na=extmap-allow-mixed\r\na=msid-semantic: WMS e263ecf4-bf74-44bd-8a83-c4853f40f90d\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111 63 9 0 8 13 110 126\r\nc=IN IP4 0.0.0.0\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=ice-ufrag:jpBA\r\na=ice-pwd:WOgff0s/ZCEWYayqUjD6awa6\r\na=ice-options:trickle\r\na=fingerprint:sha-256 F0:27:05:DE:35:84:5B:C2:E5:79:76:20:83:A9:DB:19:C0:54:C5:95:E7:C0:B9:AE:50:7D:5C:B5:19:D2:45:E7\r\na=setup:actpass\r\na=mid:0\r\na=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level\r\na=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=extmap:4 urn:ietf:params:rtp-hdrext:sdes:mid\r\na=sendrecv\r\na=msid:e263ecf4-bf74-44bd-8a83-c4853f40f90d 6d3c0bd4-e5bd-4fb9-b440-c75e04f879b2\r\na=rtcp-mux\r\na=rtcp-rsize\r\na=rtcp-xr:rcvr-rtt=all\r\na=rtcp-fb:111 rrtr\r\na=rtcp-fb:63 rrtr\r\na=rtcp-fb:9 rrtr\r\na=rtcp-fb:0 rrtr\r\na=rtcp-fb:8 rrtr\r\na=rtcp-fb:13 rrtr\r\na=rtcp-fb:110 rrtr\r\na=rtcp-fb:126 rrtr\r\na=rtpmap:111 opus/48000/2\r\na=rtcp-fb:111 transport-cc\r\na=fmtp:111 minptime=10;useinbandfec=1\r\na=rtpmap:63 red/48000/2\r\na=fmtp:63 111/111\r\na=rtpmap:9 G722/8000\r\na=rtpmap:0 PCMU/8000\r\na=rtpmap:8 PCMA/8000\r\na=rtpmap:13 CN/8000\r\na=rtpmap:110 telephone-event/48000\r\na=rtpmap:126 telephone-event/8000\r\na=ssrc:1289201631 cname:k0w6IoouV40svbLM\r\na=ssrc:1289201631 msid:e263ecf4-bf74-44bd-8a83-c4853f40f90d 6d3c0bd4-e5bd-4fb9-b440-c75e04f879b2\r\n","type":"offer"}', '{"sdp":"v=0\r\no=- 3639384382084724663 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0\r\na=extmap-allow-mixed\r\na=msid-semantic: WMS 7ee7c4ac-98d6-491e-bf2c-cdf20877b165\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111 63 9 0 8 13 110 126\r\nc=IN IP4 0.0.0.0\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=ice-ufrag:m+MZ\r\na=ice-pwd:svS5CSMFg5LSEfy2JhjTX1sa\r\na=ice-options:trickle\r\na=fingerprint:sha-256 B9:7D:26:9A:C1:E7:91:D4:EB:AA:9E:68:35:CE:BE:04:D0:9C:3A:E6:7D:C0:E9:2F:BC:A3:FD:27:DA:24:49:F2\r\na=setup:active\r\na=mid:0\r\na=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level\r\na=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=extmap:4 urn:ietf:params:rtp-hdrext:sdes:mid\r\na=sendrecv\r\na=msid:7ee7c4ac-98d6-491e-bf2c-cdf20877b165 004d6675-9532-4761-b4fe-fc2a24202b76\r\na=rtcp-mux\r\na=rtcp-rsize\r\na=rtcp-xr:rcvr-rtt=all\r\na=rtcp-fb:111 rrtr\r\na=rtcp-fb:63 rrtr\r\na=rtcp-fb:9 rrtr\r\na=rtcp-fb:0 rrtr\r\na=rtcp-fb:8 rrtr\r\na=rtcp-fb:13 rrtr\r\na=rtcp-fb:110 rrtr\r\na=rtcp-fb:126 rrtr\r\na=rtpmap:111 opus/48000/2\r\na=rtcp-fb:111 transport-cc\r\na=fmtp:111 minptime=10;useinbandfec=1\r\na=rtpmap:63 red/48000/2\r\na=fmtp:63 111/111\r\na=rtpmap:9 G722/8000\r\na=rtpmap:0 PCMU/8000\r\na=rtpmap:8 PCMA/8000\r\na=rtpmap:13 CN/8000\r\na=rtpmap:110 telephone-event/48000\r\na=rtpmap:126 telephone-event/8000\r\na=ssrc:2004297380 cname:aettyWgA59gVJDxn\r\n","type":"answer"}', '[]', '[{"candidate":"candidate:200335787 1 udp 2122260223 192.168.0.107 54872 typ host generation 0 ufrag m+MZ network-id 1","sdpMid":"0","sdpMLineIndex":0,"usernameFragment":"m+MZ"},{"candidate":"candidate:3393107681 1 udp 1686052607 103.84.209.90 54872 typ srflx raddr 192.168.0.107 rport 54872 generation 0 ufrag m+MZ network-id 1","sdpMid":"0","sdpMLineIndex":0,"usernameFragment":"m+MZ"},{"candidate":"candidate:4116329791 1 tcp 1518280447 192.168.0.107 9 typ host tcptype active generation 0 ufrag m+MZ network-id 1","sdpMid":"0","sdpMLineIndex":0,"usernameFragment":"m+MZ"}]', '2026-08-15 18:13:51', '2026-08-15 18:14:22', 31, '2026-08-15 18:13:44', '2026-08-15 18:14:22'),
(8, 13, 10, 'rejected', '{"sdp":"v=0\r\no=- 221858740246090093 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0\r\na=extmap-allow-mixed\r\na=msid-semantic: WMS 79ef4f13-a67b-4461-8e81-79f4e406764a\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111 63 9 0 8 13 110 126\r\nc=IN IP4 0.0.0.0\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=ice-ufrag:Aqay\r\na=ice-pwd:NBjwKTFXWFXXLzr64XWb6yO9\r\na=ice-options:trickle\r\na=fingerprint:sha-256 47:39:B8:7E:23:B9:94:01:CD:9D:29:F5:BE:59:7F:C3:68:16:7B:89:FD:B0:20:EE:23:C8:0E:D5:2D:D6:52:85\r\na=setup:actpass\r\na=mid:0\r\na=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level\r\na=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=extmap:4 urn:ietf:params:rtp-hdrext:sdes:mid\r\na=sendrecv\r\na=msid:79ef4f13-a67b-4461-8e81-79f4e406764a b2b90a6b-8fd9-486d-98ff-00609defa1f5\r\na=rtcp-mux\r\na=rtcp-rsize\r\na=rtcp-xr:rcvr-rtt=all\r\na=rtcp-fb:111 rrtr\r\na=rtcp-fb:63 rrtr\r\na=rtcp-fb:9 rrtr\r\na=rtcp-fb:0 rrtr\r\na=rtcp-fb:8 rrtr\r\na=rtcp-fb:13 rrtr\r\na=rtcp-fb:110 rrtr\r\na=rtcp-fb:126 rrtr\r\na=rtpmap:111 opus/48000/2\r\na=rtcp-fb:111 transport-cc\r\na=fmtp:111 minptime=10;useinbandfec=1\r\na=rtpmap:63 red/48000/2\r\na=fmtp:63 111/111\r\na=rtpmap:9 G722/8000\r\na=rtpmap:0 PCMU/8000\r\na=rtpmap:8 PCMA/8000\r\na=rtpmap:13 CN/8000\r\na=rtpmap:110 telephone-event/48000\r\na=rtpmap:126 telephone-event/8000\r\na=ssrc:3989358645 cname:q2dF2Btx41p9a8xY\r\na=ssrc:3989358645 msid:79ef4f13-a67b-4461-8e81-79f4e406764a b2b90a6b-8fd9-486d-98ff-00609defa1f5\r\n","type":"offer"}', NULL, '[{"candidate":"candidate:2456552774 1 udp 1686052607 103.84.209.90 54225 typ srflx raddr 192.168.0.101 rport 54225 generation 0 ufrag Aqay network-id 1","sdpMid":"0","sdpMLineIndex":0,"usernameFragment":"Aqay"}]', '[]', NULL, '2026-08-16 11:36:07', 0, '2026-08-16 11:36:01', '2026-08-16 11:36:08'),
(9, 10, 13, 'ended', '{"sdp":"v=0\r\no=- 1817940639216944187 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0\r\na=extmap-allow-mixed\r\na=msid-semantic: WMS eca449d8-c604-4d45-8778-f9504c181a97\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111 63 9 0 8 13 110 126\r\nc=IN IP4 0.0.0.0\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=ice-ufrag:nwbt\r\na=ice-pwd:cI2skkDcyusdTRSA+Z/u4Wmn\r\na=ice-options:trickle\r\na=fingerprint:sha-256 0B:57:CC:A9:DA:62:42:CF:3D:AB:88:5B:B8:54:06:94:AF:7E:A3:C5:05:A4:5F:70:2C:F6:8A:4F:D3:14:DE:D0\r\na=setup:actpass\r\na=mid:0\r\na=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level\r\na=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=extmap:4 urn:ietf:params:rtp-hdrext:sdes:mid\r\na=sendrecv\r\na=msid:eca449d8-c604-4d45-8778-f9504c181a97 fb2b4847-1d93-44d9-925f-5132a8681933\r\na=rtcp-mux\r\na=rtcp-rsize\r\na=rtcp-xr:rcvr-rtt=all\r\na=rtcp-fb:111 rrtr\r\na=rtcp-fb:63 rrtr\r\na=rtcp-fb:9 rrtr\r\na=rtcp-fb:0 rrtr\r\na=rtcp-fb:8 rrtr\r\na=rtcp-fb:13 rrtr\r\na=rtcp-fb:110 rrtr\r\na=rtcp-fb:126 rrtr\r\na=rtpmap:111 opus/48000/2\r\na=rtcp-fb:111 transport-cc\r\na=fmtp:111 minptime=10;useinbandfec=1\r\na=rtpmap:63 red/48000/2\r\na=fmtp:63 111/111\r\na=rtpmap:9 G722/8000\r\na=rtpmap:0 PCMU/8000\r\na=rtpmap:8 PCMA/8000\r\na=rtpmap:13 CN/8000\r\na=rtpmap:110 telephone-event/48000\r\na=rtpmap:126 telephone-event/8000\r\na=ssrc:3214252457 cname:g+VE5REQYpvIPPnI\r\na=ssrc:3214252457 msid:eca449d8-c604-4d45-8778-f9504c181a97 fb2b4847-1d93-44d9-925f-5132a8681933\r\n","type":"offer"}', NULL, '[]', '[]', NULL, '2026-08-17 16:15:13', 0, '2026-08-17 16:15:10', '2026-08-17 16:15:13');

SELECT setval('public.voice_calls_id_seq', COALESCE((SELECT MAX("id") FROM "voice_calls"), 1), true);

