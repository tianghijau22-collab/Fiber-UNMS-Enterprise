<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Fiber UNMS — Cinox Media Network</title>

    <?php
        $hotFile = public_path('hot');
        if (file_exists($hotFile)) {
            $fp = @fsockopen('127.0.0.1', 5173, $errno, $errstr, 0.1);
            if (!$fp) {
                @unlink($hotFile);
            } else {
                fclose($fp);
            }
        }
    ?>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app-entry.jsx']); ?>
</head>
<body class="font-sans">
    <div id="root"></div>
</body>
</html>
<?php /**PATH C:\Projects\Fiber-UNMS\resources\views/app.blade.php ENDPATH**/ ?>