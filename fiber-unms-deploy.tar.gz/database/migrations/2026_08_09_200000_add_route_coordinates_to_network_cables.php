<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('network_cables', function (Blueprint $table) {
            $table->json('route_coordinates')->nullable()->after('route_description');
        });
    }

    public function down(): void
    {
        Schema::table('network_cables', function (Blueprint $table) {
            $table->dropColumn('route_coordinates');
        });
    }
};
